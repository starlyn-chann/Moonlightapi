import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ANTILINK_FILE = path.join(__dirname, 'data', 'antilink.json');
const USERS_FILE = path.join(__dirname, 'data', 'users.json');
const PRIMARIOS_FILE = path.join(process.cwd(), 'databases', 'primarios.json');

const linkRegex = /(https?:\/\/)?(chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}|whatsapp\.com\/channel\/[0-9A-Za-z]{20,24})/i;

function loadAntilink() {
    try {
        if (fs.existsSync(ANTILINK_FILE)) {
            const data = fs.readFileSync(ANTILINK_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando antilink:', e);
    }
    return {};
}

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function cleanNumber(number) {
    if (!number) return '';
    if (typeof number === 'object') {
        number = number.id || number.jid || number.phoneNumber || '';
    }
    if (typeof number === 'string') {
        let cleaned = number.replace(/@.+/, '').split(':')[0];
        cleaned = cleaned.replace(/\D/g, '');
        return cleaned;
    }
    return '';
}

function getPrimaryBot(groupId) {
    try {
        if (fs.existsSync(PRIMARIOS_FILE)) {
            const data = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
            return data[groupId] || null;
        }
    } catch (e) {}
    return null;
}

function getBotNumber(sock) {
    if (sock.phoneNumber) {
        return sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        return sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    return '';
}

function loadConfig() {
    try {
        const configPath = path.join(__dirname, 'config.js');
        if (fs.existsSync(configPath)) {
            const configContent = fs.readFileSync(configPath, 'utf8');
            const match = configContent.match(/export default\s+({[\s\S]*})/);
            if (match && match[1]) {
                return eval('(' + match[1] + ')');
            }
        }
    } catch (e) {
        console.error('Error cargando config:', e);
    }
    return {};
}

function getCommandName(body) {
    // Obtener el nombre del comando del mensaje
    if (!body) return '';
    const prefix = '.';
    if (!body.startsWith(prefix)) return '';
    const parts = body.slice(prefix.length).trim().split(/ +/);
    return parts[0]?.toLowerCase() || '';
}

export default async (sock, msg) => {
    try {
        // Solo procesar mensajes de grupo
        if (!msg.key?.remoteJid?.includes('@g.us')) return;
        
        // Solo procesar mensajes de texto
        const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
        if (!body) return;
        
        // ============ VERIFICAR SI ES COMANDO SAY O TAG ============
        // Si es un comando (empieza con .), verificar si es say o tag
        if (body.startsWith('.')) {
            const commandName = getCommandName(body);
            // Si es say o tag, ignorar completamente el antilink
            if (commandName === 'say' || commandName === 'tag' || commandName === 'decir') {
                console.log(`[ANTILINK] Comando ${commandName} ignorado`);
                return;
            }
        }
        // ================================================================
        
        // Obtener información del mensaje
        const from = msg.key.remoteJid;
        const participant = msg.key.participant || msg.key.remoteJid;
        const number = cleanNumber(participant);
        const senderJid = participant;
        
        // Verificar si es un mensaje del bot
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        if (senderJid === botId) return;
        
        // Verificar si hay un bot primario
        const primaryData = getPrimaryBot(from);
        const currentBotNumber = getBotNumber(sock);
        const isPrimary = !primaryData || primaryData.botNumber === currentBotNumber;
        
        // Si no es primario, ignorar
        if (!isPrimary) {
            console.log(`[ANTILINK] Bot primario es ${primaryData?.botNumber}, ignorando`);
            return;
        }
        
        // Verificar si el antilink está activo en el grupo
        const antilinkData = loadAntilink();
        const isAntilinkActive = antilinkData[from] !== false;
        if (!isAntilinkActive) return;
        
        // Verificar si es administrador
        const groupMetadata = await sock.groupMetadata(from).catch(() => null);
        if (!groupMetadata) return;
        
        const participantData = groupMetadata.participants.find(p => p.id === senderJid);
        const isAdmin = participantData?.admin === 'admin' || participantData?.admin === 'superadmin';
        
        // Si es admin, ignorar
        if (isAdmin) return;
        
        // Verificar si el bot es admin
        const botParticipant = groupMetadata.participants.find(p => p.id === botId);
        const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
        
        // Si el bot no es admin, no puede eliminar
        if (!isBotAdmin) return;
        
        // Verificar si es un enlace de grupo o canal de WhatsApp
        const isGroupLink = linkRegex.test(body);
        if (!isGroupLink) return;
        
        // Verificar si el enlace es del canal permitido
        const config = loadConfig();
        const allowedChannel = config.canalId || '';
        
        // Si es el canal permitido, ignorar
        if (allowedChannel && body.includes(allowedChannel)) return;
        
        // Eliminar mensaje
        try {
            await sock.sendMessage(from, {
                delete: {
                    remoteJid: from,
                    fromMe: false,
                    id: msg.key.id,
                    participant: senderJid
                }
            });
        } catch (e) {
            console.error('Error eliminando mensaje:', e);
        }
        
        // Verificar si es enlace de canal o grupo
        const isChannelLink = /whatsapp\.com\/channel\//i.test(body);
        const tipoLink = isChannelLink ? 'canales' : 'otros grupos';
        
        // Enviar mensaje de advertencia con mención al usuario
        try {
            const warnMsg = `> ✿ Se ha eliminado a @${number} del grupo por \`Anti-Link\`, no permitimos enlaces de *${tipoLink}*.`;
            await sock.sendMessage(from, {
                text: warnMsg,
                mentions: [senderJid]
            });
        } catch (e) {
            console.error('Error enviando mensaje de advertencia:', e);
        }
        
        // Eliminar usuario del grupo
        try {
            await sock.groupParticipantsUpdate(from, [senderJid], 'remove');
            console.log(`🚫 Usuario ${number} eliminado por antilink en ${from}`);
        } catch (e) {
            console.error('Error eliminando usuario:', e);
        }
        
    } catch (error) {
        console.error('❌ Error en antilink:', error);
    }
};