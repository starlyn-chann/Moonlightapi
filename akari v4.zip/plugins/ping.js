export default {
    name: 'ping',
    alias: ['speed', 'p', 'test'],
    description: 'Latencia',
    category: 'main',
    
    async execute(sock, msg, { args, command, body, config, startTime, isOwner, pushName, userNumber, isGroup, expResult, replyWithContext }) {
        
        // Obtener el timestamp del mensaje original del usuario
        const messageTimestamp = msg.messageTimestamp || msg.message?.messageTimestamp;
        const userSendTime = messageTimestamp * 1000; // Convertir a milisegundos
        
        // Tiempo actual (cuando el bot responde)
        const now = Date.now();
        
        // Calcular ping real (tiempo desde que el usuario envió hasta ahora)
        const ping = now - userSendTime;
        
        const response = `᠙࣭ᜒ𝆬𖤐ֵ໊ᰰ🍪໋ຼ̷̸ֹ〪⍰᜔᮫𞄳 ¡Pong!\n> *Velocidad ⧖ ${ping}ms*`;
        
        await replyWithContext(response);
    }
};