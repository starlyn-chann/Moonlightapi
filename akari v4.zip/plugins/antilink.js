import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ANTILINK_FILE = path.join(__dirname, '..', 'data', 'antilink.json');

function loadAntilink() {
    try {
        if (fs.existsSync(ANTILINK_FILE)) {
            const data = fs.readFileSync(ANTILINK_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando antilink:', e);
    }
    return {};
}

function saveAntilink(antilink) {
    try {
        fs.writeFileSync(ANTILINK_FILE, JSON.stringify(antilink, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando antilink:', e);
        return false;
    }
}

export default {
    name: 'antilink',
    alias: ['antilinks'],
    description: 'Activar o desactivar el antilink en el grupo',
    category: 'on / off',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, isGroup, isOwner } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === msg.key.participant);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            
            if (!isAdmin && !isOwner) {
                return await replyWithContext(`*ᰔᩚ* *Solo administradores pueden usar este comando*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes proporcionar *on/off*\n> Ejemplo: ${config.prefix}antilink on`
                );
            }
            
            const accion = args[0].toLowerCase();
            
            if (accion !== 'on' && accion !== 'off') {
                return await replyWithContext(`❀ Debes proporcionar *on/off*`);
            }
            
            const antilink = loadAntilink();
            
            if (accion === 'on') {
                antilink[from] = true;
                saveAntilink(antilink);
                await replyWithContext(`❀ *Antilink activado* en este grupo.\n> Los usuarios que envíen enlaces serán eliminados.`);
            } else {
                antilink[from] = false;
                saveAntilink(antilink);
                await replyWithContext(`❀ *Antilink desactivado* en este grupo.`);
            }
            
        } catch (error) {
            console.error('❌ Error en antilink:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};