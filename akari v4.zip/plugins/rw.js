import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import { obtenerPersonajesAleatorios, verificarReclamo, obtenerPersonajesReclamados } from '../lib/gacha.js';
import { 
    guardarPersonajeEnGrupo, 
    eliminarPersonajeDelCache, 
    cambiarAFase2,
    getPersonajeEnGrupo,
    getTiempoRestante 
} from '../lib/gachaCache.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

// ============ DANBOORU SESSION ============
let sessionCookie = null;

async function getDanbooruSession() {
    if (sessionCookie) return sessionCookie;
    try {
        const res = await axios.post('https://danbooru.donmai.us/session', 
            'user[name]=uwudanonino5599&user[password]=danoninoleonel5599', 
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        sessionCookie = res.headers['set-cookie'];
        return sessionCookie;
    } catch (e) {
        console.error('Error obteniendo sesión Danbooru:', e.message);
        return null;
    }
}

async function getDanbooruImage(tag) {
    try {
        const cookie = await getDanbooruSession();
        const url = `https://danbooru.donmai.us/posts.json?tags=${encodeURIComponent(tag)}&limit=20&random=true`;
        
        const response = await axios.get(url, {
            headers: { 'Cookie': cookie || '' },
            timeout: 15000
        });

        const json = response.data;

        if (!Array.isArray(json) || json.length === 0) {
            return null;
        }

        const mediaList = json
            .filter(p => p?.file_url && /\.(jpe?g|png|gif|webp)$/i.test(p.file_url))
            .map(p => p.file_url);

        if (!mediaList.length) {
            return null;
        }

        return mediaList[Math.floor(Math.random() * mediaList.length)];
    } catch (error) {
        console.error('Error buscando imagen en Danbooru:', error.message);
        return null;
    }
}

// ============ SAFEBOORU ============
async function getSafebooruImage(tag) {
    try {
        const url = `https://safebooru.org/index.php?page=dapi&s=post&q=index&json=1&tags=${encodeURIComponent(tag)}`;
        
        const response = await axios.get(url, {
            headers: { 
                'User-Agent': 'Mozilla/5.0', 
                'Accept': 'application/json' 
            },
            timeout: 15000
        });

        const json = response.data;
        const data = Array.isArray(json) ? json : json?.post || json?.data || [];

        if (!data || data.length === 0) {
            return null;
        }

        const mediaList = data
            .map(i => i?.file_url || i?.large_file_url || i?.image)
            .filter(u => typeof u === 'string' && /\.(jpe?g|png|gif|webp)$/i.test(u));

        if (!mediaList.length) {
            return null;
        }

        return mediaList[Math.floor(Math.random() * mediaList.length)];
    } catch (error) {
        console.error('Error buscando imagen en Safebooru:', error.message);
        return null;
    }
}

// =============================================

export default {
    name: 'rw',
    alias: ['roll', 'waifu'],
    description: 'Obtén un personaje aleatorio del gacha con imagen',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando rw...');
            
            const { config, replyWithContext, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // Cooldown de 10 minutos
            const cooldownKey = `cooldown_${from}_${userNumber}`;
            const cooldownData = getPersonajeEnGrupo(cooldownKey);
            
            if (cooldownData) {
                const tiempoTranscurrido = Date.now() - cooldownData.timestamp;
                const tiempoRestante = Math.max(0, 600000 - tiempoTranscurrido);
                
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.ceil((tiempoRestante % 60000) / 1000);
                    const tiempoStr = minutos > 0 ? `${minutos}m ${segundos}s` : `${segundos}s`;
                    return await replyWithContext(`ꕤ Debes esperar \`${tiempoStr}\` para volver a usar ${config.prefix}rw`);
                } else {
                    eliminarPersonajeDelCache(cooldownKey);
                }
            }
            
            // Verificar si hay personajes disponibles
            const personajes = await obtenerPersonajesAleatorios(1);
            
            if (!personajes || personajes.length === 0) {
                return await replyWithContext(`❌ *No hay personajes disponibles*\n> Agrega personajes con ${config.prefix}addpj`);
            }
            
            const personaje = personajes[0];
            
            // ============ VERIFICAR SI ESTÁ RECLAMADO ============
            const reclamado = await verificarReclamo(from, personaje.id);
            let nombreReclamador = null;
            
            if (reclamado) {
                const reclamos = await obtenerPersonajesReclamados(from);
                const reclamo = reclamos.find(r => r.personajeId === personaje.id);
                
                if (reclamo) {
                    const usersDb = loadUsersDb();
                    const user = usersDb.find(u => u.number === reclamo.usuarioId);
                    nombreReclamador = user ? user.pushName : reclamo.usuarioId;
                }
            }
            // ==============================================================
            
            // Estado del personaje
            let estado;
            if (reclamado && nombreReclamador) {
                estado = `ᰔᩚ 𝖤𝗌𝗍𝖺𝖽𝗈 › Reclamado por ${nombreReclamador}`;
            } else if (reclamado) {
                estado = `ᰔᩚ 𝖤𝗌𝗍𝖺𝖽𝗈 › Reclamado`;
            } else {
                estado = `ᰔᩚ 𝖤𝗌𝗍𝖺𝖽𝗈 › Libre`;
            }
            
            // ============ BUSCAR IMAGEN (DANBOORU → SAFEBOORU) ============
            let imageUrl = null;
            let imageFound = false;
            
            if (personaje.tag) {
                console.log(`🔍 Buscando imagen para: ${personaje.tag}`);
                
                // Primero intentar en Danbooru
                imageUrl = await getDanbooruImage(personaje.tag);
                if (imageUrl) {
                    imageFound = true;
                    console.log(`✅ Imagen encontrada en Danbooru: ${imageUrl}`);
                } else {
                    console.log(`❌ Sin resultados en Danbooru, buscando en Safebooru...`);
                    // Si no hay en Danbooru, buscar en Safebooru
                    imageUrl = await getSafebooruImage(personaje.tag);
                    if (imageUrl) {
                        imageFound = true;
                        console.log(`✅ Imagen encontrada en Safebooru: ${imageUrl}`);
                    } else {
                        console.log(`❌ No se encontró imagen en Danbooru ni Safebooru para: ${personaje.tag}`);
                    }
                }
            }
            
            // Crear caption SOLO con la información del personaje
            const caption = 
`❀ 𝖭𝗈𝗆𝖻𝗋𝖾 › ${personaje.nombre}
✧ 𝖵𝖺𝗅𝗈𝗋 › ${personaje.valor}
⚥ 𝖦e𝗇𝖾𝗋𝗈 › ${personaje.genero}
${estado}
♡ 𝖲𝖾𝗋𝗂𝖾 › ${personaje.anime}`;

            // Enviar mensaje con imagen o sin ella
            let sentMsg;
            
            if (imageFound && imageUrl) {
                sentMsg = await sock.sendMessage(from, {
                    image: { url: imageUrl },
                    caption: caption,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                sentMsg = await replyWithContext(caption);
            }
            
            // ============ SI ESTÁ LIBRE, GUARDAR EN CACHE ============
            if (!reclamado) {
                const cacheKey = `${from}_${userNumber}`;
                const cacheActual = getPersonajeEnGrupo(cacheKey);
                
                if (!cacheActual) {
                    guardarPersonajeEnGrupo(cacheKey, personaje.id, userNumber, sentMsg?.key?.id || null);
                    console.log(`💾 Personaje guardado: ${personaje.nombre}`);
                    
                    guardarPersonajeEnGrupo(cooldownKey, 'cooldown', userNumber, null);
                    
                    setTimeout(() => {
                        const data = getPersonajeEnGrupo(cacheKey);
                        if (data && data.fase === 1) {
                            cambiarAFase2(cacheKey);
                            console.log(`⏰ Personaje ${personaje.nombre} pasó a fase 2`);
                        }
                    }, 60000);
                    
                    setTimeout(() => {
                        const data = getPersonajeEnGrupo(cacheKey);
                        if (data) {
                            eliminarPersonajeDelCache(cacheKey);
                            console.log(`⏰ Personaje ${personaje.nombre} expiró`);
                        }
                    }, 120000);
                    
                    setTimeout(() => {
                        const cooldown = getPersonajeEnGrupo(cooldownKey);
                        if (cooldown) {
                            eliminarPersonajeDelCache(cooldownKey);
                            console.log(`⏰ Cooldown eliminado para ${userNumber}`);
                        }
                    }, 600000);
                }
            }
            // ==============================================================
            
            console.log('✅ Comando rw finalizado');
            
        } catch (error) {
            console.error('❌ Error en rw:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};