export default {
    name: 'totalfunciones',
    alias: ['totalcmd'],
    description: 'Muestra el total de comandos disponibles',
    category: 'main',
    
    async execute(sock, msg, options) {
        try {
            const { plugins, replyWithContext, isOwner } = options;
            
            let totalComandos = 0;
            
            if (plugins && typeof plugins.forEach === 'function') {
                const processedCommands = new Set();
                
                for (const [name, plugin] of plugins) {
                    if (processedCommands.has(plugin.name)) continue;
                    processedCommands.add(plugin.name);
                    
                    if (plugin.name && plugin.category) {
                        // Excluir categoría owner para todos (incluso para el owner)
                        if (plugin.category.toLowerCase() === 'owner') continue;
                        totalComandos++;
                    }
                }
            }
            
            await replyWithContext(`Იᮬ͡ᩚ𐑼ֹֹֹֹ֟ᮬ͚፝ᩚܻ⃞🩰❀ֹֹֹֹᮬ͜ᮬ፝ *ƚᦅƚα𝗅 𝖿𝗎𝗇cꪱᦅ𝗇ᧉ𝗌* » ${totalComandos}`);
            
        } catch (error) {
            console.error('❌ Error en totalfunciones:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};