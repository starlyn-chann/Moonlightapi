import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { obtenerPacksUsuario, agregarSticker } from '../lib/mongoose.js';

export default {
    name: 'addsticker',
    alias: ['stickeradd'],
    description: 'Agrega un sticker a un pack',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            const args = options.args || [];
            const packName = args.join(' ').trim();
            
            if (!packName) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre del pack\n> Ejemplo: ${config.prefix}addsticker Mis Stickers (Respondiendo a un sticker)`);
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage || !quotedMessage.stickerMessage) {
                return await replyWithContext(`「✰」 *Debes responder a un sticker*\n> Ejemplo: ${config.prefix}addsticker Mis Stickers (respondiendo a un sticker)`);
            }
            
            // Obtener packs del usuario desde MongoDB
            const packs = await obtenerPacksUsuario(userNumber);
            
            if (!packs || packs.length === 0) {
                return await replyWithContext(`「✰」 No tienes ningún pack creado\n> Crea uno con ${config.prefix}newpack <nombre>`);
            }
            
            const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (!pack) {
                return await replyWithContext(`「✰」No tienes un pack llamado "${packName}"\n> Crea uno usando ${config.prefix}newpack ${packName}`);
            }
            
            if (pack.stickers && pack.stickers.length >= 50) {
                return await replyWithContext(`「✰」Límite de stickers alcanzado *(50/50)*`);
            }
            
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg.stanzaId,
                    participant: quotedMsg.participant || from,
                    fromMe: false
                },
                message: {
                    stickerMessage: quotedMessage.stickerMessage
                }
            };
            
            const stickerBuffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            if (!stickerBuffer || stickerBuffer.length === 0) {
                throw new Error('No se pudo descargar el sticker');
            }
            
            const stickerId = Date.now().toString() + Math.random().toString(36).substring(7);
            
            const stickerData = {
                id: stickerId,
                buffer: stickerBuffer.toString('base64'),
                addedAt: new Date().toLocaleString(),
                timestamp: Date.now()
            };
            
            // Agregar sticker a MongoDB
            const resultado = await agregarSticker(userNumber, packName, stickerData);
            
            if (!resultado) {
                return await replyWithContext(`❌ Error al guardar el sticker en la base de datos.\n> Por favor, intenta nuevamente.`);
            }
            
            // Obtener cantidad actualizada de stickers
            const packsActualizados = await obtenerPacksUsuario(userNumber);
            const packActualizado = packsActualizados.find(p => p.name.toLowerCase() === packName.toLowerCase());
            const cantidad = packActualizado?.stickers?.length || 0;
            
            await replyWithContext(`《✧》Sticker agregado al pack \`${pack.name}\`!\n> Ahora tiene *${cantidad}* sticker(s)`);
            
        } catch (error) {
            console.error('❌ Error en addsticker:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};