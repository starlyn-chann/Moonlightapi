import axios from 'axios';

export default {
    name: 'happymod',
    alias: ['hm'],
    description: 'Busca mods de juegos en HappyMod',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ');
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes proporcionar el nombre del juego o aplicación a buscar\n> Ejemplo: ${options.config.prefix}happymod subway surfers`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            // Llamar a la API de HappyMod SIN TIMEOUT
            const apiUrl = `https://api-xemoz-official.my.id/api/search/happymod.php?q=${encodeURIComponent(query)}`;
            const response = await axios.get(apiUrl, {
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            // Verificar si la API respondió correctamente
            if (!response.data?.status || !response.data?.result?.success || !response.data.result.results?.length) {
                return await replyWithContext(`《✧》No se encontraron resultados para *${query}*`);
            }
            
            const results = response.data.result.results;
            
            // Construir el mensaje con el diseño exacto
            let message = `★ \`\`\`H A P P Y - M O D\`\`\`\n\n`;
            
            // Mostrar cada resultado con el mismo formato
            for (let i = 0; i < results.length; i++) {
                const result = results[i];
                message += `[ ✰ ] *Título ›* ${result.title}\n`;
                message += `[ ✰ ] *Url ›* ${result.url}\n`;
                message += `[ ✰ ] *Info ›* ${result.info.join(' • ')}\n`;
                
                // Agregar separador entre resultados excepto en el último
                if (i < results.length - 1) {
                    message += `\n`;
                }
            }
            
            // Enviar con la imagen del icono del primer resultado
            const firstResult = results[0];
            if (firstResult.icon) {
                try {
                    // Descargar el icono SIN TIMEOUT
                    const iconResponse = await axios.get(firstResult.icon, {
                        responseType: 'arraybuffer',
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    const iconBuffer = Buffer.from(iconResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: iconBuffer,
                        caption: message,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: options.config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: options.config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (iconError) {
                    // Si falla la descarga del icono, enviar solo el texto
                    console.log('Error descargando icono:', iconError.message);
                    await replyWithContext(message);
                }
            } else {
                await replyWithContext(message);
            }
            
            // Reacción de éxito
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ HappyMod buscado por ${pushName || userNumber}: "${query}" - ${results.length} resultados`);
            
        } catch (error) {
            console.error('❌ Error en happymod:', error);
            
            // Reacción de error
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            // Verificar si el error es por la API lenta pero tiene datos parciales
            if (error.response?.data) {
                try {
                    const partialData = error.response.data;
                    if (partialData?.result?.results?.length) {
                        const results = partialData.result.results;
                        let message = `★ \`\`\`H A P P Y - M O D\`\`\`\n\n`;
                        
                        for (let i = 0; i < results.length; i++) {
                            const result = results[i];
                            message += `[ ✰ ] *Título ›* ${result.title}\n`;
                            message += `[ ✰ ] *Url ›* ${result.url}\n`;
                            message += `[ ✰ ] *Info ›* ${result.info.join(' • ')}\n`;
                            
                            if (i < results.length - 1) {
                                message += `\n`;
                            }
                        }
                        
                        return await replyWithContext(message);
                    }
                } catch (e) {}
            }
            
            // Mensaje de error exacto
            const query = options.args?.join(' ') || 'la búsqueda';
            await options.replyWithContext(`《✧》No se encontraron resultados para *${query}*`);
        }
    }
};