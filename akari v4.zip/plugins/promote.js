export default {
    name: 'promote',
    alias: ['promover'],
    description: 'Promueve a administrador a un miembro del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, senderJid, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Función para limpiar número y obtener JID limpio
            function cleanNumber(jid) {
                if (!jid) return '';
                // Limpiar el JID: quitar :0 y @s.whatsapp.net
                const cleanJid = jid.split(':')[0].split('@')[0];
                return cleanJid.replace(/\D/g, '');
            }
            
            function getCleanJid(jid) {
                if (!jid) return '';
                // Devolver JID limpio para menciones (formato número@s.whatsapp.net)
                const number = cleanNumber(jid);
                return `${number}@s.whatsapp.net`;
            }
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Obtener el usuario objetivo (mencionado o respondido)
            let targetJid = null;
            let targetNumber = null;
            let targetCleanJid = null;
            
            // Verificar si hay mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
                targetNumber = cleanNumber(targetJid);
                targetCleanJid = getCleanJid(targetJid);
            }
            
            // Verificar si hay mensaje citado
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!targetJid && quotedMsg?.participant) {
                targetJid = quotedMsg.participant;
                targetNumber = cleanNumber(targetJid);
                targetCleanJid = getCleanJid(targetJid);
            }
            
            // Si no hay mención ni cita
            if (!targetJid) {
                return await replyWithContext(`*ᰔᩚ* Debes responder o mencionar a un usuario`);
            }
            
            // No puede promoverse a sí mismo
            const senderCleanJid = getCleanJid(senderJid);
            if (targetCleanJid === senderCleanJid) {
                return await replyWithContext(`「✰」 No puedes promoverte a ti mismo`);
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Verificar si el usuario que ejecuta el comando es administrador
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid || p.id === senderCleanJid);
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            if (!isSenderAdmin) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para poder usar este comando`);
            }
            
            // Verificar si el usuario objetivo ya es administrador
            const targetParticipant = groupMetadata.participants.find(p => p.id === targetJid || p.id === targetCleanJid);
            
            if (targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin') {
                return await replyWithContext(`「✰」 @${targetNumber} ya era administrador del grupo`, [targetCleanJid]);
            }
            
            // Intentar promover al usuario
            try {
                await sock.groupParticipantsUpdate(from, [targetCleanJid], 'promote');
                
                await replyWithContext(`《✧》 @${targetNumber} ha sido promovido a administrador del grupo`, [targetCleanJid]);
                
                console.log(`✅ Usuario ${targetNumber} promovido a admin por ${pushName || userNumber} en grupo ${from}`);
                
            } catch (error) {
                console.error('Error al promover:', error);
                
                // Verificar si el error es porque el bot no es admin
                const botJid = sock.user?.id;
                const botCleanJid = getCleanJid(botJid);
                const botParticipant = groupMetadata.participants.find(p => p.id === botJid || p.id === botCleanJid);
                const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
                
                if (!isBotAdmin) {
                    return await replyWithContext(`「✰」 ${config.nombre || config.name} debe ser administrador del grupo`);
                }
                
                return await replyWithContext(`❌ Error al promover: ${error.message}`);
            }
            
        } catch (error) {
            console.error('❌ Error en promote:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};