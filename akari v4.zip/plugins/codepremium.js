import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getPairingCodePrem, getPrem } from '../lib/prem.js';
import chalk from 'chalk';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PREMS_FILE = path.join(__dirname, '..', 'databases', 'prems.json');
const COOLDOWN_FILE = path.join(__dirname, '..', 'databases', 'code_premium_cooldown.json');

if (!fs.existsSync(path.join(__dirname, '..', 'databases'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'databases'), { recursive: true });
}

function loadPrems() {
    try {
        if (fs.existsSync(PREMS_FILE)) {
            return JSON.parse(fs.readFileSync(PREMS_FILE, 'utf8'));
        }
    } catch (e) {}
    return {};
}

function savePrems(data) {
    try {
        fs.writeFileSync(PREMS_FILE, JSON.stringify(data, null, 2));
    } catch (e) {}
}

function isTokenExpired(tokenData) {
    if (!tokenData || !tokenData.expires) return true;
    return Date.now() > tokenData.expires;
}

function loadCooldown() {
    try {
        if (fs.existsSync(COOLDOWN_FILE)) {
            return JSON.parse(fs.readFileSync(COOLDOWN_FILE, 'utf8'));
        }
    } catch (e) {}
    return {};
}

function saveCooldown(data) {
    try {
        fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
    } catch (e) {}
}

export default {
    name: 'codepremium',
    alias: [],
    description: 'Crea un bot premium',
    category: 'main',
    
    async execute(sock, msg, options) {
        try {
            const { args, replyWithContext, config, pushName, userNumber } = options;
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Debes proporcionar un token premium\n> Ejemplo: ${config.prefix}codepremium 1234AbCd`);
            }
            
            const token = args[0].trim();
            
            if (!/^[A-Za-z0-9]{8}$/.test(token)) {
                return await replyWithContext(`*ᰔᩚ* Token inválido\n> Debe tener 8 caracteres alfanuméricos`);
            }
            
            const prems = loadPrems();
            const tokenData = prems[token];
            
            if (!tokenData) {
                return await replyWithContext(`*ᰔᩚ* Token \`${token}\` no encontrado`);
            }
            
            if (isTokenExpired(tokenData)) {
                return await replyWithContext(`*ᰔᩚ* El token \`${token}\` ha expirado`);
            }
            
            // Verificar si ya está vinculado
            if (tokenData.numero && tokenData.activo) {
                const premExistente = getPrem(tokenData.numero);
                if (premExistente && premExistente.sock && premExistente.sock.user) {
                    const premNumber = tokenData.numero;
                    const premJid = `${premNumber}@s.whatsapp.net`;
                    
                    return await replyWithContext(
                        `🪷 El token \`${token}\` ya fue vinculado en @${premNumber}\n> Si crees que esto es un error o tu token fue robado contacta a soporte.`,
                        [premJid]
                    );
                } else {
                    tokenData.numero = null;
                    tokenData.activo = false;
                    savePrems(prems);
                }
            }
            
            // Cooldown
            const cooldowns = loadCooldown();
            const lastUsed = cooldowns[userNumber];
            const now = Date.now();
            const cooldownTime = 2 * 60 * 1000;
            
            if (lastUsed && (now - lastUsed) < cooldownTime) {
                const tiempoRestante = Math.ceil((cooldownTime - (now - lastUsed)) / 1000);
                const minutos = Math.floor(tiempoRestante / 60);
                const segundos = tiempoRestante % 60;
                let tiempoTexto = minutos > 0 ? `${minutos} minuto(s) y ${segundos} segundo(s)` : `${segundos} segundo(s)`;
                return await replyWithContext(`《✧》Debes esperar \`${tiempoTexto}\` para volver a intentar`);
            }
            
            const targetNumber = userNumber;
            
            if (!targetNumber || targetNumber === 'Desconocido') {
                return await replyWithContext('❌ No se pudo obtener tu número.');
            }
            
            cooldowns[userNumber] = now;
            saveCooldown(cooldowns);
            
            tokenData.numero = targetNumber;
            tokenData.activo = false;
            savePrems(prems);
            
            await replyWithContext(`ㅤᩤᩣ    𝖯𝗋𝖾𝗆-𝖡𝗈𝗍 - 𝖢𝗈𝖽𝖾ㅤ ౿ ㅤ\n> Conecta un Bot Premium\n\n❀ WhatsApp > Dispositivos vinculados > Vincular > Vincular con número > Pega el código\n\n> El código expira en 60 segundos`);
            
            console.log(chalk.cyan(`[ PREMIUM ] Usuario ${pushName} (${targetNumber}) generando código con token ${token}...`));
            
            try {
                const result = await getPairingCodePrem(targetNumber);
                
                if (result.status === 'pending') {
                    await replyWithContext(`${result.code}`);
                    
                    console.log(chalk.green(`[ PREMIUM ] Código generado para ${targetNumber}: ${result.code}`));
                    
                    let checkInterval;
                    const timeout = setTimeout(() => {
                        if (checkInterval) clearInterval(checkInterval);
                        const premsActual = loadPrems();
                        if (premsActual[token] && !premsActual[token].activo) {
                            premsActual[token].numero = null;
                            savePrems(premsActual);
                        }
                    }, 60000);
                    
                    checkInterval = setInterval(async () => {
                        const prem = getPrem(targetNumber);
                        if (prem && prem.sock && prem.sock.user) {
                            clearTimeout(timeout);
                            clearInterval(checkInterval);
                            
                            const premsActual = loadPrems();
                            if (premsActual[token]) {
                                premsActual[token].activo = true;
                                premsActual[token].numero = targetNumber;
                                savePrems(premsActual);
                            }
                            
                            await replyWithContext(`𖹭 @${userNumber} Ha conectado un nuevo Bot Premium`, [`${userNumber}@s.whatsapp.net`]);
                            console.log(chalk.green(`[ PREMIUM ] ${targetNumber} conectado por ${pushName} con token ${token}`));
                        }
                    }, 2000);
                    
                } else if (result.status === 'connected') {
                    await replyWithContext(`🌼 @${userNumber} Ya tiene un Bot Premium conectado`, [`${userNumber}@s.whatsapp.net`]);
                } else if (result.status === 'expired') {
                    const premsActual = loadPrems();
                    if (premsActual[token] && !premsActual[token].activo) {
                        premsActual[token].numero = null;
                        savePrems(premsActual);
                    }
                    await replyWithContext(`🪷 El código expiró. Usa *${config.prefix}codepremium ${token}* nuevamente.`);
                }
                
            } catch (err) {
                console.log(chalk.red(`Error: ${err.message}`));
                const premsActual = loadPrems();
                if (premsActual[token] && !premsActual[token].activo) {
                    premsActual[token].numero = null;
                    savePrems(premsActual);
                }
                await replyWithContext(`💤 Error: ${err.message}`);
            }
            
        } catch (error) {
            console.error('❌ Error en codepremium:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};