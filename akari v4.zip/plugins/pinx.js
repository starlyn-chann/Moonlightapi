import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import FormData from 'form-data';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERHASH = '0c3e78aeb2c067f3520f900de';

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'jpg';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', USERHASH);
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 60000
    });

    if (typeof res.data !== 'string' || !res.data.startsWith('https://')) {
        throw new Error('Respuesta inválida de Catbox');
    }
    return res.data;
}

export default {
    name: 'pinx',
    alias: ['pintx'],
    description: 'Sube una imagen de Pinterest a Catbox y obtén el link',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const link = args.join(' ').trim();
            
            if (!link) {
                return await replyWithContext(`❀ Debes proporcionar un enlace de Pinterest\n\n> Ejemplo: ${config.prefix}pinx https://pin.it/xxxxx`);
            }
            
            // Verificar si es un link de Pinterest
            if (!link.includes('pin.it') && !link.includes('pinterest.com') && !link.includes('pin/')) {
                return await replyWithContext(`❀ Eso no parece ser un enlace de Pinterest válido`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
            } catch (e) {}
            
            console.log(`🔗 Procesando link de Pinterest: ${link}`);
            
            // ============ OBTENER CONTENIDO DE PINTEREST ============
            const apiUrl = `https://api.nexray.web.id/downloader/pinterest?url=${encodeURIComponent(link)}`;
            
            const response = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data || !response.data.status || !response.data.result) {
                throw new Error('No se pudo obtener el contenido del link');
            }
            
            const result = response.data.result;
            const title = result.title || 'Pinterest';
            const author = result.author || 'Desconocido';
            
            // Determinar URL del media
            let mediaUrl = result.video || result.image || result.thumbnail;
            
            if (!mediaUrl) {
                throw new Error('No se encontró contenido descargable');
            }
            
            // Descargar el media
            const mediaResponse = await axios.get(mediaUrl, {
                responseType: 'arraybuffer',
                timeout: 60000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const mediaBuffer = Buffer.from(mediaResponse.data);
            
            // Determinar MIME type
            let mime = 'image/jpeg';
            const isVideo = mediaUrl.includes('.mp4') || mediaUrl.includes('.mov') || result.video;
            const isGif = mediaUrl.includes('.gif');
            
            if (isVideo) {
                mime = 'video/mp4';
            } else if (isGif) {
                mime = 'image/gif';
            } else if (mediaUrl.includes('.png')) {
                mime = 'image/png';
            } else if (mediaUrl.includes('.webp')) {
                mime = 'image/webp';
            }
            
            // Subir a Catbox
            try {
                await sock.sendMessage(from, { react: { text: '☁️', key: msg.key } });
            } catch (e) {}
            
            const catboxUrl = await uploadCatbox(mediaBuffer, mime);
            
            console.log(`✅ Imagen subida a Catbox: ${catboxUrl}`);
            
            // Crear caption
            const caption = `❀ *Pinterest - Upload* ✿\n\n` +
                           `「★」*Título* » ${title}\n` +
                           `「★」*Autor* » ${author}\n` +
                           `「★」*Tipo* » ${isVideo ? '🎬 Video' : isGif ? '🎞️ GIF' : '🖼️ Imagen'}\n` +
                           `「★」*Tamaño* » ${(mediaBuffer.length / 1024 / 1024).toFixed(2)} MB\n\n` +
                           `🔗 *Link:* ${catboxUrl}`;
            
            // Enviar resultado
            await replyWithContext(caption);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Pinterest subido a Catbox por ${pushName || userNumber}: ${title}`);
            
        } catch (error) {
            console.error('❌ Error en pinx:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❀ Se ha producido un problema.\n\n> ${error.message}`);
            } catch (e) {}
        }
    }
};