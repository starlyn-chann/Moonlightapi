import axios from 'axios';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import FormData from 'form-data';

// --- FUNCIONES DE SUBIDA ---

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadUguu(buffer) {
    const form = new FormData();
    form.append('files[]', buffer, generateUniqueFilename('image/jpeg'));
    const res = await axios.post('https://uguu.se/upload.php', form, { headers: form.getHeaders() });
    return res.data?.files?.[0]?.url;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });
    const res = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
    return res.data;
}

async function uploadAuto(buffer, mime) {
    try {
        return await uploadUguu(buffer);
    } catch {
        try {
            return await uploadCatbox(buffer, mime);
        } catch (e) {
            throw new Error('No se pudo subir la imagen a ningún servidor');
        }
    }
}

// --- COMANDO PRINCIPAL ---

export default {
    name: 'phpost',
    alias: [],
    description: 'Crea un post falso de XNXX respondiendo a una imagen',
    category: 'fun',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            // 1. Validar que responda a una imagen
            const isQuotedImage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            const isImage = msg.message?.imageMessage;
            
            if (!isImage && !isQuotedImage) {
                return await replyWithContext(`「✰」Debes responder a una imagen para generar el post.`);
            }

            // 2. Definir el título
            const title = args.length > 0 ? args.join(' ') : 'Increíble video de ' + pushName;
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}

            // 3. Descargar la imagen (ya sea directa o citada)
            const quoted = isQuotedImage ? msg.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : msg.message.imageMessage;
            
            // Reconstrucción del objeto para downloadMediaMessage
            const msgToDownload = isQuotedImage ? {
                message: { imageMessage: quoted },
                key: msg.message.extendedTextMessage.contextInfo.stanzaId 
            } : msg;

            const imageBuffer = await downloadMediaMessage(
                msgToDownload,
                'buffer',
                {},
                { logger: console, reuploadRequest: sock.updateMediaMessage }
            );

            console.log(`📸 Generando PH-Post para: ${pushName || userNumber}`);

            // 4. Subir la imagen para obtener la URL
            const imageUrl = await uploadAuto(imageBuffer, 'image/jpeg');
            
            // 5. Llamada a la API de Canvas
            const canvasApi = `https://api.siputzx.my.id/api/canvas/xnxx?title=${encodeURIComponent(title)}&image=${encodeURIComponent(imageUrl)}`;
            
            const response = await axios.get(canvasApi, {
                responseType: 'arraybuffer',
                timeout: 60000
            });
            
            // 6. Enviar resultado con diseño Premium
            await sock.sendMessage(from, {
                image: Buffer.from(response.data),
                caption: `《✧》Título: _${title}_`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || 'Meme Maker'
                    }
                }
            }, { quoted: msg });

            try {
                await sock.sendMessage(from, { react: { text: '✨', key: msg.key } });
            } catch (e) {}
            
        } catch (error) {
            console.error('❌ Error en phpost:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`♡ Error al generar la imagen: ${error.message}`);
            } catch (e) {}
        }
    }
};