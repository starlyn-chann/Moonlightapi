import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function getBotConfigPath(sock) {
    let botNumber = '';
    if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    
    if (!botNumber) return null;
    
    const subBotPath = path.join(process.cwd(), 'subs', botNumber, 'config.js');
    if (fs.existsSync(subBotPath)) {
        return { path: subBotPath, type: 'sub-bot', number: botNumber };
    }
    
    const mainPath = path.join(process.cwd(), 'config.js');
    if (fs.existsSync(mainPath)) {
        return { path: mainPath, type: 'main', number: botNumber };
    }
    
    return null;
}

export default {
    name: 'setchannel',
    alias: ['setcanal'],
    description: 'Cambia el nombre del canal del bot (solo dueño del bot)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, userNumber, senderNumber } = options;
            
            const userNumberClean = cleanNumber(senderNumber || userNumber || '');
            const botownerClean = config.botowner ? cleanNumber(config.botowner) : '';
            
            if (!botownerClean || userNumberClean !== botownerClean) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede cambiar el nombre del canal*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」Debes proporcionar un nombre\n> *Uso correcto:* ${config.prefix}setchannel Nuevo nombre del canal`);
            }
            
            let newName = args.join(' ');
            if (newName.startsWith('+')) newName = newName.substring(1).trim();
            if (!newName || newName.length === 0) {
                return await replyWithContext(`*ᰔᩚ* *El nombre del canal no puede estar vacío*`);
            }
            if (newName.length > 50) {
                return await replyWithContext(`*ᰔᩚ* *El nombre del canal es demasiado largo*\n> Máximo 50 caracteres`);
            }
            
            const botConfig = getBotConfigPath(sock);
            if (!botConfig) {
                throw new Error('No se pudo encontrar la configuración del bot');
            }
            
            const configPath = botConfig.path;
            
            if (!fs.existsSync(configPath)) {
                throw new Error(`No se encontró configuración en: ${configPath}`);
            }
            
            let configContent = fs.readFileSync(configPath, 'utf8');
            const canalNombreRegex = /(canalNombre:\s*['"])([^'"]*)(['"])/;
            const match = configContent.match(canalNombreRegex);
            
            let newConfigContent;
            if (!match) {
                const canalIdRegex = /(canalId:\s*['"][^'"]+['"])/;
                if (canalIdRegex.test(configContent)) {
                    newConfigContent = configContent.replace(canalIdRegex, `$1,\n  canalNombre: '${newName}'`);
                } else {
                    throw new Error('No se encontró el campo canalId en la configuración');
                }
            } else {
                newConfigContent = configContent.replace(canalNombreRegex, `$1${newName}$3`);
            }
            
            fs.writeFileSync(configPath, newConfigContent, 'utf8');
            
            if (options.config) options.config.canalNombre = newName;
            
            await replyWithContext(`《✧》Nombre del canal actualizado a: *${newName}*`);
            
        } catch (error) {
            console.error('Error en setchannel:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};