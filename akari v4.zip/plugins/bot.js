import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ruta para guardar el estado del bot en cada grupo
const BOT_STATUS_FILE = path.join(__dirname, '..', 'data', 'bot_status.json');

// Asegurar que la carpeta data exista
if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

// Cargar estados de los bots
function loadBotStatus() {
    try {
        if (fs.existsSync(BOT_STATUS_FILE)) {
            const data = fs.readFileSync(BOT_STATUS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando estados de bots:', error);
    }
    return {};
}

// Guardar estados de los bots
function saveBotStatus(status) {
    try {
        fs.writeFileSync(BOT_STATUS_FILE, JSON.stringify(status, null, 2));
        return true;
    } catch (error) {
        console.error('Error guardando estados de bots:', error);
        return false;
    }
}

// Función para verificar si el bot está activo en un grupo
function isBotActive(groupId) {
    const status = loadBotStatus();
    return status[groupId] !== false; // Por defecto activo (true)
}

// Función para cambiar el estado del bot en un grupo
function setBotStatus(groupId, active) {
    const status = loadBotStatus();
    status[groupId] = active;
    saveBotStatus(status);
    return true;
}

export default {
    name: 'bot',
    alias: [],
    description: 'Activa o desactiva el bot en el grupo (solo administradores)',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, senderJid, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Verificar si el usuario es administrador
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid);
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            const isOwner = config.owner?.some(owner => owner.replace(/\D/g, '') === userNumber);
            
            if (!isSenderAdmin && !isOwner) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para usar este comando`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `*ᰔᩚ* Debes proporcionar on/off\n` +
                    `> » *${config.prefix}bot on* (Activar)\n` +
                    `> » *${config.prefix}bot off* (Desactivar)`
                );
            }
            
            const action = args[0].toLowerCase();
            const botName = config.nombre || config.name || 'Bot';
            const currentStatus = isBotActive(from);
            
            if (action === 'on') {
                if (currentStatus) {
                    return await replyWithContext(`ꕤ *${botName}* ya estaba activado`);
                }
                setBotStatus(from, true);
                return await replyWithContext(`❀ Se ha activado a *${botName}*`);
                
            } else if (action === 'off') {
                if (!currentStatus) {
                    return await replyWithContext(`ꕤ *${botName}* ya estaba apagado`);
                }
                setBotStatus(from, false);
                return await replyWithContext(`❀ Se ha desactivado a *${botName}*`);
                
            } else {
                return await replyWithContext(
                    `*ᰔᩚ* Debes proporcionar on/off\n` +
                    `> » *${config.prefix}bot on* (Activar)\n` +
                    `> » *${config.prefix}bot off* (Desactivar)`
                );
            }
            
        } catch (error) {
            console.error('❌ Error en bot:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};