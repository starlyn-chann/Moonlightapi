export default {
    name: 'creador',
    alias: ['owner', 'dueño'],
    description: 'Muestra información del creador del bot',
    category: 'main',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const infoText = `𖥔ׂ໋߲ 𑂴⛩⵿ฺ໋᪲࠭✦ᜒฺִּ໋፞۫ 𝙉𝙖𝙢𝙚 » *⭐̷̸ۜあ゚ 𝓢𝓽𝓪𝓻𝓵𝔂𝓷𖹭𑂳ׄ ᮫ׅ⢎*
𖥔ׂ໋߲ 𑂴⛩⵿ฺ໋᪲࠭✦ᜒฺִּ໋፞۫ 𝙂𝙚𝙣𝙙𝙚𝙧 » *Hombre*
𖥔ׂ໋߲ 𑂴⛩⵿ฺ໋᪲࠭✦ᜒฺִּ໋፞۫ 𝙄𝙜 » *kob.danonino*
𖥔ׂ໋߲ 𑂴⛩⵿ฺ໋᪲࠭✦ᜒฺִּ໋፞۫ 𝙏𝙞𝙠𝙏𝙤𝙠 » *kob.danonino*
𖥔ׂ໋߲ 𑂴⛩⵿ฺ໋᪲࠭✦ᜒฺִּ໋፞۫ 𝙉𝙪𝙢𝙗𝙚𝙧 » *+52 999 204 2946*
𖥔ׂ໋߲ 𑂴⛩⵿ฺ໋᪲࠭✦ᜒฺִּ໋፞۫ 𝘾𝙝𝙖𝙣𝙣𝙚𝙡 » *https://whatsapp.com/channel/0029VbCYdHfK0IBjVgKNvM1e*`;
            
            const buttons = [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Instagram",
                        url: "https://www.instagram.com/kob.danonino?igsh=djJid2djZzVrb2Zs",
                        merchant_url: "https://www.instagram.com/kob.danonino?igsh=djJid2djZzVrb2Zs"
                    })
                },
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "TikTok",
                        url: "https://www.tiktok.com/@kob.danonino?_r=1&_t=ZS-96THhC3yNRS",
                        merchant_url: "https://www.tiktok.com/@kob.danonino?_r=1&_t=ZS-96THhC3yNRS"
                    })
                }
            ];
            
            await sock.sendMessage(from, {
                text: infoText,
                footer: "Developer",
                interactiveButtons: buttons,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            console.log(`📱 Información del creador mostrada a ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en creador:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};