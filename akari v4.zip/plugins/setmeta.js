import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const METADATA_FILE = path.join(__dirname, '..', 'data', 'metadata.json');

// Asegurar que el archivo existe
if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}
if (!fs.existsSync(METADATA_FILE)) {
    fs.writeFileSync(METADATA_FILE, JSON.stringify({}, null, 2));
}

function loadMetadata() {
    try {
        const data = fs.readFileSync(METADATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveMetadata(metadata) {
    fs.writeFileSync(METADATA_FILE, JSON.stringify(metadata, null, 2));
}

export default {
    name: 'setmeta',
    alias: [],
    description: 'Establece el packname y author para tus stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, userNumber, pushName } = options;
            
            if (!args || args.length === 0) {
                return await replyWithContext(`❀ Por favor, ingresa los metadatos que deseas asignar a tus stickers.\n\n> Ejemplo: ${config.prefix}setmeta Mi Pack | Mi Autor`);
            }
            
            const fullArgs = args.join(' ');
            const [metadatos01, metadatos02] = fullArgs.split('|').map(meta => meta.trim());
            
            const metadata = loadMetadata();
            metadata[userNumber] = {
                packname: metadatos01 || '',
                author: metadatos02 || '',
                updatedAt: new Date().toISOString()
            };
            saveMetadata(metadata);
            
            await replyWithContext(`✅ Los metadatos de tus stickers se han actualizado correctamente.\n\n> *Pack:* ${metadatos01 || 'Sin pack'}\n> *Autor:* ${metadatos02 || 'Sin autor'}`);
            
            console.log(`✅ Metadatos actualizados para ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en setmeta:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};