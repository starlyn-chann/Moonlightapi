import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SALES_FILE = path.join(__dirname, '..', 'data', 'sales.json');

function loadSales() {
    try {
        if (fs.existsSync(SALES_FILE)) {
            const data = fs.readFileSync(SALES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando ventas:', e);
    }
    return {};
}

function saveSales(sales) {
    try {
        fs.writeFileSync(SALES_FILE, JSON.stringify(sales, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando ventas:', e);
        return false;
    }
}

export default {
    name: 'removesale',
    alias: ['removerventa', 'deletesale', 'eliminarventa'],
    description: 'Eliminar un personaje de la venta',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando removesale...');
            
            const { config, replyWithContext, args, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes especificar un personaje para eliminar.\n> Ejemplo: ${config.prefix}removesale Goku`
                );
            }
            
            const nombrePersonaje = args.join(' ').trim();
            
            // ============ BUSCAR EN VENTAS ============
            const sales = loadSales();
            
            if (!sales[from] || Object.keys(sales[from]).length === 0) {
                return await replyWithContext(`ꕥ No hay personajes en venta en este grupo.`);
            }
            
            let idEncontrado = null;
            let ventaEncontrada = null;
            
            for (const [id, venta] of Object.entries(sales[from])) {
                if (venta.nombre.toLowerCase() === nombrePersonaje.toLowerCase()) {
                    idEncontrado = id;
                    ventaEncontrada = venta;
                    break;
                }
            }
            
            if (!ventaEncontrada) {
                return await replyWithContext(`ꕥ No se encontró el personaje *${nombrePersonaje}* en venta.`);
            }
            
            // ============ VERIFICAR QUE SEA EL VENDEDOR ============
            if (ventaEncontrada.usuario !== userNumber) {
                return await replyWithContext(`ꕥ *${ventaEncontrada.nombre}* no está a la venta por ti.`);
            }
            // ================================================================
            
            // ============ ELIMINAR DE VENTAS ============
            delete sales[from][idEncontrado];
            saveSales(sales);
            // ================================================================
            
            await replyWithContext(`❀ *${ventaEncontrada.nombre}* ha sido eliminado de la lista de ventas.`);
            
            console.log(`✅ removesale ejecutado: ${pushName || userNumber} eliminó ${ventaEncontrada.nombre} de ventas`);
            
        } catch (error) {
            console.error('❌ Error en removesale:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};