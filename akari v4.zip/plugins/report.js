export default {
    name: 'report',
    alias: ['reportar', 'reporte'],
    description: 'Envía un reporte al staff',
    category: 'soporte',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, isGroup, senderJid } = options;
            const from = msg.key.remoteJid;
            const reporte = args.join(' ').trim();
            
            if (!reporte) {
                return await replyWithContext(`「✰」 Debes escribir un reporte\n> Ejemplo: ${config.prefix}report El comando play no funciona`);
            }
            
            const TARGET_GROUP = '120363407835993121@g.us';
            
            let groupName = 'Chat privado';
            let groupId = from;
            
            if (isGroup) {
                try {
                    const groupMetadata = await sock.groupMetadata(from);
                    groupName = groupMetadata.subject || 'Sin nombre';
                } catch (e) {}
            }
            
            const fecha = new Date();
            const fechaFormateada = fecha.toLocaleString('es-ES', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            const senderNumber = userNumber || (senderJid ? senderJid.split('@')[0] : 'Desconocido');
            const senderName = pushName || 'Usuario';
            
            const reportMessage = `𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Reporte:* ${reporte}
𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Enviado por:* ${senderName}
𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Número:* ${senderNumber}
𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Tag:* @${senderNumber}
𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Grupo:* ${groupName}
𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Grupo Id:* ${groupId}
𖥔᳝݁݁⚡᩠݂݂᪲𖥔ׅ݁݁ *Fecha:* ${fechaFormateada}`;
            
            let enviado = false;
            
            if (global.principalBot && global.principalBot.sendMessage) {
                try {
                    await global.principalBot.sendMessage(TARGET_GROUP, {
                        text: reportMessage,
                        mentions: [`${senderNumber}@s.whatsapp.net`],
                        contextInfo: {
                            mentionedJid: [`${senderNumber}@s.whatsapp.net`],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    });
                    enviado = true;
                    console.log(`✅ Reporte enviado por bot principal a ${TARGET_GROUP}`);
                } catch (err) {
                    console.log('Error con bot principal:', err.message);
                }
            }
            
            if (!enviado) {
                try {
                    await sock.sendMessage(TARGET_GROUP, {
                        text: reportMessage,
                        mentions: [`${senderNumber}@s.whatsapp.net`],
                        contextInfo: {
                            mentionedJid: [`${senderNumber}@s.whatsapp.net`],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    });
                    enviado = true;
                    console.log(`✅ Reporte enviado por bot actual a ${TARGET_GROUP}`);
                } catch (err) {
                    console.log('Error con bot actual:', err.message);
                }
            }
            
            if (enviado) {
                await replyWithContext(`「✰」 Tu reporte se ha enviado con éxito.\n> El reporte puede tomar tiempo en ser revisado ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`);
            } else {
                await replyWithContext(`❌ No se pudo enviar tu reporte. Asegúrate de que el bot esté en el grupo de reportes.`);
            }
            
        } catch (error) {
            console.error('❌ Error en report:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};