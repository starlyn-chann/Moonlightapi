import axios from 'axios';

// API ÚNICA: Delirius
const API_DELIRIUS = 'https://api.delirius.store/download/threads';

export default {
    name: 'threads',
    alias: ['th'],
    description: 'Descarga contenido (videos/imágenes) de Threads',
    category: 'download',

    async execute(sock, msg, options) {
        try {
            const { config, args, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const url = args.join(' ').trim();

            if (!url) {
                return await replyWithContext(`「✰」Debes proporcionar un link de Threads\n> Ejemplo: ${config.prefix}threads https://www.threads.net/...`);
            }

            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}

            // --- 1. LLAMAR A LA API DE DELIRIUS ---
            let mediaItems = [];
            let postInfo = {};

            try {
                const response = await axios.get(`${API_DELIRIUS}?url=${encodeURIComponent(url)}`, {
                    timeout: 30000,
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                });

                if (!response.data?.status || !response.data?.data) {
                    throw new Error('Respuesta inválida de la API');
                }

                const result = response.data.data;
                
                // Extraer información de la publicación
                postInfo = {
                    author: result.full_name || result.username || 'Usuario',
                    username: result.username || '',
                    likes: result.like || 0,
                    create_at: result.taken_at || '',
                    avatar: result.profile_pic_url || '',
                    description: result.description || '',
                    verified: result.verified || false,
                    media_count: result.media_count || 0,
                    media_type: result.media_type || 'unknown'
                };

                // Extraer URLs de medios (imágenes/videos)
                if (result.media && Array.isArray(result.media)) {
                    mediaItems = result.media.map(item => ({ 
                        url: item.url, 
                        type: item.type || (item.url.includes('.mp4') ? 'video' : 'image')
                    }));
                }

                if (mediaItems.length === 0) {
                    throw new Error('No se encontraron medios en la respuesta');
                }

                console.log(`✅ API Delirius: ${mediaItems.length} medios encontrados`);

            } catch (apiError) {
                console.error('❌ Error con API Delirius:', apiError.message);
                throw new Error(`No se pudo obtener el contenido: ${apiError.message}`);
            }

            // --- 2. DESCARGAR Y PREPARAR CARDS ---
            const cards = [];
            let downloadedCount = 0;

            for (let i = 0; i < mediaItems.length; i++) {
                try {
                    const media = mediaItems[i];
                    let mediaBuffer = null;
                    let mediaType = media.type;

                    // Si el tipo no está definido, intentar adivinarlo por la extensión de la URL
                    if (!mediaType) {
                        mediaType = media.url.includes('.mp4') ? 'video' : 'image';
                    }

                    // Descargar el archivo (imagen o video)
                    const fileResponse = await axios.get(media.url, {
                        responseType: 'arraybuffer',
                        timeout: 30000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    mediaBuffer = Buffer.from(fileResponse.data);

                    if (!mediaBuffer) continue;

                    // Formatear fecha si existe
                    let fechaFormateada = 'Desconocido';
                    if (postInfo.create_at) {
                        const fecha = new Date(postInfo.create_at);
                        fechaFormateada = fecha.toLocaleString('es-ES', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                    }

                    // Determinar la información a mostrar en la card
                    let title = `Contenido ${i + 1} de ${mediaItems.length}`;
                    let body = ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Autor:* ${postInfo.author}\n`;
                    body += postInfo.username ? ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Usuario:* @${postInfo.username}\n` : '';
                    body += postInfo.description ? ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Descripción:* ${postInfo.description.substring(0, 100)}${postInfo.description.length > 100 ? '...' : ''}\n` : '';
                    body += ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Publicado:* ${fechaFormateada}\n`;
                    body += ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Likes:* ${postInfo.likes.toLocaleString() || 0}\n`;
                    if (postInfo.verified) body += ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Verificado*\n`;
                    
                    if (mediaType === 'video') {
                        title = ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ Video ${i + 1}`;
                        body += `\n 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Tipo:* Video`;
                    } else {
                        title = ` 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ Imagen ${i + 1}`;
                        body += `\n 𐴏ׂ𝅼͚ᨗ᪲🌸۪࣪ *Tipo:* Imagen`;
                    }

                    // Crear la card (usando imagen o video)
                    cards.push({
                        [mediaType === 'video' ? 'video' : 'image']: mediaBuffer,
                        title: `🍬 ${title}`,
                        body: body,
                        footer: `© Moonlight Staff`
                    });
                    downloadedCount++;

                } catch (err) {
                    console.error(`Error descargando medio ${i + 1}:`, err.message);
                }
            }

            if (cards.length === 0) {
                throw new Error('No se pudo descargar ningún archivo multimedia');
            }

            // --- 3. ENVIAR RESULTADOS COMO CARRUSEL (CARDS) ---
            await sock.sendMessage(from, {
                text: `🍬 *Contenido descargado*`,
                title: '🌺 THREADS CARRUSEL',
                subtitle: `${downloadedCount} elementos disponibles`,
                footer: 'Moonlight Staff',
                cards: cards
            }, { quoted: msg });

            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

            console.log(`✅ Threads procesado por ${pushName || userNumber} - ${downloadedCount} archivos`);

        } catch (error) {
            console.error('❌ Error en threads:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `❌ *Error:* ${error.message}`;
            if (error.response?.status === 400 || error.message.includes('expirado') || error.message.includes('URL')) {
                errorMsg += `\n\n⚠️ El enlace proporcionado no es válido o ha expirado. Por favor, verifica el link e intenta de nuevo.`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};