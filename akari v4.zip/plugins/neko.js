import axios from 'axios';

export default {
    name: 'neko',
    alias: [],
    description: 'Envía imágenes aleatorias de nekos',
    category: 'image',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber, args } = options;
            const from = msg.key.remoteJid;
            
            // Tipos de neko disponibles
            const nekoTypes = [
                'neko', 'husbando', 'kitsune', 'waifu',
                'cuddle', 'hug', 'kiss', 'pat', 'smug',
                'bonk', 'blush', 'smile', 'wave', 'handhold',
                'nom', 'bite', 'glomp', 'slap', 'kill',
                'happy', 'wink', 'poke', 'dance', 'cringe'
            ];

            let type = 'neko'; // Por defecto
            
            // Verificar si se especificó un tipo
            if (args && args[0]) {
                const requestedType = args[0].toLowerCase();
                if (nekoTypes.includes(requestedType)) {
                    type = requestedType;
                }
            }

            // Determinar categoría (sfw por defecto)
            let category = 'sfw';
            if (args && args[1] && (args[1].toLowerCase() === 'nsfw' || args[1].toLowerCase() === '+18')) {
                category = 'nsfw';
            }

            // Obtener neko aleatoria
            const response = await axios({
                method: 'GET',
                url: `https://nekos.life/api/v2/img/${type}`,
                timeout: 10000
            });

            const imageUrl = response.data?.url;

            if (!imageUrl) {
                throw new Error('No se pudo obtener la imagen');
            }

            // Descargar imagen
            const imageResponse = await axios({
                method: 'GET',
                url: imageUrl,
                responseType: 'arraybuffer',
                timeout: 15000
            });

            const imageBuffer = Buffer.from(imageResponse.data);

            // Preparar caption
            const caption = `> *Neko para ${pushName || userNumber || 'ti'}* ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`;

            // Enviar imagen
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: caption,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            console.log(`✅ Neko enviada a ${pushName || userNumber} (${type})`);

        } catch (error) {
            console.error("❌ Error en neko:", error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`🥕 Ocurrió un error obteniendo neko.\n> Error: ${error.message}`);
            } catch (e) {}
        }
    }
};