import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { obtenerPacksUsuario } from '../lib/mongoose.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'getpack',
    alias: ['pack', 'verpack'],
    description: 'Obtiene un pack de stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            const args = options.args || [];
            const packName = args.join(' ').trim();
            
            if (!packName) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre del pack\n> Ejemplo: ${config.prefix}getpack Mis Stickers`);
            }
            
            // Obtener packs desde MongoDB
            const packs = await obtenerPacksUsuario(userNumber);
            
            if (!packs || packs.length === 0) {
                return await replyWithContext(`「✰」No tienes ningún pack creado\n> Usa ${config.prefix}newpack para crear uno`);
            }
            
            let pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (!pack) {
                return await replyWithContext(`「✰」No tienes un pack llamado "${packName}"\n> Usa ${config.prefix}packlist para ver tus packs`);
            }
            
            if (!pack.stickers || pack.stickers.length < 4) {
                return await replyWithContext(`「✰」El pack "${pack.name}" no tiene suficientes stickers (mínimo 4)\n> Agrega stickers con ${config.prefix}addsticker ${pack.name}`);
            }
            
            // Validar stickers
            const validStickers = pack.stickers.map(s => {
                try {
                    if (s.buffer) {
                        return Buffer.from(s.buffer, 'base64');
                    }
                    return null;
                } catch {
                    return null;
                }
            }).filter(s => s && Buffer.isBuffer(s) && s.length > 0);
            
            if (validStickers.length < 4) {
                return await replyWithContext(`「✰」Algunos stickers del pack están corruptos\n> Intenta agregarlos nuevamente`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📦', key: msg.key } });
            } catch (e) {}
            
            const MAX_STICKERS = 50;
            const selected = validStickers.slice(0, MAX_STICKERS);
            const cover = selected[0];
            
            const webp = await import('node-webpmux');
            
            // Procesar stickers
            const stickerResults = await Promise.all(selected.map(async (buffer, index) => {
                try {
                    const img = new webp.default.Image();
                    await img.load(buffer);
                    
                    const json = { 
                        'sticker-pack-id': `https://github.com/Moonlight-Bot/${pack.id || Date.now()}`, 
                        'sticker-pack-name': pack.name, 
                        'sticker-pack-publisher': pack.author || 'Moonlight Bot', 
                        emojis: ['✨'] 
                    };
                    
                    const exifAttr = Buffer.from([0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
                    const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8');
                    const exif = Buffer.concat([exifAttr, jsonBuff]);
                    exif.writeUIntLE(jsonBuff.length, 14, 4);
                    img.exif = exif;
                    
                    const tmpOut = path.join(process.cwd(), 'temp', `pack-sticker-${Date.now()}-${Math.random().toString(36).slice(2)}.webp`);
                    
                    // Asegurar que temp existe
                    const tempDir = path.join(process.cwd(), 'temp');
                    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
                    
                    await img.save(tmpOut);
                    const stickerBuf = fs.readFileSync(tmpOut);
                    fs.unlinkSync(tmpOut);
                    
                    return { sticker: stickerBuf, isAnimated: false, isLottie: false, emojis: ['✨'] };
                } catch (e) {
                    console.error('Error procesando sticker:', e.message);
                    // Si falla el procesamiento, usar el buffer original
                    return { sticker: buffer, isAnimated: false, isLottie: false, emojis: ['✨'] };
                }
            }));
            
            // Enviar pack
            await sock.sendMessage(from, { 
                stickerPack: { 
                    name: pack.name, 
                    publisher: `𝘔𝘢𝘥𝘦 𝘸𝘪𝘵𝘩 ❤️ | 𝘔𝘰𝘰𝘯𝘭𝘪𝘨𝘩𝘵 𝘚𝘵𝘢𝘧𝘧`, 
                    description: pack.desc || `Paquete de stickers creado por ${pushName || userNumber}`,
                    cover: cover, 
                    stickers: stickerResults 
                } 
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Pack "${pack.name}" enviado por ${pushName || userNumber} - ${selected.length} stickers`);
            
        } catch (error) {
            console.error('❌ Error en getpack:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};