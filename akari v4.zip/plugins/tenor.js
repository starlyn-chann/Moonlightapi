import axios from 'axios';

export default {
    name: 'tenor',
    alias: ['gif', 'buscar'],
    description: 'Busca GIFs animados en Tenor',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const busqueda = args.join(' ').trim();
            
            if (!busqueda) {
                return await replyWithContext(`[ ★ ] Debes proporcionar una búsqueda\n\n> Ejemplo: ${config.prefix}tenor gatos`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            const response = await axios.get(`https://api.delirius.store/search/tenor?q=${encodeURIComponent(busqueda)}`, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.status || !response.data?.data || response.data.data.length === 0) {
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return await replyWithContext(`[ ★ ] No se encontraron resultados para *${busqueda}*`);
            }
            
            // Mezclar resultados aleatoriamente
            const shuffled = response.data.data.sort(() => Math.random() - 0.5);
            const resultados = shuffled.slice(0, 10);
            
            let enviados = 0;
            
            for (let i = 0; i < resultados.length; i++) {
                const item = resultados[i];
                const videoUrl = item.mp4;
                
                if (!videoUrl) continue;
                
                try {
                    const videoResponse = await axios.get(videoUrl, {
                        responseType: 'arraybuffer',
                        timeout: 30000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const videoBuffer = Buffer.from(videoResponse.data);
                    
                    const caption = `[ ★ ] *Título* » ${item.title}\n` +
                                   `[ ★ ] *Creado* » ${item.created || 'Desconocido'}\n` +
                                   `[ ★ ] *Resultado* » ${i + 1}/${resultados.length}`;
                    
                    await sock.sendMessage(from, {
                        video: videoBuffer,
                        mimetype: 'video/mp4',
                        gifPlayback: true,
                        caption: caption,
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    enviados++;
                    
                } catch (error) {
                    console.log(`⚠️ Error descargando GIF ${i + 1}: ${error.message}`);
                }
            }
            
            if (enviados === 0) {
                return await replyWithContext(`[ ★ ] No se pudieron cargar los GIFs para *${busqueda}*`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Tenor: ${enviados} GIFs de "${busqueda}" enviados a ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en tenor:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`[ ★ ] Error al buscar: ${error.message}`);
            } catch (e) {}
        }
    }
};