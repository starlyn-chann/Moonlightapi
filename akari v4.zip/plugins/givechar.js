import { 
    obtenerPersonajePorNombre, 
    obtenerPersonajePorId,
    verificarReclamo,
    obtenerPersonajesReclamados,
    reclamarPersonaje,
    eliminarReclamo,
    obtenerTodosPersonajes
} from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

function getDisplayName(number) {
    const users = loadUsersDb();
    const user = users.find(u => u.number === number);
    return user ? user.pushName : number;
}

export default {
    name: 'givechar',
    alias: ['givewaifu', 'regalar', 'gift'],
    description: 'Regala un personaje a otro usuario',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando givechar...');
            
            const { config, replyWithContext, args, userNumber, senderJid, pushName, quotedMsg, quotedMessage } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes escribir el nombre del personaje y citar o mencionar al usuario que lo recibirá\n> Ejemplo: ${config.prefix}givechar Goku @usuario`
                );
            }
            
            // ============ OBTENER USUARIO DESTINO ============
            let targetNumber = null;
            let targetJid = null;
            
            // Verificar si hay mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (mentionedJid) {
                targetJid = mentionedJid;
                targetNumber = cleanNumber(mentionedJid);
            } else if (quotedMsg && quotedMessage) {
                const quotedParticipant = quotedMsg?.participant || quotedMsg?.remoteJid;
                if (quotedParticipant) {
                    targetJid = quotedParticipant;
                    targetNumber = cleanNumber(quotedParticipant);
                }
            }
            
            if (!targetNumber) {
                return await replyWithContext(
                    `❀ Debes mencionar o citar al usuario que recibirá el personaje.\n> Ejemplo: ${config.prefix}givechar Goku @usuario`
                );
            }
            
            if (targetNumber === userNumber) {
                return await replyWithContext(`ꕥ No puedes regalarte un personaje a ti mismo.`);
            }
            // ================================================================
            
            // ============ OBTENER NOMBRE DEL PERSONAJE ============
            let nombrePersonaje = '';
            if (mentionedJid) {
                const textoSinMencion = args.join(' ').replace(`@${targetNumber}`, '').trim();
                nombrePersonaje = textoSinMencion;
            } else {
                nombrePersonaje = args.join(' ').trim();
            }
            
            if (!nombrePersonaje) {
                return await replyWithContext(`❀ Debes especificar el nombre del personaje a regalar.`);
            }
            // ================================================================
            
            // ============ BUSCAR PERSONAJE ============
            let personaje = await obtenerPersonajePorNombre(nombrePersonaje);
            
            if (!personaje) {
                const palabras = nombrePersonaje.trim().split(/\s+/);
                if (palabras.length > 1) {
                    const nombreInvertido = palabras.reverse().join(' ');
                    personaje = await obtenerPersonajePorNombre(nombreInvertido);
                }
            }
            
            if (!personaje) {
                const todos = await obtenerTodosPersonajes();
                const nombreLower = nombrePersonaje.toLowerCase();
                
                for (const pj of todos) {
                    const pjNombreLower = pj.nombre.toLowerCase();
                    if (pjNombreLower.includes(nombreLower) || nombreLower.includes(pjNombreLower)) {
                        personaje = pj;
                        break;
                    }
                }
            }
            
            if (!personaje) {
                return await replyWithContext(`ꕥ No se encontró el personaje *${nombrePersonaje}*.`);
            }
            // ================================================================
            
            // ============ VERIFICAR QUE EL PERSONAJE ESTÉ RECLAMADO POR EL USUARIO ============
            const reclamados = await obtenerPersonajesReclamados(from, userNumber);
            const reclamo = reclamados.find(r => r.personajeId === personaje.id);
            
            if (!reclamo) {
                return await replyWithContext(`ꕥ *${personaje.nombre}* no está reclamado por ti.`);
            }
            // ================================================================
            
            // ============ REALIZAR TRANSFERENCIA ============
            // Eliminar reclamo del usuario actual
            await eliminarReclamo(from, personaje.id);
            
            // Crear reclamo para el usuario destino
            await reclamarPersonaje(from, personaje.id, targetNumber);
            
            const senderName = getDisplayName(userNumber);
            const receiverName = getDisplayName(targetNumber);
            // ================================================================
            
            // ============ MENSAJE DE ÉXITO ============
            const mensaje = `❀ *${personaje.nombre}* ha sido regalado a *${receiverName}* por *${senderName}*.`;
            
            await replyWithContext(mensaje, [targetJid]);
            // ================================================================
            
            console.log(`✅ givechar ejecutado: ${senderName} → ${receiverName} (${personaje.nombre})`);
            
        } catch (error) {
            console.error('❌ Error en givechar:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};