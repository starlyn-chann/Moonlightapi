import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CLAIM_MSG_FILE = path.join(__dirname, '..', 'data', 'claim_messages.json');

function loadClaimMessages() {
    try {
        if (fs.existsSync(CLAIM_MSG_FILE)) {
            const data = fs.readFileSync(CLAIM_MSG_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de claim:', e);
    }
    return {};
}

function saveClaimMessages(messages) {
    try {
        fs.writeFileSync(CLAIM_MSG_FILE, JSON.stringify(messages, null, 2), 'utf8');
        return true;
    } catch (error) {
        console.error('Error guardando mensajes de claim:', error);
        return false;
    }
}

export default {
    name: 'setclaim',
    alias: ['setclaimmsg'],
    description: 'Modificar el mensaje al reclamar un personaje',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando setclaim...');
            
            const { config, replyWithContext, args, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes especificar un mensaje para reclamar un personaje.\n> Ejemplo:\n> ${config.prefix}setclaim $user ha reclamado el personaje $character`
                );
            }
            
            const customMsg = args.join(' ');
            
            if (!customMsg.includes('$user') || !customMsg.includes('$character')) {
                return await replyWithContext(
                    `ꕥ Tu mensaje debe incluir *$user* y *$character* para que funcione correctamente.`
                );
            }
            
            // Guardar mensaje personalizado
            const messages = loadClaimMessages();
            messages[userNumber] = customMsg;
            saveClaimMessages(messages);
            
            await replyWithContext(
                `❀ Mensaje de reclamación modificado.`
            );
            
            console.log(`✅ setclaim ejecutado por ${pushName || userNumber}: ${customMsg}`);
            
        } catch (error) {
            console.error('❌ Error en setclaim:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};