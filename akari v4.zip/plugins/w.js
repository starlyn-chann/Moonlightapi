import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function saveTimers(timers) {
    try {
        fs.writeFileSync(TIMER_FILE, JSON.stringify(timers, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando timeeconomy:', e);
        return false;
    }
}

function getTimerKey(userNumber, groupId) {
    return `work_${userNumber}_${groupId}`;
}

export default {
    name: 'w',
    alias: ['work'],
    description: 'Trabaja y gana dinero en el grupo',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const timerKey = getTimerKey(userNumber, from);
            const now = Date.now();
            const cooldownTime = 3 * 60 * 1000;
            
            let timers = loadTimers();
            
            if (timers[timerKey]) {
                const lastUsed = timers[timerKey];
                const tiempoRestante = cooldownTime - (now - lastUsed);
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.floor((tiempoRestante % 60000) / 1000);
                    return await replyWithContext(`❀ *Espera un poco*\n> Puedes trabajar de nuevo en ${minutos}m ${segundos}s`);
                }
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const ganancia = Math.floor(Math.random() * (3000 - 10 + 1)) + 10;
            
            const trabajos = [
                'Trabajaste como desarrollador web',
                'Trabajaste como diseñador gráfico',
                'Trabajaste como escritor creativo',
                'Trabajaste como profesor de matemáticas',
                'Trabajaste como enfermero en un hospital',
                'Trabajaste como ingeniero civil',
                'Trabajaste como chef en un restaurante',
                'Trabajaste como fotógrafo profesional',
                'Trabajaste como músico callejero',
                'Trabajaste como actor de teatro',
                'Trabajaste como periodista deportivo',
                'Trabajaste como arquitecto de casas',
                'Trabajaste como piloto de avión',
                'Trabajaste como bombero voluntario',
                'Trabajaste como policía de tránsito',
                'Trabajaste como abogado defensor',
                'Trabajaste como contador de empresas',
                'Trabajaste como psicólogo clínico',
                'Trabajaste como veterinario de mascotas',
                'Trabajaste como electricista industrial',
                'Trabajaste como plomero de emergencias',
                'Trabajaste como carpintero de muebles',
                'Trabajaste como pintor de casas',
                'Trabajaste como jardinero paisajista',
                'Trabajaste como repartidor de comida',
                'Trabajaste como taxista nocturno',
                'Trabajaste como camarero en un bar',
                'Trabajaste como guardia de seguridad',
                'Trabajaste como mecánico de autos',
                'Trabajaste como barbero',
                'Trabajaste como estilista de moda',
                'Trabajaste como entrenador personal',
                'Trabajaste como nutricionista',
                'Trabajaste como farmacéutico',
                'Trabajaste como dentista',
                'Trabajaste como fisioterapeuta',
                'Trabajaste como conductor de autobús',
                'Trabajaste como mensajero',
                'Trabajaste como albañil',
                'Trabajaste como soldador',
                'Trabajaste como herrero',
                'Trabajaste como joyero',
                'Trabajaste como relojero',
                'Trabajaste como cerrajero',
                'Trabajaste como vidriero',
                'Trabajaste como tapicero',
                'Trabajaste como decorador de interiores',
                'Trabajaste como florista',
                'Trabajaste como panadero',
                'Trabajaste como pastelero',
                'Trabajaste como carnicero',
                'Trabajaste como pescador',
                'Trabajaste como granjero',
                'Trabajaste como minero',
                'Trabajaste como alfarero',
                'Trabajaste como sastre',
                'Trabajaste como zapatero',
                'Trabajaste como sombrerero',
                'Trabajaste como marino',
                'Trabajaste como guardabosques',
                'Trabajaste como geólogo',
                'Trabajaste como astrónomo',
                'Trabajaste como físico nuclear',
                'Trabajaste como químico farmacéutico',
                'Trabajaste como biólogo marino',
                'Trabajaste como arqueólogo',
                'Trabajaste como historiador',
                'Trabajaste como traductor de idiomas',
                'Trabajaste como intérprete',
                'Trabajaste como locutor de radio',
                'Trabajaste como presentador de TV',
                'Trabajaste como camarógrafo',
                'Trabajaste como editor de video',
                'Trabajaste como animador 3D',
                'Trabajaste como programador de juegos',
                'Trabajaste como tester de software',
                'Trabajaste como administrador de sistemas',
                'Trabajaste como consultor de TI',
                'Trabajaste como científico de datos',
                'Trabajaste como analista de negocios',
                'Trabajaste como agente de viajes',
                'Trabajaste como recepcionista de hotel',
                'Trabajaste como guía turístico',
                'Trabajaste como museógrafo',
                'Trabajaste como bibliotecario',
                'Trabajaste como detective privado',
                'Trabajaste como agente inmobiliario',
                'Trabajaste como tasador de arte',
                'Trabajaste como anticuario',
                'Trabajaste como orfebre',
                'Trabajaste como ebanista',
                'Trabajaste como ceramista',
                'Trabajaste como vidriero artístico',
                'Trabajaste como ilustrador de libros',
                'Trabajaste como cartelista',
                'Trabajaste como diseñador de moda',
                'Trabajaste como peluquero canino',
                'Trabajaste como entrenador de caballos',
                'Trabajaste como domador de circo',
                'Trabajaste como payaso infantil',
                'Trabajaste como mago callejero',
                'Trabajaste como cuentacuentos',
                'Trabajaste como titiritero',
                'Trabajaste como escultor de hielo'
            ];
            
            const trabajo = trabajos[Math.floor(Math.random() * trabajos.length)];
            
            economy[from][userNumber].dinero += ganancia;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            timers[timerKey] = now;
            saveTimers(timers);
            
            await replyWithContext(`❀ *Trabajaste*\n> ${trabajo}\n> *Ganaste* ${ganancia} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en w:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};