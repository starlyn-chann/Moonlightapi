import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import { exec } from 'child_process';
import { promisify } from 'util';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execAsync = promisify(exec);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function randomFileName(ext) {
    return `${Date.now()}_${Math.random().toString(36).substring(7)}.${ext}`;
}

// Convertir imagen a WebP usando ffmpeg
async function imageToWebp(inputPath, outputPath) {
    await execAsync(`ffmpeg -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=increase,crop=512:512" -q:v 80 "${outputPath}" -y`);
}

export default {
    name: 'bratanime',
    alias: ['animebrat'],
    description: 'Genera texto con estilo bratanime',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        let inputPath = null;
        let outputPath = null;
        
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const text = args.join(' ').trim();
            
            if (!text) {
                return await replyWithContext(`「✰」Debes proporcionar un texto\n> Ejemplo: ${config.prefix}bratanime Hola`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🌙', key: msg.key } });
            } catch (e) {}
            
            // Llamar a la API de bratanime
            const apiUrl = `https://api.nexray.web.id/maker/bratanime?text=${encodeURIComponent(text)}`;
            console.log(`🎨 Generando bratanime: ${text}`);
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('No se pudo generar la imagen');
            }
            
            const imageBuffer = Buffer.from(response.data);
            
            // Guardar imagen temporal
            inputPath = path.join(tempFolder, randomFileName('jpg'));
            outputPath = path.join(tempFolder, randomFileName('webp'));
            fs.writeFileSync(inputPath, imageBuffer);
            
            // Convertir a WebP (sticker)
            await imageToWebp(inputPath, outputPath);
            
            if (!fs.existsSync(outputPath)) {
                throw new Error('Error al convertir a sticker');
            }
            
            const stickerBuffer = fs.readFileSync(outputPath);
            
            // Enviar sticker
            await sock.sendMessage(from, {
                sticker: stickerBuffer,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Bratanime creado para ${pushName || userNumber}: "${text}"`);
            
        } catch (error) {
            console.error('❌ Error en bratanime:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`🍧 Error: ${error.message}`);
            } catch (e) {}
            
        } finally {
            // Limpiar archivos temporales
            try { if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath); } catch (e) {}
            try { if (outputPath && fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (e) {}
        }
    }
};