import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `spotify_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatDuration(duration) {
    if (!duration) return 'N/A';
    return duration;
}

async function descargarYEnviar(sock, downloadUrl, title, artist, album, year, duration, cover, config, senderJid, pushName, userNumber, quotedMsg, targetJid) {
    try {
        await sock.sendMessage(targetJid, { react: { text: '📥', key: quotedMsg.key } });
    } catch (e) {}

    const audioResponse = await axios.get(downloadUrl, {
        responseType: 'arraybuffer',
        timeout: 120000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive'
        }
    });
    
    const audioBuffer = Buffer.from(audioResponse.data);
    const cleanTitle = `${artist} - ${title}`.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    
    // Descargar cover
    let coverBuffer = null;
    if (cover) {
        try {
            const coverResponse = await axios.get(cover, {
                responseType: 'arraybuffer',
                timeout: 10000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });
            coverBuffer = Buffer.from(coverResponse.data);
        } catch (e) {
            console.log('Error descargando cover:', e.message);
        }
    }
    
    // Enviar información con cover
    const infoText = `ㅤ♡゙  *𝘚𝘱𝘰𝘵𝘪𝘧𝘺-𝘗𝘭𝘢𝘺ᰱ*   🫍::ㅤׁ\n\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Título:* ${title}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Artista:* ${artist}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Álbum:* ${album || 'N/A'}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Año:* ${year || 'N/A'}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Duración:* ${formatDuration(duration)}\n` +
                    `𒐁᳕⃜ ⃝🕸️᮫⫶ໍ᳟ ۣۙ❱ֱ֘❱ؚّٟؒ❯ *Tamaño:* ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB\n> *Disfruta de la canción  ᐡ,,o ·̫ o,,ᐡ*`;
    
    if (coverBuffer) {
        await sock.sendMessage(targetJid, {
            image: coverBuffer,
            caption: infoText,
            contextInfo: {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        }, { quoted: quotedMsg });
    } else {
        await sock.sendMessage(targetJid, {
            text: infoText,
            contextInfo: {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            }
        }, { quoted: quotedMsg });
    }
    
    // Enviar audio
    await sock.sendMessage(targetJid, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        fileName: `${cleanTitle}.mp3`,
        ptt: false,
        contextInfo: {
            mentionedJid: senderJid ? [senderJid] : [],
            forwardingScore: 9999999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: config.canalId || '',
                serverMessageId: 0,
                newsletterName: config.canalNombre || ''
            }
        }
    }, { quoted: quotedMsg });
    
    console.log(`✅ Canción descargada: ${title} - ${artist} por ${pushName || userNumber}`);
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'spotifyplay',
    alias: ['splay'],
    description: 'Busca y descarga canciones de Spotify',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            const esBotPrincipal = isMainBot(sock);
            const esPremium = config.premium === true;
            
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir el nombre de una canción\n> Ejemplo: ${config.prefix}splay Boss Bitch`);
            }
            
            // Verificar si es un enlace de Spotify
            if (query.includes('open.spotify.com/track/')) {
                try {
                    await sock.sendMessage(from, { react: { text: '🕑', key: msg.key } });
                    
                    // ============ API DE DESCARGA ============
                    const apiUrl = `https://apiakari.vercel.app/api/downloader/spotify?url=${encodeURIComponent(query)}`;
                    const response = await axios.get(apiUrl, { timeout: 30000 });
                    
                    if (!response.data?.status || !response.data?.data) {
                        throw new Error('No se pudo obtener la canción');
                    }
                    
                    const data = response.data.data;
                    const downloadUrl = data.download || data.raw?.mp3;
                    const title = data.title || data.raw?.name;
                    const artist = data.author || data.raw?.artist;
                    const album = data.album || data.raw?.album;
                    const year = data.year || data.raw?.year;
                    const duration = data.duration || data.raw?.duration;
                    const cover = data.cover || data.raw?.cover;
                    
                    if (!downloadUrl) {
                        throw new Error('No se pudo obtener el enlace de descarga');
                    }
                    
                    await descargarYEnviar(sock, downloadUrl, title, artist, album, year, duration, cover, config, senderJid, pushName, userNumber, msg, from);
                    
                    try {
                        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                    } catch (e) {}
                    
                } catch (error) {
                    console.error('Error descargando:', error);
                    await replyWithContext(`❌ Error: ${error.message}`);
                    try {
                        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                    } catch (e) {}
                }
                return;
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // ============ BUSCAR CON API NANZZ ============
            const apiUrl = `https://api-nanzz.my.id/docs/api/search/spotify.php?q=${encodeURIComponent(query)}`;
            const response = await axios.get(apiUrl, { timeout: 30000 });
            
            if (!response.data?.status || !response.data?.result || !response.data.result.tracks || response.data.result.tracks.length === 0) {
                await replyWithContext(`「✰」 No se encontraron resultados para "${query}"`);
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            const tracks = response.data.result.tracks;
            
            // Crear secciones para botones
            const rows = tracks.slice(0, 10).map((track) => {
                const artistName = track.artists && track.artists.length > 0 ? track.artists[0].name : 'Artista desconocido';
                const duration = formatDuration(track.duration_ms);
                return {
                    header: `${artistName}`,
                    title: `${track.title}`,
                    description: `⏱️ ${duration}`,
                    id: `${config.prefix}splay ${track.url}`
                };
            });
            
            const sections = [{
                title: "RESULTADOS DE BÚSQUEDA",
                rows: rows
            }];
            
            // Obtener imagen del primer resultado
            let imageBuffer = null;
            if (tracks[0]?.album?.images && tracks[0].album.images.length > 0) {
                try {
                    const imgUrl = tracks[0].album.images[0].url;
                    const imgResponse = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
                    imageBuffer = Buffer.from(imgResponse.data);
                } catch (e) {
                    console.log('Error descargando imagen:', e.message);
                }
            }
            
            const infoText = `✿ 𝘚𝘗𝘖𝘛𝘐𝘍𝘠 𝘋𝘖𝘞𝘕𝘓𝘖𝘈𝘋 ✿\n\n` +
                           `「✰」 Búsqueda › ${query}\n` +
                           `「✰」 Resultados › ${Math.min(tracks.length, 10)}`;
            
            if (imageBuffer) {
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: infoText,
                    interactiveButtons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Opciones",
                            sections: sections
                        })
                    }],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: infoText,
                    interactiveButtons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "Opciones",
                            sections: sections
                        })
                    }],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            console.log(`🎵 Spotify buscado: ${query} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en spotifyplay:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};