import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERHASH = '0c3e78aeb2c067f3520f900de';

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `tourl_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime, intentos = 0) {
    const maxIntentos = 5;
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', USERHASH);
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });

    try {
        const res = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            timeout: 60000
        });

        if (typeof res.data !== 'string') {
            throw new Error('Respuesta inválida de Catbox (no es string)');
        }

        const responseText = res.data.trim();

        if (!responseText) {
            throw new Error('Catbox devolvió una respuesta vacía');
        }

        if (responseText.includes('error') || responseText.includes('Error')) {
            throw new Error(`Catbox error: ${responseText}`);
        }

        if (!responseText.startsWith('https://')) {
            throw new Error(`Respuesta inválida: ${responseText}`);
        }

        return responseText;

    } catch (error) {
        if (intentos < maxIntentos) {
            console.log(`⚠️ Intento ${intentos + 1} falló, reintentando en ${(intentos + 1) * 2}s...`);
            await new Promise(resolve => setTimeout(resolve, (intentos + 1) * 2000));
            return uploadCatbox(buffer, mime, intentos + 1);
        }
        throw error;
    }
}

export default {
    name: 'tourl2',
    alias: ['toupload2', 'upload2', 'subir2'],
    description: 'Sube imágenes, GIFs o videos a Catbox',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!quotedMsg?.quotedMessage) {
                return await replyWithContext(`⭐ Responde a una imagen, GIF o video\n\n> Ejemplo: Responde a una imagen con ${config.prefix}tourl2`);
            }

            const quotedMessage = quotedMsg.quotedMessage;
            const isImage = quotedMessage.imageMessage;
            const isVideo = quotedMessage.videoMessage;
            
            if (!isImage && !isVideo) {
                return await replyWithContext(`⭐ Solo se permiten imágenes, GIFs o videos`);
            }
            
            const media = isImage || isVideo;
            let type = 'image';
            let mime = 'image/jpeg';
            
            if (isImage) {
                type = 'image';
                mime = media.mimetype || 'image/jpeg';
            } else if (isVideo) {
                const videoMime = media.mimetype || 'video/mp4';
                if (videoMime.includes('gif')) {
                    type = 'gif';
                    mime = videoMime;
                } else {
                    type = 'video';
                    mime = videoMime;
                }
            }
            
            const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'webm'];
            const ext = mime.split('/')[1]?.toLowerCase() || '';
            
            if (!allowedExtensions.includes(ext) && !mime.includes('gif')) {
                return await replyWithContext(`⭐ Formato no soportado\n> Formatos permitidos: JPG, PNG, GIF, MP4, WEBM`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
            } catch (e) {}
            
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg.stanzaId,
                    participant: quotedMsg.participant || from,
                    fromMe: false
                },
                message: {
                    [isVideo ? 'videoMessage' : 'imageMessage']: media
                }
            };
            
            const buffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            if (!buffer || buffer.length === 0) {
                throw new Error('No se pudo descargar el archivo');
            }
            
            const maxSize = 9 * 1024 * 1024;
            
            if (buffer.length > maxSize) {
                return await replyWithContext(`⭐ El archivo es demasiado grande (${formatSize(buffer.length)})\n> Máx: 9MB para Catbox`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '☁️', key: msg.key } });
            } catch (e) {}
            
            console.log(`📤 Subiendo archivo a Catbox (tipo: ${type}, tamaño: ${formatSize(buffer.length)})`);
            const link = await uploadCatbox(buffer, mime);
            console.log(`✅ Archivo subido exitosamente: ${link}`);
            
            const emoji = type === 'image' ? '📷' : type === 'gif' ? '🎞️' : '🎬';
            const tipoTexto = type === 'image' ? 'Imagen' : type === 'gif' ? 'GIF' : 'Video';
            
            const desc = `﹒︵͡⏜ ᅟ︵͡⏜
﹒ ─ ‎ ‎‎ ‎ 사랑 ‎ *TOURL2* ‎ ‎‎ ‎ ‎ᰍ ׅ

✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *URL* » ${link}
✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *Servidor* » catbox
✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *Tipo* » ${emoji} ${tipoTexto}
✿ ꒰ㅤ⃞̸̷ֺ᪱๑ֺ *Tamaño* » ${formatSize(buffer.length)}`;

            if (type === 'image') {
                await sock.sendMessage(from, { 
                    image: buffer, 
                    caption: desc,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { 
                    video: buffer, 
                    gifPlayback: type === 'gif',
                    caption: desc,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Tourl2: ${type} subido a catbox (${formatSize(buffer.length)}) por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en tourl2:', error);
            
            try {
                const { replyWithContext } = options;
                
                if (error.message.includes('Catbox error') || error.message.includes('Respuesta inválida')) {
                    await replyWithContext(`❌ *Error:* No se pudo subir el archivo a Catbox después de varios intentos\n> Verifica que el archivo sea válido y no esté corrupto\n> Tamaño máximo: 9MB`);
                } else if (error.response?.status === 412) {
                    await replyWithContext(`❌ *Error:* Archivo demasiado grande o formato no soportado por Catbox\n> Tamaño máximo: 9MB\n> Formatos: JPG, PNG, GIF, MP4, WEBM`);
                } else {
                    await replyWithContext(`❌ *Error:* ${error.message}`);
                }
                
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {
                console.error('Error enviando mensaje de error:', e);
            }
        }
    }
};