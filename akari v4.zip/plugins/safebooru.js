import axios from 'axios';

export default {
    name: 'safebooru',
    alias: ['sfw', 'safe'],
    description: 'Busca una imagen en Safebooru (SFW)',
    category: 'anime',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, senderJid } = options;
            const from = msg.key.remoteJid;
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir un tag para buscar\n> Ejemplo: ${config.prefix}safebooru neko`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // Buscar en Safebooru (sin límite)
            const apiUrl = `https://safebooru.org/index.php?page=dapi&s=post&q=index&json=1&tags=${encodeURIComponent(query)}`;
            
            const response = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const posts = response.data;
            
            if (!posts || posts.length === 0) {
                return await replyWithContext(`「✰」 No se encontraron imágenes para "${query}"`);
            }
            
            // Seleccionar una imagen aleatoria
            const randomIndex = Math.floor(Math.random() * posts.length);
            const post = posts[randomIndex];
            
            // Construir URL de la imagen
            const imageUrl = `https://safebooru.org/images/${post.directory}/${post.image}`;
            
            // Obtener información de la imagen
            const rating = post.rating || 'N/A';
            const score = post.score || 0;
            const tags = post.tags || '';
            const tagList = tags.split(' ').slice(0, 10).join(', ');
            
            // Descargar la imagen
            const imgResponse = await axios.get(imageUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const imgBuffer = Buffer.from(imgResponse.data);
            
            // Enviar imagen con información
            const caption = `「✰」 *Tag:* ${query}\n` +
                           `「✰」 *Rating:* ${rating}\n` +
                           `「✰」 *Score:* ${score}\n` +
                           `「✰」 *Tags:* ${tagList || 'Sin etiquetas'}\n\n` +
                           `> *Solicitado por:* ${pushName || userNumber}`;
            
            await sock.sendMessage(from, {
                image: imgBuffer,
                caption: caption,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`🖼️ Safebooru: "${query}" por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en safebooru:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `❌ *Error:* ${error.message}`;
            if (error.response?.status === 404) {
                errorMsg = `❌ No se encontraron resultados para "${query}"`;
            } else if (error.code === 'ECONNABORTED') {
                errorMsg = `❌ La búsqueda tardó demasiado. Intenta con tags más específicos.`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};