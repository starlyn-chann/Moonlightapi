import { xvideosDownload } from '@danonino/starlyn-scraper';
import axios from 'axios';

const UA = 'Mozilla/5.0 (Linux; Android 11; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

export default {
    name: 'testv3',
    alias: [],
    description: 'Descarga videos de Xvideos usando el scraper, los envía al chat y muestra el JSON obtenido',
    category: 'downloader',
    
    async execute(sock, msg, options) {
        try {
            const { args, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const targetUrl = args[0];
            
            // Se actualizó la validación para aceptar xvideos.com y xvideos.es
            if (!targetUrl || (!targetUrl.includes('xvideos.com') && !targetUrl.includes('xvideos.es'))) {
                return await replyWithContext(
                    `[ ★ ] *Uso incorrecto del comando*\n\n` +
                    `Debes proporcionar un enlace válido de Xvideos.\n\n` +
                    `Ejemplo:\n.testv3 https://www.xvideos.com/video.xxxxx/slug`
                );
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`[ ★ ] Procesando y obteniendo datos de Xvideos...\n⏱️ Por favor espera, esto puede tardar unos momentos...`);
            
            const scrapeData = await xvideosDownload(targetUrl);
            
            const videoUrl = scrapeData.download?.high?.url || scrapeData.download?.low?.url;
            const qualityUsed = scrapeData.download?.high ? scrapeData.download.high.quality : (scrapeData.download?.low?.quality || '240p');
            
            if (!videoUrl) {
                throw new Error('No se pudo encontrar una URL de descarga válida.');
            }
            
            const videoResponse = await axios.get(videoUrl, {
                responseType: 'arraybuffer',
                headers: { 'User-Agent': UA },
                timeout: 60000
            });
            
            const buffer = Buffer.from(videoResponse.data);
            
            const title = scrapeData.title || 'Video de Xvideos';
            const duration = scrapeData.duration || 'Desconocida';
            const uploadDate = scrapeData.uploadDate || 'N/A';
            const views = scrapeData.views ? Number(scrapeData.views).toLocaleString() : 'N/A';
            const fileSizeMB = (buffer.length / 1024 / 1024).toFixed(2);
            
            const videoMessage = {
                video: buffer,
                mimetype: 'video/mp4',
                caption: 
                    `🎬 *Título:* ${title}\n` +
                    `⏱️ *Duración:* ${duration}\n` +
                    `👀 *Vistas:* ${views}\n` +
                    `⚙️ *Calidad:* ${qualityUsed}\n` +
                    `📅 *Fecha:* ${uploadDate}\n` +
                    `📁 *Tamaño:* ${fileSizeMB} MB`,
                fileName: `${title.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`
            };
            
            // 1. Envía el video primero
            await sock.sendMessage(from, videoMessage, { quoted: msg });
            
            // 2. Prepara y envía el JSON del scraper limpio (omitiendo el buffer para no saturar el chat)
            const jsonOutput = {
                creator: '𝗌ƚαꭇ𝗅ᥡ𝗇',
                status: true,
                result: {
                    title: scrapeData.title,
                    thumb: scrapeData.thumb,
                    duration: scrapeData.duration,
                    views: scrapeData.views,
                    uploadDate: scrapeData.uploadDate,
                    sizeBytes: buffer.length,
                    download: scrapeData.download
                }
            };

            await replyWithContext(`📦 *JSON del Scraper:*\n\`\`\`json\n${JSON.stringify(jsonOutput, null, 2)}\n\`\`\``);
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
        } catch (error) {
            console.error('❌ Error en testv3:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                
                let errorMessage = `[ ★ ] *ERROR*\n\n`;
                errorMessage += `${error.message}`;
                
                if (error.stack) {
                    errorMessage += `\n\n📋 *Stack:*\n\`\`\`\n${error.stack}\n\`\`\``;
                }
                
                await replyWithContext(errorMessage);
            } catch (e) {
                console.error('❌ Error al enviar mensaje de error:', e);
            }
        }
    }
};