import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GOODBYE_FILE = path.join(__dirname, '..', 'data', 'goodbye.json');

function loadGoodbye() {
    try {
        if (fs.existsSync(GOODBYE_FILE)) {
            const data = fs.readFileSync(GOODBYE_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de despedida:', e);
    }
    return {};
}

function saveGoodbye(goodbye) {
    try {
        fs.writeFileSync(GOODBYE_FILE, JSON.stringify(goodbye, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando mensajes de despedida:', e);
        return false;
    }
}

const DEFAULT_GOODBYE =
`╭╴ֺ    ׅ ☆   ࣪お  ׅ     ֺ⭐⃨ᩧ ֺ    ׅ  お  ֺ      ׅ ☆    ׅ╶╮
              ✰ 𝖦𝖮𝖮𝖣𝖡𝖸𝖤 ✰
          
      ✿ @user 𝖧𝖺 𝗌𝖺𝗅𝗂𝖽𝗈 𝖽𝖾𝗅 𝗀𝗋𝗎𝗉𝗈
      ✐ @group  
╰╴ֺ    ׅ ☆    お  ׅ    ֺ⭐⃨ᩧ ֺ    ׅ  お  ֺ      ׅ ☆    ׅ╶╯`;

export default {
    name: 'bye',
    alias: ['goodbye'],
    description: 'Activar o desactivar el mensaje de despedida',
    category: 'on / off',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, isGroup, isOwner } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === msg.key.participant);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            
            if (!isAdmin && !isOwner) {
                return await replyWithContext(`❌ *Solo administradores pueden usar este comando*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`❀ Debes proporcionar *on/off*`);
            }
            
            const accion = args[0].toLowerCase();
            
            if (accion !== 'on' && accion !== 'off') {
                return await replyWithContext(`❀ Debes proporcionar *on/off*`);
            }
            
            const goodbyeData = loadGoodbye();
            
            if (!goodbyeData[from]) {
                goodbyeData[from] = {
                    message: DEFAULT_GOODBYE,
                    enabled: true
                };
            }
            
            if (accion === 'on') {
                if (!goodbyeData[from].message || goodbyeData[from].message.trim() === '') {
                    goodbyeData[from].message = DEFAULT_GOODBYE;
                }
                goodbyeData[from].enabled = true;
                saveGoodbye(goodbyeData);
                
                const bannerUrl = config.banner || '';
                const link = 'https://moonstaff.onrender.com/';
                
                let infoText = `❀ *Se ha activado la despedida*`;
                
                if (bannerUrl) {
                    try {
                        const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                        if (uploadMethod) {
                            const { imageMessage } = await prepareWAMessageMedia(
                                { image: { url: bannerUrl } },
                                { 
                                    upload: uploadMethod, 
                                    mediaTypeOverride: 'thumbnail-link' 
                                }
                            );
                            const linkPreview = {
                                'canonical-url': link,
                                'matched-text': link,
                                title: config.nombre || config.name || "Sirius",
                                description: `🐝 Despedidas activadas`,
                                jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                                highQualityThumbnail: imageMessage || undefined
                            };
                            await sock.sendMessage(from, {
                                text: infoText,
                                linkPreview: linkPreview,
                                contextInfo: {
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        } else {
                            await replyWithContext(infoText);
                        }
                    } catch (error) {
                        console.error('Error con banner en bye:', error);
                        await replyWithContext(infoText);
                    }
                } else {
                    await replyWithContext(infoText);
                }
            } else {
                goodbyeData[from].enabled = false;
                saveGoodbye(goodbyeData);
                
                const bannerUrl = config.banner || '';
                const link = 'https://moonstaff.onrender.com/';
                
                let infoText = `❀ *Se ha desactivado la despedida*`;
                
                if (bannerUrl) {
                    try {
                        const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                        if (uploadMethod) {
                            const { imageMessage } = await prepareWAMessageMedia(
                                { image: { url: bannerUrl } },
                                { 
                                    upload: uploadMethod, 
                                    mediaTypeOverride: 'thumbnail-link' 
                                }
                            );
                            const linkPreview = {
                                'canonical-url': link,
                                'matched-text': link,
                                title: config.nombre || config.name || "Sirius",
                                description: `🐝 Despedidas desactivadas`,
                                jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                                highQualityThumbnail: imageMessage || undefined
                            };
                            await sock.sendMessage(from, {
                                text: infoText,
                                linkPreview: linkPreview,
                                contextInfo: {
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            }, { quoted: msg });
                        } else {
                            await replyWithContext(infoText);
                        }
                    } catch (error) {
                        console.error('Error con banner en bye:', error);
                        await replyWithContext(infoText);
                    }
                } else {
                    await replyWithContext(infoText);
                }
            }
            
        } catch (error) {
            console.error('❌ Error en bye:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};