import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'top',
    alias: ['rank', 'topexp'],
    description: 'Muestra el top de usuarios con más experiencia',
    category: 'main',
    
    async execute(sock, msg, options) {
        try {
            const { replyWithContext, isGroup, args } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            let usersDb = loadUsersDb();
            
            if (!usersDb || usersDb.length === 0) {
                return await replyWithContext(`❀ *No hay usuarios registrados*`);
            }
            
            let pagina = 1;
            if (args && args.length > 0) {
                const num = parseInt(args[0]);
                if (!isNaN(num) && num > 0) {
                    pagina = num;
                }
            }
            
            const USUARIOS_POR_PAGINA = 10;
            
            // Ordenar por experiencia (mayor a menor)
            const usuariosOrdenados = [...usersDb].sort((a, b) => (b.exp || 0) - (a.exp || 0));
            
            const totalUsuarios = usuariosOrdenados.length;
            const totalPaginas = Math.ceil(totalUsuarios / USUARIOS_POR_PAGINA);
            
            if (pagina > totalPaginas) {
                return await replyWithContext(`❀ *Página no válida*\n> Hay ${totalPaginas} páginas disponibles`);
            }
            
            const inicio = (pagina - 1) * USUARIOS_POR_PAGINA;
            const fin = Math.min(inicio + USUARIOS_POR_PAGINA, totalUsuarios);
            const usuariosPagina = usuariosOrdenados.slice(inicio, fin);
            
            let mensaje = `❀ *Top Experiencia*\n\n`;
            
            for (let i = 0; i < usuariosPagina.length; i++) {
                const user = usuariosPagina[i];
                const posicion = inicio + i + 1;
                const exp = user.exp || 0;
                const nivel = user.nivel || 1;
                const nombre = user.pushName || 'Usuario';
                
                mensaje += `${posicion} ✰᪲͜ᮬ ${nombre}\n`;
                mensaje += `> ${formatNumber(exp)} EXP » Nivel ${nivel}\n\n`;
            }
            
            mensaje += `> *Lista (${pagina}) de (${totalPaginas})*`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en top:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};