import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';
import os from 'os';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

function getActiveBots() {
    const activeBots = new Set();
    
    try {
        if (global.principalBot?.user?.id) {
            const botNumber = cleanNumber(global.principalBot.user.id);
            if (botNumber) activeBots.add(botNumber);
        }
        
        const subsSessionsPath = path.join(process.cwd(), 'Sessions', 'Subs');
        if (fs.existsSync(subsSessionsPath)) {
            const subFolders = fs.readdirSync(subsSessionsPath).filter(folder => {
                const folderPath = path.join(subsSessionsPath, folder);
                return fs.statSync(folderPath).isDirectory() && /^\d+$/.test(folder);
            });
            for (const folder of subFolders) {
                const credsPath = path.join(subsSessionsPath, folder, 'creds.json');
                if (fs.existsSync(credsPath)) {
                    const botNumber = cleanNumber(folder);
                    if (botNumber) activeBots.add(botNumber);
                }
            }
        }
        
        const premsSessionsPath = path.join(process.cwd(), 'Sessions', 'prems');
        if (fs.existsSync(premsSessionsPath)) {
            const premFolders = fs.readdirSync(premsSessionsPath).filter(folder => {
                const folderPath = path.join(premsSessionsPath, folder);
                return fs.statSync(folderPath).isDirectory() && /^\d+$/.test(folder);
            });
            for (const folder of premFolders) {
                const credsPath = path.join(premsSessionsPath, folder, 'creds.json');
                if (fs.existsSync(credsPath)) {
                    const botNumber = cleanNumber(folder);
                    if (botNumber) activeBots.add(botNumber);
                }
            }
        }
        
        if (global.premiumBots && Array.isArray(global.premiumBots)) {
            for (const bot of global.premiumBots) {
                if (bot.user?.id) {
                    const botNumber = cleanNumber(bot.user.id);
                    if (botNumber) activeBots.add(botNumber);
                }
            }
        }
        
        if (global.mainBots && Array.isArray(global.mainBots)) {
            for (const bot of global.mainBots) {
                if (bot.user?.id) {
                    const botNumber = cleanNumber(bot.user.id);
                    if (botNumber) activeBots.add(botNumber);
                }
            }
        }
        
    } catch (e) {
        console.error('Error obteniendo bots activos:', e);
    }
    
    return activeBots;
}

function getUptime() {
    const uptimeSeconds = process.uptime();
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    
    let parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (seconds > 0 || parts.length === 0) parts.push(`${seconds}s`);
    
    return parts.join(' ');
}

export default {
    name: 'system',
    alias: ['sistema', 'status'],
    description: 'Muestra el estado del sistema y la API',
    category: 'main',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, senderJid, pushName, isOwner } = options;
            const from = msg.key.remoteJid;
            
            try {
                await sock.sendMessage(from, { react: { text: '📊', key: msg.key } });
            } catch (e) {}
            
            // ============ OBTENER BOTS ACTIVOS ============
            const activeBots = getActiveBots();
            const totalBots = activeBots.size || 1;
            
            // ============ OBTENER UPTIME ============
            const uptime = getUptime();
            
            // ============ OBTENER RAM Y CPU ============
            const totalMem = os.totalmem();
            const freeMem = os.freemem();
            const usedMem = totalMem - freeMem;
            const usedMemGB = (usedMem / 1024 / 1024 / 1024).toFixed(2);
            const freeMemGB = (freeMem / 1024 / 1024 / 1024).toFixed(2);
            
            const cpuUsage = os.loadavg()[0];
            const cpuPercent = (cpuUsage / os.cpus().length * 100).toFixed(1);
            
            const cpuModel = os.cpus()[0]?.model || 'Desconocido';
            const cpuCores = os.cpus().length;
            
            // ============ OBTENER VERSIÓN DE NODE ============
            const nodeVersion = process.version;
            
            // ============ OBTENER API STATUS ============
            let apiStatus = 'offline';
            let totalEndpoints = 0;
            
            try {
                const apiResponse = await axios.get('https://apiakari.vercel.app/api/apilist', {
                    timeout: 10000,
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                });
                
                if (apiResponse.data?.total_endpoints) {
                    apiStatus = 'active';
                    totalEndpoints = apiResponse.data.total_endpoints;
                }
            } catch (e) {
                console.log('Error obteniendo status de API:', e.message);
            }
            
            // ============ BANNER DESDE CONFIG ============
            const bannerUrl = config.banner || '';
            const link = 'https://apiakari.vercel.app/';
            
            // ============ CONSTRUIR MENSAJE ============
            const infoText = 
`🌷𖹭゚᷼ᮬ *Sistema - Moon Staff*

📓͚ํ𖹭᳢ *Bots Activos › ${totalBots}*
📓͚ํ𖹭᳢ *Uptime › ${uptime}*

📓͚ํ𖹭᳢ *Api › https://apiakari.vercel.app/*
📓͚ํ𖹭᳢ *Estado Api › ${apiStatus}*
📓͚ํ𖹭᳢ *Endpoints › ${totalEndpoints}*

📓͚ํ𖹭᳢ *Ram Usado › ${usedMemGB} GB*
📓͚ํ𖹭᳢ *Ram Libre › ${freeMemGB} GB*
📓͚ํ𖹭᳢ *CPU › ${cpuPercent}%*
📓͚ํ𖹭᳢ *Núcleos › ${cpuCores}*
📓͚ํ𖹭᳢ *Modelo › ${cpuModel}*
📓͚ํ𖹭᳢ *Nodejs › ${nodeVersion}*`;

            // ============ ENVIAR CON BANNER ============
            if (bannerUrl) {
                try {
                    const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                    
                    if (!uploadMethod) {
                        throw new Error('No hay método de upload disponible');
                    }
                    
                    const { imageMessage } = await prepareWAMessageMedia(
                        { image: { url: bannerUrl } },
                        { 
                            upload: uploadMethod, 
                            mediaTypeOverride: 'thumbnail-link' 
                        }
                    );
                    
                    const linkPreview = {
                        'canonical-url': link,
                        'matched-text': link,
                        title: config.nombre || config.name || "Sirius",
                        description: "🌷 Sistema - Moon Staff",
                        jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                        highQualityThumbnail: imageMessage || undefined
                    };
                    
                    await sock.sendMessage(from, {
                        text: infoText,
                        linkPreview: linkPreview,
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: '0',
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                } catch (error) {
                    console.error('Error con banner:', error);
                    await replyWithContext(infoText);
                }
            } else {
                await replyWithContext(infoText);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`📊 System info mostrado a ${pushName || 'Usuario'}`);
            
        } catch (error) {
            console.error('❌ Error en system:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};