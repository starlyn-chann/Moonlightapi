import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GOODBYE_FILE = path.join(__dirname, '..', 'data', 'goodbye.json');

function loadGoodbye() {
    try {
        if (fs.existsSync(GOODBYE_FILE)) {
            const data = fs.readFileSync(GOODBYE_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de despedida:', e);
    }
    return {};
}

function saveGoodbye(goodbye) {
    try {
        fs.writeFileSync(GOODBYE_FILE, JSON.stringify(goodbye, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando mensajes de despedida:', e);
        return false;
    }
}

export default {
    name: 'setbye',
    alias: ['setgoodbye'],
    description: 'Configurar mensaje de despedida del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, isGroup, isOwner } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === msg.key.participant);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            
            if (!isAdmin && !isOwner) {
                return await replyWithContext(`*ᰔᩚ* *Solo administradores pueden usar este comando*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`Debes proporcionar un mensaje de despedida\n\n*❒ Opciones*\n\n꒰ 👒 ੭  ﾟ@user\n> → Mención del usuario que sale\n\n꒰ 👒 ੭  ﾟ@group\n> → Nombre del grupo\n\n꒰ 👒 ੭  ﾟ@desc\n> → Descripción del grupo\n\n꒰ 👒 ੭  ﾟ@members\n> → Número de miembros actuales\n\n꒰ 👒 ੭  ﾟ@time\n> → Fecha y hora`
                );
            }

            const goodbyeData = loadGoodbye();
            
            if (!goodbyeData[from]) {
                goodbyeData[from] = {
                    message: '',
                    enabled: true
                };
            }

            if (args[0] === '0') {
                if (!goodbyeData[from].message || goodbyeData[from].message.trim() === '') {
                    return await replyWithContext('✎ No tienes ningún mensaje de despedida definido.');
                }
                goodbyeData[from].message = '';
                goodbyeData[from].enabled = false;
                saveGoodbye(goodbyeData);
                return await replyWithContext('✐ Mensaje de despedida eliminado.');
            }

            if (goodbyeData[from].message && goodbyeData[from].message.trim() !== '') {
                return await replyWithContext(
                    `✎ Ya tienes un mensaje de despedida configurado:\n\n${goodbyeData[from].message}\n\nSi quieres reemplazarlo, primero bórralo con:\n${config.prefix}setbye 0`
                );
            }

            const texto = args.join(' ');
            goodbyeData[from].message = texto;
            goodbyeData[from].enabled = true;
            saveGoodbye(goodbyeData);
            
            await replyWithContext(`《✎》 Nuevo mensaje de despedida configurado correctamente.`);
            
        } catch (error) {
            console.error('❌ Error en setbye:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};