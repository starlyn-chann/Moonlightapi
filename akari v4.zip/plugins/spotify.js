import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `spotify_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

export default {
    name: 'spotify',
    alias: ['sp'],
    description: 'Descarga música desde Spotify',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, senderJid, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args.join(' ').trim();
            
            if (!url) {
                return await replyWithContext(`*ᰔᩚ* Debes proporcionar un enlace de Spotify\n> Ejemplo: ${config.prefix}spotify https://open.spotify.com/track/xxxxx`);
            }
            
            if (!url.includes('spotify.com')) {
                return await replyWithContext(`*Link inválido*\n\n> Debes proporcionar un enlace de Spotify válido.`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            await replyWithContext(`*Buscando...*`);
            
            // ============ API NANZZ ============
            const apiUrl = `https://api-nanzz.my.id/docs/api/downloader/spotify-dl.php?url=${encodeURIComponent(url)}`;
            
            const response = await axios.get(apiUrl, {
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.data?.status || !response.data?.metadata) {
                throw new Error('No se encontró la canción');
            }
            
            const metadata = response.data.metadata;
            const downloadUrl = response.data.download_url;
            
            const title = metadata.name || 'Canción';
            const artist = metadata.artist || 'Artista';
            const album = metadata.album || '';
            const duration = metadata.duration || 'N/A';
            const imageUrl = metadata.image || '';
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // Descargar thumbnail
            let thumbnailBuffer = null;
            if (imageUrl) {
                try {
                    const thumbResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (e) {
                    console.log('Error descargando thumbnail:', e.message);
                }
            }
            
            // Descargar audio
            const audioResponse = await axios.get(downloadUrl, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://spotify.com/'
                }
            });
            
            const audioBuffer = Buffer.from(audioResponse.data);
            const sizeMB = (audioBuffer.length / 1024 / 1024).toFixed(2);
            const nombreArchivo = title.replace(/[^a-zA-Z0-9]/g, '_');
            
            // Construir caption
            let caption = `꯭ꕤ゙ *Nombre › ${title}*\n`;
            caption += `ꕤ゙ *Artista › ${artist}*\n`;
            if (album) caption += `ꕤ゙ *Álbum › ${album}*\n`;
            caption += `ꕤ゙ *Duración › ${duration}*\n`;
            caption += `ꕤ゙ *Tamaño › ${sizeMB} MB*\n\n`;
            caption += `> Solicitado por: ${pushName || 'Usuario'}`;
            
            // Enviar thumbnail con la información
            if (thumbnailBuffer) {
                await sock.sendMessage(from, {
                    image: thumbnailBuffer,
                    caption: caption,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await replyWithContext(caption);
            }
            
            // Enviar el audio como MP3
            await sock.sendMessage(from, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${nombreArchivo}.mp3`,
                ptt: false,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Canción descargada: ${title} - ${artist} (${sizeMB} MB) por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en spotify:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}\n\n> Verifica que el enlace sea válido y vuelve a intentarlo.`);
            } catch (e) {}
        }
    }
};