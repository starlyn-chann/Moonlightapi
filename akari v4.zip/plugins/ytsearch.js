import yts from 'yt-search';
import axios from 'axios';

export default {
    name: 'ytsearch',
    alias: ['yts', 'yutubesearch'],
    description: 'Busca videos en YouTube',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」Debes proporcionar una búsqueda\n> Ejemplo: ${config.prefix}ytsearch música relajante`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // Buscar en YouTube usando yt-search
            const results = await yts(query);
            const videos = results.videos || results.all || [];
            
            if (!videos || videos.length === 0) {
                return await replyWithContext(`「✰」No se encontraron videos para *${query}*\n\n> Intenta con otra palabra clave`);
            }
            
            // Tomar los primeros 5 videos
            const topVideos = videos.slice(0, 5);
            
            // Descargar miniaturas y crear cards
            const cards = [];
            let downloadedCount = 0;
            
            for (let i = 0; i < topVideos.length; i++) {
                try {
                    const video = topVideos[i];
                    
                    // Descargar miniatura
                    let thumbnailBuffer = null;
                    if (video.thumbnail) {
                        try {
                            const thumbResponse = await axios.get(video.thumbnail, {
                                responseType: 'arraybuffer',
                                timeout: 10000,
                                headers: {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                                }
                            });
                            thumbnailBuffer = Buffer.from(thumbResponse.data);
                        } catch (e) {
                            console.log(`Error descargando miniatura ${i + 1}:`, e.message);
                        }
                    }
                    
                    // Limpiar título
                    let title = video.title || 'Sin título';
                    if (title.length > 50) title = title.substring(0, 50) + '...';
                    
                    // Limpiar canal
                    let channel = video.author?.name || video.channel?.name || 'Canal desconocido';
                    if (channel.length > 30) channel = channel.substring(0, 30) + '...';
                    
                    // Formatear vistas
                    let views = video.views || 0;
                    let viewsText = views.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                    
                    // Formatear duración
                    let duration = video.timestamp || video.duration?.timestamp || 'N/A';
                    
                    // Formatear fecha
                    let publishedTime = video.ago || video.published || 'N/A';
                    
                    cards.push({
                        image: thumbnailBuffer,
                        title: `⭐ ${title}`,
                        body: `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ ꥓࣮ *Canal* » ${channel}\n` +
                              `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ ꥓࣮ *Duración* » ${duration}\n` +
                              `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ ꥓࣮ *Vistas* » ${viewsText}\n` +
                              `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ ꥓࣮ *Publicado* » ${publishedTime}\n` +
                              `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ ꥓࣮ *Enlace* » ${video.url}`,
                        footer: `⭐ Moonlight Staff ⭐`
                    });
                    
                    downloadedCount++;
                    
                } catch (error) {
                    console.error(`Error procesando video ${i + 1}:`, error.message);
                    continue;
                }
            }
            
            if (cards.length === 0) {
                return await replyWithContext(`*YouTube Search*\n\n❌ Error al procesar los resultados para *${query}*`);
            }
            
            // Enviar como cards
            await sock.sendMessage(from, {
                text: `*YouTube Search*\n\n` +
                      `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ *Búsqueda:* ${query}\n` +
                      `݂〫𝆬⭐֮᷼𑣲᮫ׅׄ *Resultados:* ${downloadedCount} videos\n\n` +
                      `*Resultados de YouTube*`,
                title: '⭐ YouTube Search',
                subtitle: `Resultados para: ${query}`,
                footer: '⭐ Moonlight Staff ⭐',
                cards: cards,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ YouTube Search: "${query}" - ${downloadedCount} videos encontrados por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en ytsearch:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`*YouTube Search*\n\n❌ Error al realizar la búsqueda: ${error.message}`);
            } catch (e) {}
        }
    }
};