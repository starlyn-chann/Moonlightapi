import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERHASH = '7eac01ee208c76d5f57056c68';

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `gay_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function generateUniqueFilename(mime) {
    const ext = mime.split('/')[1] || 'bin';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let id = Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${id}.${ext}`;
}

async function uploadCatbox(buffer, mime) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', USERHASH);
    form.append('fileToUpload', buffer, { filename: generateUniqueFilename(mime) });

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders(),
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        timeout: 30000
    });

    if (typeof res.data !== 'string' || !res.data.startsWith('https://')) {
        throw new Error('Respuesta inválida de Catbox');
    }
    return res.data;
}

export default {
    name: 'gay',
    alias: [],
    description: 'Aplica el efecto gay a la foto de perfil de un usuario',
    category: 'fun',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Obtener el usuario mencionado o al que se responde
            let targetJid = null;
            let targetName = 'Usuario';
            
            // Verificar si hay una mención
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
            }
            
            // Verificar si se está respondiendo a un mensaje
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!targetJid && quotedMsg?.participant) {
                targetJid = quotedMsg.participant;
            }
            
            // Si no hay mención ni respuesta, usar el propio usuario
            if (!targetJid) {
                targetJid = msg.key.participant || msg.key.remoteJid;
                targetName = pushName || userNumber || 'Tú';
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🏳️‍🌈', key: msg.key } });
            } catch (e) {}
            
            // Obtener información del usuario objetivo
            try {
                if (targetJid.includes('@s.whatsapp.net')) {
                    const contact = await sock.getContactById(targetJid);
                    if (contact?.name) targetName = contact.name;
                    else if (contact?.notify) targetName = contact.notify;
                }
            } catch (e) {
                console.log('No se pudo obtener el nombre del usuario');
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📸', key: msg.key } });
            } catch (e) {}
            
            // Obtener la foto de perfil del usuario
            let profilePicBuffer = null;
            try {
                const ppUrl = await sock.profilePictureUrl(targetJid, 'image');
                
                if (ppUrl) {
                    const response = await axios.get(ppUrl, {
                        responseType: 'arraybuffer',
                        timeout: 20000,
                        headers: { 'User-Agent': 'Mozilla/5.0' }
                    });
                    profilePicBuffer = Buffer.from(response.data);
                } else {
                    throw new Error('No hay foto de perfil');
                }
            } catch (err) {
                console.log('Error obteniendo foto de perfil:', err.message);
                return await replyWithContext(`*ᰔᩚ* El usuario "${targetName}" no tiene foto de perfil o es privada.`);
            }
            
            if (!profilePicBuffer) {
                return await replyWithContext(`*ᰔᩚ* No se pudo obtener la foto de perfil de "${targetName}".`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '☁️', key: msg.key } });
            } catch (e) {}
            
            // Subir la foto a Catbox
            let catboxUrl;
            try {
                catboxUrl = await uploadCatbox(profilePicBuffer, 'image/jpeg');
                console.log(`✅ Imagen subida a Catbox: ${catboxUrl}`);
            } catch (uploadError) {
                console.error('Error subiendo a Catbox:', uploadError);
                return await replyWithContext(`❌ Error al subir la imagen: ${uploadError.message}`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🎨', key: msg.key } });
            } catch (e) {}
            
            // Aplicar efecto GAY con la API de Delirius
            let gayBuffer;
            try {
                const apiUrl = `https://api.delirius.store/canvas/gay?url=${encodeURIComponent(catboxUrl)}`;
                console.log(`🔄 Aplicando efecto Gay: ${apiUrl}`);
                
                const response = await axios.get(apiUrl, {
                    responseType: 'arraybuffer',
                    timeout: 60000,
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                });
                
                gayBuffer = Buffer.from(response.data);
                
                if (!gayBuffer || gayBuffer.length < 1000) {
                    throw new Error('La respuesta de la API es demasiado pequeña');
                }
            } catch (apiError) {
                console.error('Error aplicando efecto Gay:', apiError.message);
                return await replyWithContext(`❌ Error al aplicar el efecto Gay: ${apiError.message}`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
            } catch (e) {}
            
            // Enviar la imagen con efecto gay
            const caption = ``;
            
            await sock.sendMessage(from, {
                image: gayBuffer,
                caption: caption,
                contextInfo: {
                    mentionedJid: [targetJid],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Efecto Gay aplicado a ${targetName} (${targetJid}) por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en gay:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `❌ *Error:* ${error.message}`;
            if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                errorMsg += `\n\n⏰ La solicitud tardó demasiado. Por favor, intenta de nuevo.`;
            } else if (error.message.includes('foto de perfil')) {
                errorMsg = `❌ ${error.message}`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};