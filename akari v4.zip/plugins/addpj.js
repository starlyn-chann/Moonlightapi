import { agregarPersonajes } from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ROLES_FILE = path.join(__dirname, '..', 'data', 'roles.json');

function loadRoles() {
    try {
        if (fs.existsSync(ROLES_FILE)) {
            const data = fs.readFileSync(ROLES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Error cargando roles:', error);
    }
    return {};
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.replace(/@.+/, '').split(':')[0];
    cleaned = cleaned.replace(/\D/g, '');
    return cleaned;
}

function tieneRol(userNumber, rolesPermitidos) {
    const roles = loadRoles();
    const userData = roles[userNumber];
    if (!userData) return false;
    return rolesPermitidos.includes(userData.rol);
}

export default {
    name: 'addpj',
    alias: ['addpersonaje', 'agregarpj'],
    description: 'Agrega personajes al sistema gacha (Owners, Sub-owners y Mods)',
    category: 'owner',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, userNumber, isOwner } = options;
            
            // Verificar si es owner o tiene rol permitido
            const tieneRolPermitido = tieneRol(userNumber, ['sub-owner', 'mod']);
            
            if (!isOwner && !tieneRolPermitido) {
                return; // No responder nada, silencioso
            }
            
            if (args.length === 0) {
                return await replyWithContext(
                    `「✰」 *AGREGAR PERSONAJES*\n\n` +
                    `📌 *Formato:*\n` +
                    `${config.prefix}addpj <nombre> / <tag> / <género> / <anime>\n\n` +
                    `📌 *Géneros disponibles:*\n` +
                    `• hombre\n` +
                    `• mujer\n` +
                    `• desconocido\n\n` +
                    `📌 *Ejemplo:*\n` +
                    `${config.prefix}addpj Goku / goku / hombre / Dragon Ball\n\n` +
                    `📌 *Múltiples personajes:*\n` +
                    `${config.prefix}addpj Goku / goku / hombre / Dragon Ball\n` +
                    `Naruto / naruto / hombre / Naruto\n` +
                    `Bulma / bulma / mujer / Dragon Ball`
                );
            }
            
            const texto = args.join(' ');
            const lineas = texto.split('\n').filter(line => line.trim());
            
            const personajes = [];
            const errores = [];
            const nombresProcesados = new Set();
            
            for (const linea of lineas) {
                const partes = linea.split('/').map(p => p.trim());
                
                if (partes.length !== 4) {
                    errores.push(`✘ Formato incorrecto: "${linea}"`);
                    continue;
                }
                
                const [nombre, tag, genero, anime] = partes;
                
                if (!nombre || !tag || !genero || !anime) {
                    errores.push(`✘ Datos incompletos: "${linea}"`);
                    continue;
                }
                
                const generoLower = genero.toLowerCase();
                if (!['hombre', 'mujer', 'desconocido'].includes(generoLower)) {
                    errores.push(`✘ Género inválido para "${nombre}": debe ser "hombre", "mujer" o "desconocido"`);
                    continue;
                }
                
                const nombreKey = nombre.trim().toLowerCase();
                if (nombresProcesados.has(nombreKey)) {
                    errores.push(`✘ Duplicado en la lista: "${nombre}"`);
                    continue;
                }
                nombresProcesados.add(nombreKey);
                
                const tagKey = tag.trim().toLowerCase();
                if (nombresProcesados.has(`tag_${tagKey}`)) {
                    errores.push(`✘ Tag duplicado en la lista: "${tag}" (personaje: ${nombre})`);
                    continue;
                }
                nombresProcesados.add(`tag_${tagKey}`);
                
                personajes.push({
                    nombre: nombre.trim(),
                    tag: tag.trim().toLowerCase(),
                    genero: generoLower,
                    anime: anime.trim(),
                    valor: 50
                });
            }
            
            if (personajes.length === 0) {
                return await replyWithContext(
                    `✘ *No se encontraron personajes válidos*\n\n` +
                    errores.join('\n')
                );
            }
            
            const resultados = await agregarPersonajes(personajes);
            
            let mensaje = `「✰」 *RESULTADOS*\n\n`;
            let agregados = 0;
            let duplicados = 0;
            
            for (const r of resultados) {
                if (r.estado === 'agregado') {
                    agregados++;
                    mensaje += `✔ ${r.mensaje}\n`;
                } else {
                    duplicados++;
                    mensaje += `⚠ ${r.mensaje}\n`;
                }
            }
            
            mensaje += `\n✐ *Resumen:*\n`;
            mensaje += `✔ Agregados: ${agregados}\n`;
            if (duplicados > 0) mensaje += `⚠ Duplicados: ${duplicados}\n`;
            
            if (errores.length > 0) {
                mensaje += `\n⚠︎ *Errores:*\n${errores.join('\n')}`;
            }
            
            await replyWithContext(mensaje);
            
            const rol = isOwner ? 'OWNER' : (tieneRolPermitido ? 'MOD/SUB-OWNER' : '');
            console.log(`✅ addpj ejecutado por ${rol}: ${options.pushName || userNumber}`);
            console.log(`📝 Personajes agregados: ${agregados}`);
            
        } catch (error) {
            console.error('❌ Error en addpj:', error);
        }
    }
};