import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `play_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

export default {
    name: 'play',
    alias: ['ytmp3'],
    description: 'Busca y descarga música de YouTube',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir el nombre de una canción o un enlace de YouTube\n> Ejemplo: ${config.prefix}play Bad Bunny`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            // ============ DETECTAR SI ES URL O BÚSQUEDA ============
            const isUrl = query.includes('youtube.com') || query.includes('youtu.be');
            
            let videoUrl = query;
            let searchTerm = query;
            
            // Si es URL, buscar directamente
            if (isUrl) {
                console.log('📥 URL detectada:', query);
            } else {
                // Buscar con API de búsqueda
                console.log('🔍 Buscando:', query);
                
                const searchApi = `https://api.ikyyxd.my.id/search/youtube?apikey=kyzz&query=${encodeURIComponent(query)}`;
                const searchResponse = await axios.get(searchApi, { timeout: 30000 });
                
                if (!searchResponse.data?.status || !searchResponse.data?.result || searchResponse.data.result.length === 0) {
                    await replyWithContext(`「✰」 No se encontraron resultados para "${query}"`);
                    try {
                        await sock.sendMessage(from, { react: { text: '✖️', key: msg.key } });
                    } catch (e) {}
                    return;
                }
                
                const results = searchResponse.data.result;
                
                // Si solo hay un resultado o es una URL, descargar directamente
                if (results.length === 1 || isUrl) {
                    const firstResult = results[0];
                    videoUrl = firstResult.link || firstResult.url;
                    searchTerm = firstResult.title;
                } else {
                    // Múltiples resultados - mostrar lista para seleccionar
                    const rows = results.slice(0, 10).map((video) => {
                        const duration = video.duration || 'N/A';
                        const channel = video.channel || 'Desconocido';
                        return {
                            header: channel,
                            title: video.title || 'Sin título',
                            description: `⧖ ${duration}`,
                            id: `${config.prefix}play ${video.link}`
                        };
                    });
                    
                    const sections = [{
                        title: "RESULTADOS DE BÚSQUEDA",
                        rows: rows
                    }];
                    
                    // Obtener imagen del primer resultado
                    let imageBuffer = null;
                    if (results[0]?.imageUrl || results[0]?.thumbnail) {
                        try {
                            const imgUrl = results[0].imageUrl || results[0].thumbnail;
                            const imgResponse = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
                            imageBuffer = Buffer.from(imgResponse.data);
                        } catch (e) {
                            console.log('Error descargando imagen:', e.message);
                        }
                    }
                    
                    const infoText = ` ꒰ *𝘠𝘛-𝘋𝘖𝘞𝘕𝘓𝘖𝘈𝘋* ꒱
─ ⋅ ⋅ ⋅ ─── ꒰ ♡ ꒱ ─── ⋅ ⋅ ⋅ ─\n\n` +
                                   `˚₊‧꒰ა *b𝗎𝗌𝗊𝗎ᧉdα* › ${query}\n` +
                                   `˚₊‧꒰ა *ꭇᧉ𝗌𝗎𝗅ƚαd𖹭* › ${Math.min(results.length, 10)}`;
                    
                    if (imageBuffer) {
                        await sock.sendMessage(from, {
                            image: imageBuffer,
                            caption: infoText,
                            interactiveButtons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "seleccionar",
                                    sections: sections
                                })
                            }],
                            contextInfo: {
                                mentionedJid: senderJid ? [senderJid] : [],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    } else {
                        await sock.sendMessage(from, {
                            text: infoText,
                            interactiveButtons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "seleccionar",
                                    sections: sections
                                })
                            }],
                            contextInfo: {
                                mentionedJid: senderJid ? [senderJid] : [],
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    }
                    
                    console.log(`🎵 Música buscada: ${query} por ${pushName || userNumber}`);
                    return;
                }
            }
            
            // ============ DESCARGAR CON API AKARI ============
            if (!videoUrl) {
                throw new Error('No se pudo obtener la URL del video');
            }
            
            console.log('📥 Descargando:', videoUrl);
            
            const downloadApi = `https://apiakari.vercel.app/api/downloader/ytmp3?url=${encodeURIComponent(videoUrl)}`;
            const response = await axios.get(downloadApi, { timeout: 30000 });
            
            if (!response.data?.status || !response.data?.data) {
                throw new Error('No se pudo obtener el audio');
            }
            
            const data = response.data.data;
            const title = data.title || 'Sin título';
            const channel = data.channel || 'Desconocido';
            const duration = data.duration || 'N/A';
            const quality = data.quality || '128kbps';
            const size = data.size || 'N/A';
            const thumbnail = data.thumbnail || '';
            const downloadUrl = data.download;
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // ============ DESCARGAR IMAGEN ============
            let imageBuffer = null;
            if (thumbnail) {
                try {
                    const imgResponse = await axios.get(thumbnail, { responseType: 'arraybuffer', timeout: 15000 });
                    imageBuffer = Buffer.from(imgResponse.data);
                } catch (e) {
                    console.log('Error descargando imagen:', e.message);
                }
            }
            
            // ============ ENVIAR INFORMACIÓN ============
            const infoText = `︵⏜⌒⁡ ᥀ ❀ ⁔⭐⁔⁣⁣⁣⁡⁡⁣   ᥀ ✿ ⌒⏜︵\n\n` +
                           `🌷ׅᩙ♡ *ƚiƚ𝗎𝗅𖹭* › ${title}\n` +
                           `🌷ׅᩙ♡ *cα𝗇α𝗅* › ${channel}\n` +
                           `🌷ׅᩙ♡ *d𝗎ꭇαcꪱo𝗇* › ${duration}\n` +
                           `🌷ׅᩙ♡ *cα𝗅ꪱdαd* › ${quality}\n` +
                           `🌷ׅᩙ♡ *ƚα𝗆αᥒ̃𖹭* › ${size}`;
            
            if (imageBuffer) {
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: infoText,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, {
                    text: infoText,
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            // ============ DESCARGAR Y ENVIAR AUDIO ============
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            const audioResponse = await axios.get(downloadUrl, {
                responseType: 'arraybuffer',
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const audioBuffer = Buffer.from(audioResponse.data);
            const cleanTitle = title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
            
            await sock.sendMessage(from, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                fileName: `${cleanTitle}.mp3`,
                ptt: false,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Música descargada: ${title} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en play:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}`);
            } catch (e) {}
        }
    }
};