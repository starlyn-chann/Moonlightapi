import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function saveTimers(timers) {
    try {
        fs.writeFileSync(TIMER_FILE, JSON.stringify(timers, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando timeeconomy:', e);
        return false;
    }
}

function getTimerKey(userNumber, groupId) {
    return `minar_${userNumber}_${groupId}`;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'minar',
    alias: ['mine'],
    description: 'Mina y gana entre 10,000 y 50,000 monedas',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            
            const timerKey = getTimerKey(userNumber, from);
            const now = Date.now();
            const cooldownTime = 3 * 60 * 1000;
            
            let timers = loadTimers();
            
            if (timers[timerKey]) {
                const lastUsed = timers[timerKey];
                const tiempoRestante = cooldownTime - (now - lastUsed);
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.floor((tiempoRestante % 60000) / 1000);
                    return await replyWithContext(`❀ *Espera un poco*\n> Puedes minar de nuevo en ${minutos}m ${segundos}s`);
                }
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const ganancia = Math.floor(Math.random() * (50000 - 10000 + 1)) + 10000;
            
            const minas = [
                'Encontraste un yacimiento de oro ⛏️',
                'Descubriste una veta de diamantes 💎',
                'Excavaste una mina de esmeraldas 🟢',
                'Hallaste un tesoro enterrado 🏴‍☠️',
                'Encontraste una cueva con gemas 💠',
                'Descubriste una mina de plata 🥈',
                'Excavaste y encontraste rubíes ❤️',
                'Hallaste una mina de zafiros 💙',
                'Encontraste un bloque de oro macizo 🪙',
                'Descubriste una mina abandonada con riquezas 🏚️',
                'Excavaste y encontraste un cofre del tesoro 📦',
                'Hallaste una veta de cristal de luna 🌙',
                'Encontraste una mina de carbón con diamantes ocultos 🔥',
                'Descubriste una caverna con estalactitas de oro 🏔️',
                'Excavaste y encontraste una estatua de oro 🗿',
                'Hallaste una mina de platino ⚪',
                'Encontraste un meteorito con minerales raros ☄️',
                'Descubriste una mina de cobre con oro incrustado 🪙',
                'Excavaste y encontraste joyas antiguas 👑',
                'Hallaste un depósito de cristales mágicos ✨'
            ];
            
            const mina = minas[Math.floor(Math.random() * minas.length)];
            
            economy[from][userNumber].dinero += ganancia;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            timers[timerKey] = now;
            saveTimers(timers);
            
            await replyWithContext(`❀ *Minando* ⛏️\n> ${mina}\n> *Ganaste* ${formatNumber(ganancia)} ${moneda}\n\n*Billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en minar:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};