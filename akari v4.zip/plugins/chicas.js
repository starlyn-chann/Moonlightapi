import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para leer el archivo JSON
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Función para cargar la configuración NSFW
function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

export default {
    name: 'chicas',
    alias: ['girls'],
    description: 'Envía imágenes NSFW de chicas',
    category: 'nsfw',

    async execute(sock, msg, options) {
        try {
            const { config, pushName, userNumber, replyWithContext, isGroup } = options;
            const from = msg.key.remoteJid;

            // --- VALIDACIÓN NSFW ---
            // Si es un grupo, verificamos si el NSFW está activo
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------

            // 1. Reacción de proceso
            try {
                await sock.sendMessage(from, { react: { text: '🍑', key: msg.key } });
            } catch (e) {}

            console.log(`🔍 Obteniendo imagen NSFW para ${pushName || userNumber}...`);

            // 2. URL de la API
            const apiUrl = `https://api.delirius.store/nsfw/girls`;

            // 3. Envío de la imagen con contextInfo y diseño mejorado
            await sock.sendMessage(from, {
                image: { url: apiUrl },
                caption: `🔞 *GIRLS NSFW*\n> Disfruta, ${pushName || 'usuario'}`,
                footer: config.canalNombre || 'Made By StarLyn',
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });

            // 4. Reacción de éxito
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

            console.log(`✅ Comando chicas ejecutado con éxito`);

        } catch (error) {
            console.error('❌ Error en comando chicas:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`♡ Ocurrió un error al obtener la imagen: ${error.message}`);
            } catch (e) {}
        }
    }
};