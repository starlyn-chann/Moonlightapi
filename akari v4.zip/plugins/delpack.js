import { obtenerPacksUsuario, eliminarPack } from '../lib/mongoose.js';

export default {
    name: 'delpack',
    alias: ['removepack', 'borrarpack'],
    description: 'Elimina un pack de stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid } = options;
            
            const args = options.args || [];
            const packName = args.join(' ').trim();
            
            if (!packName) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre del pack\n> Ejemplo: ${config.prefix}delpack Mis Stickers`);
            }
            
            // Obtener packs del usuario desde MongoDB
            const packs = await obtenerPacksUsuario(userNumber);
            
            if (!packs || packs.length === 0) {
                return await replyWithContext(`「✰」No tienes ningún pack creado`);
            }
            
            const packExists = packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (!packExists) {
                return await replyWithContext(`「✰」No tienes un pack llamado "${packName}"\n> Usa ${config.prefix}packlist para ver tus packs`);
            }
            
            // Eliminar pack de MongoDB
            const resultado = await eliminarPack(userNumber, packName);
            
            if (!resultado) {
                return await replyWithContext(`❌ Error al eliminar el pack. Por favor, intenta nuevamente.`);
            }
            
            await replyWithContext(`「✰」Pack \`${packName}\` eliminado exitosamente`);
            
        } catch (error) {
            console.error('❌ Error en delpack:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};