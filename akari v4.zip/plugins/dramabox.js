import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `dramabox_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

// Función para buscar drama por nombre
async function searchDrama(query) {
    try {
        const apiUrl = `https://api-nanzz.my.id/docs/api/nonton-&-baca/dramabox/search.php?q=${encodeURIComponent(query)}`;
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (response.data?.status === true && response.data?.result?.results) {
            return response.data.result.results;
        }
        return [];
    } catch (error) {
        console.error('Error buscando drama:', error.message);
        return [];
    }
}

// Función para obtener capítulos del drama
async function getDramaChapters(id, slug) {
    try {
        const apiUrl = `https://api-nanzz.my.id/docs/api/nonton-&-baca/dramabox/download.php?id=${id}&slug=${slug}`;
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (response.data?.status === true && response.data?.result) {
            return response.data.result;
        }
        return null;
    } catch (error) {
        console.error('Error obteniendo capítulos:', error.message);
        return null;
    }
}

// Función para descargar video
async function downloadVideo(videoUrl, outputPath) {
    return new Promise(async (resolve, reject) => {
        try {
            const response = await axios({
                method: 'GET',
                url: videoUrl,
                responseType: 'stream',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://www.dramabox.com/'
                },
                timeout: 120000
            });
            
            const writer = fs.createWriteStream(outputPath);
            response.data.pipe(writer);
            
            writer.on('finish', () => resolve(outputPath));
            writer.on('error', reject);
        } catch (error) {
            reject(error);
        }
    });
}

// ============ FUNCIÓN PARA VERIFICAR SI ES BOT PRINCIPAL ============
function isMainBot(sock) {
    try {
        let botNumber = '';
        if (sock.phoneNumber) {
            botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
        } else if (sock.user?.id) {
            botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
        }
        
        if (!botNumber) return false;
        
        // Verificar si existe config en info/
        const infoConfigPath = path.join(process.cwd(), 'info', botNumber, 'config.js');
        if (fs.existsSync(infoConfigPath)) {
            return true;
        }
        
        // Verificar si existe creds en sessions/ (bot principal)
        const credsPath = path.join(process.cwd(), 'sessions', 'creds.json');
        if (fs.existsSync(credsPath)) {
            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
            if (creds?.me?.id) {
                const mainNumber = creds.me.id.split(':')[0].replace(/[^0-9]/g, '');
                if (mainNumber === botNumber) {
                    return true;
                }
            }
        }
        
        return false;
    } catch (e) {
        return false;
    }
}
// ==============================================================

export default {
    name: 'dramabox',
    alias: ['drama', 'buscardrama'],
    description: 'Busca y descarga capítulos de drama',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, senderJid, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // ============ VERIFICAR QUE SEA PREMIUM O PRINCIPAL ============
            // Obtener número del bot actual
            let currentBotNumber = '';
            if (sock.phoneNumber) {
                currentBotNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
            } else if (sock.user?.id) {
                currentBotNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
            }
            
            // Verificar si es el bot principal
            const esBotPrincipal = isMainBot(sock);
            
            // Verificar si es premium por config
            const esPremium = config.premium === true;
            
            // Verificar si es premium desde el archivo config en subs/
            let esPremiumPorConfig = false;
            if (currentBotNumber) {
                try {
                    const configPath = path.join(process.cwd(), 'subs', currentBotNumber, 'config.js');
                    if (fs.existsSync(configPath)) {
                        const content = fs.readFileSync(configPath, 'utf8');
                        const match = content.match(/premium:\s*(true|false)/);
                        if (match && match[1] === 'true') {
                            esPremiumPorConfig = true;
                        }
                    }
                } catch (e) {}
            }
            
            // Si es sub-bot y NO es premium → denegar
            // Si es sub-bot y ES premium → permitir
            // Si es bot principal → permitir (SIEMPRE)
            if (!esBotPrincipal && !esPremium && !esPremiumPorConfig) {
                return await replyWithContext(`❀ *Este comando solo está disponible en bots premium*`);
            }
            // ================================================================
            
            const query = args.join(' ').trim();
            
            if (!query) {
                return await replyWithContext(`「✰」 Debes escribir el nombre de un drama\n> Ejemplo: ${config.prefix}dramabox rey payaso`);
            }
            
            // Verificar si es selección de capítulo (formato: id|slug|episodio)
            if (query.includes('|') && query.split('|').length === 3) {
                const [id, slug, episodeNum] = query.split('|');
                
                try {
                    await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
                    
                    const dramaInfo = await getDramaChapters(id, slug);
                    
                    if (!dramaInfo || !dramaInfo.downloads) {
                        await replyWithContext(`「✰」 No se encontró información del drama`);
                        return;
                    }
                    
                    const episode = dramaInfo.downloads.find(ep => ep.episode === parseInt(episodeNum));
                    
                    if (!episode || !episode.mp4) {
                        await replyWithContext(`「✰」 No se encontró el capítulo ${episodeNum}`);
                        return;
                    }
                    
                    await replyWithContext(`「✰」 Descargando capítulo ${episodeNum}...\n> Esto puede tomar unos minutos`);
                    
                    const outputPath = getTempFilePath('mp4');
                    await downloadVideo(episode.mp4, outputPath);
                    
                    const videoBuffer = fs.readFileSync(outputPath);
                    const fileName = `${slug}_Ep${episodeNum}.mp4`;
                    
                    await sock.sendMessage(from, {
                        document: videoBuffer,
                        mimetype: 'video/mp4',
                        fileName: fileName,
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    fs.unlinkSync(outputPath);
                    
                    try {
                        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                    } catch (e) {}
                    
                    console.log(`✅ Drama descargado: ${slug} Ep${episodeNum} por ${pushName || userNumber}`);
                    
                } catch (error) {
                    console.error('Error descargando:', error);
                    await replyWithContext(`「✰」 Error al descargar: ${error.message}`);
                    try {
                        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                    } catch (e) {}
                }
                return;
            }
            
            // Buscar drama por nombre
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            const results = await searchDrama(query);
            
            if (results.length === 0) {
                await replyWithContext(`「✰」 No se encontraron dramas para "${query}"`);
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            const randomIndex = Math.floor(Math.random() * results.length);
            const selectedDrama = results[randomIndex];
            
            await replyWithContext(`「✰」 *${selectedDrama.title}*\n> ${selectedDrama.description?.substring(0, 150)}...\n\n📥 Obteniendo capítulos...`);
            
            const dramaInfo = await getDramaChapters(selectedDrama.id, selectedDrama.title_en);
            
            if (!dramaInfo || !dramaInfo.downloads || dramaInfo.downloads.length === 0) {
                await replyWithContext(`「✰」 No se encontraron capítulos para este drama`);
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return;
            }
            
            const rows = dramaInfo.downloads.map(ep => ({
                title: `Capítulo ${ep.episode}: ${ep.title?.replace(/[^\x00-\x7F]/g, '') || `Episodio ${ep.episode}`}`,
                description: `Descargar capítulo ${ep.episode}`,
                id: `${config.prefix}dramabox ${selectedDrama.id}|${selectedDrama.title_en}|${ep.episode}`
            }));
            
            const sections = [{
                title: `📺 CAPÍTULOS DISPONIBLES (${dramaInfo.total || dramaInfo.downloads.length})`,
                rows: rows.slice(0, 20)
            }];
            
            if (selectedDrama.cover) {
                try {
                    const imgResponse = await axios.get(selectedDrama.cover, { responseType: 'arraybuffer', timeout: 15000 });
                    const imgBuffer = Buffer.from(imgResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: imgBuffer,
                        caption: `「✰」 *${selectedDrama.title}*\n> ${selectedDrama.description?.substring(0, 200)}...\n> 📊 Capítulos: ${dramaInfo.total || dramaInfo.downloads.length}\n> ⭐ Rating: ${selectedDrama.rating || 'N/A'}\n> 👁️ Vistas: ${selectedDrama.views?.toLocaleString() || 'N/A'}\n\n📺 Selecciona un capítulo para descargar:`,
                        interactiveButtons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "📺 Seleccionar capítulo",
                                sections: sections
                            })
                        }],
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                } catch (e) {
                    await sock.sendMessage(from, {
                        text: `「✰」 *${selectedDrama.title}*\n> ${selectedDrama.description?.substring(0, 200)}...\n> 📊 Capítulos: ${dramaInfo.total || dramaInfo.downloads.length}\n> ⭐ Rating: ${selectedDrama.rating || 'N/A'}\n> 👁️ Vistas: ${selectedDrama.views?.toLocaleString() || 'N/A'}\n\n📺 Selecciona un capítulo para descargar:`,
                        interactiveButtons: [{
                            name: "single_select",
                            buttonParamsJson: JSON.stringify({
                                title: "📺 Seleccionar capítulo",
                                sections: sections
                            })
                        }],
                        contextInfo: {
                            mentionedJid: senderJid ? [senderJid] : [],
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                }
            } else {
                await sock.sendMessage(from, {
                    text: `「✰」 *${selectedDrama.title}*\n> ${selectedDrama.description?.substring(0, 200)}...\n> 📊 Capítulos: ${dramaInfo.total || dramaInfo.downloads.length}\n> ⭐ Rating: ${selectedDrama.rating || 'N/A'}\n> 👁️ Vistas: ${selectedDrama.views?.toLocaleString() || 'N/A'}\n\n📺 Selecciona un capítulo para descargar:`,
                    interactiveButtons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "📺 Seleccionar capítulo",
                            sections: sections
                        })
                    }],
                    contextInfo: {
                        mentionedJid: senderJid ? [senderJid] : [],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`📺 Drama encontrado: ${selectedDrama.title} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en dramabox:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};