import axios from 'axios';

export default {
    name: 'billieeilish',
    alias: ['billie'],
    description: 'Envía una imagen aleatoria de Billie Eilish',
    category: 'image',
    
    async execute(sock, msg, options) {
        try {
            const { config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            const apiUrl = 'https://siriusfamosos.vercel.app/billie.html';
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'image/jpeg,image/png,image/webp,image/*,*/*;q=0.8',
                    'Accept-Encoding': 'gzip, deflate, br'
                },
                maxRedirects: 5,
                decompress: true
            });
            
            // Verificar que el buffer sea válido
            if (!response.data || response.data.length < 1000) {
                throw new Error('La imagen parece estar corrupta o vacía');
            }
            
            const imageBuffer = Buffer.from(response.data);
            
            // Verificar si es realmente una imagen (primeros bytes de JPEG: FF D8)
            const isJPEG = imageBuffer[0] === 0xFF && imageBuffer[1] === 0xD8;
            
            if (!isJPEG) {
                // Si no es JPEG, intentar buscar la URL de la imagen en el HTML
                const html = response.data.toString('utf-8');
                const imageRegex = /https:\/\/files\.catbox\.moe\/[a-zA-Z0-9]+\.jpeg/g;
                const matches = html.match(imageRegex);
                
                if (matches && matches.length > 0) {
                    const randomImageUrl = matches[Math.floor(Math.random() * matches.length)];
                    const imgResponse = await axios.get(randomImageUrl, {
                        responseType: 'arraybuffer',
                        timeout: 30000,
                        headers: { 'accept': '*/*' }
                    });
                    
                    const finalBuffer = Buffer.from(imgResponse.data);
                    
                    await sock.sendMessage(from, {
                        image: finalBuffer,
                        caption: '',
                        contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: config.canalId || '',
                                serverMessageId: 0,
                                newsletterName: config.canalNombre || ''
                            }
                        }
                    }, { quoted: msg });
                    
                    try {
                        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                    } catch (e) {}
                    
                    console.log(`✅ Billie Eilish enviado a ${pushName || userNumber}`);
                    return;
                }
                
                throw new Error('No se pudo obtener una imagen válida');
            }
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: '',
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Billie Eilish enviado a ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en billieeilish:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: No se pudo obtener la imagen de Billie Eilish`);
            } catch (e) {}
        }
    }
};