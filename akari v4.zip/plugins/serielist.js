import { obtenerTodosPersonajes } from '../lib/gacha.js';

export default {
    name: 'serielist',
    alias: ['slist', 'animelist', 'listseries'],
    description: 'Lista todas las series/animes disponibles en el gacha',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando serielist...');
            
            const { config, replyWithContext, args, userNumber } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // ============ OBTENER TODOS LOS PERSONAJES ============
            const todosPersonajes = await obtenerTodosPersonajes();
            
            if (!todosPersonajes || todosPersonajes.length === 0) {
                return await replyWithContext(`❀ No hay personajes en la base de datos\n> Agrega personajes con ${config.prefix}addpj`);
            }
            
            // ============ AGRUPAR POR SERIE ============
            const seriesMap = {};
            
            for (const pj of todosPersonajes) {
                if (!pj.anime) continue;
                const anime = pj.anime;
                if (!seriesMap[anime]) {
                    seriesMap[anime] = {
                        nombre: anime,
                        personajes: []
                    };
                }
                seriesMap[anime].personajes.push(pj);
            }
            
            const seriesKeys = Object.keys(seriesMap).sort();
            const totalSeries = seriesKeys.length;
            
            // ============ PAGINACIÓN ============
            const page = parseInt(args[0]) || 1;
            const perPage = 20;
            const totalPages = Math.max(1, Math.ceil(totalSeries / perPage));
            
            if (page < 1 || page > totalPages) {
                return await replyWithContext(`❀ Página no válida. Hay un total de *${totalPages}* páginas.`);
            }
            
            const start = (page - 1) * perPage;
            const end = Math.min(start + perPage, totalSeries);
            const seriesPage = seriesKeys.slice(start, end);
            // ================================================================
            
            // ============ CREAR MENSAJE ============
            let mensaje = `*❏ Lista de series (${totalSeries}):*\n\n`;
            
            for (const key of seriesPage) {
                const serie = seriesMap[key];
                const nombre = serie.nombre || key;
                const cantidad = serie.personajes.length;
                mensaje += `» *${nombre}* (${cantidad})\n`;
            }
            
            mensaje += `\n> • _Página ${page}/${totalPages}_`;
            // ================================================================
            
            await replyWithContext(mensaje);
            
            console.log(`✅ serielist ejecutado: ${totalSeries} series, página ${page}/${totalPages}`);
            
        } catch (error) {
            console.error('❌ Error en serielist:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};