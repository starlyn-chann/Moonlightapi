import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const TIMER_FILE = path.join(__dirname, '..', 'data', 'timeeconomy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function loadTimers() {
    try {
        if (fs.existsSync(TIMER_FILE)) {
            const data = fs.readFileSync(TIMER_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando timeeconomy:', e);
    }
    return {};
}

function saveTimers(timers) {
    try {
        fs.writeFileSync(TIMER_FILE, JSON.stringify(timers, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando timeeconomy:', e);
        return false;
    }
}

function getTimerKey(userNumber, groupId) {
    return `chambear_${userNumber}_${groupId}`;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'chambear',
    alias: ['chamba'],
    description: 'Haz una chamba aleatoria y gana dinero',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            const moneda = config.moneda || '💰';
            
            const timerKey = getTimerKey(userNumber, from);
            const now = Date.now();
            const cooldownTime = 3 * 60 * 1000;
            
            let timers = loadTimers();
            
            if (timers[timerKey]) {
                const lastUsed = timers[timerKey];
                const tiempoRestante = cooldownTime - (now - lastUsed);
                if (tiempoRestante > 0) {
                    const minutos = Math.floor(tiempoRestante / 60000);
                    const segundos = Math.floor((tiempoRestante % 60000) / 1000);
                    return await replyWithContext(`❀ *Espera un poco*\n> Puedes chambear de nuevo en ${minutos}m ${segundos}s`);
                }
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const ganancia = Math.floor(Math.random() * (3000 - 10 + 1)) + 10;
            
            const chambas = [
                'Caminaste perros en el parque 🐕',
                'Cuidaste niños por unas horas 👶',
                'Ayudaste a una señora a cruzar la calle 🚶‍♀️',
                'Lavaste carros en la esquina 🚗',
                'Repartiste volantes en el centro 📄',
                'Limpiaste vidrios de autos 🪟',
                'Cortaste el césped de un vecino 🌿',
                'Pintaste una cerca 🎨',
                'Organizaste una venta de garaje 🏷️',
                'Entregaste paquetes en bicicleta 📦',
                'Ayudaste en una mudanza 🚚',
                'Hiciste mandados para una tienda 🛒',
                'Cuidaste una tienda por unas horas 🏪',
                'Recogiste frutas en un huerto 🍎',
                'Limpiaste una casa abandonada 🧹',
                'Arreglaste una bicicleta 🚲',
                'Ayudaste a un músico callejero 🎸',
                'Hiciste fila por alguien 🎫',
                'Cuidaste una mascota por el día 🐱',
                'Ayudaste a cargar bolsas del supermercado 🛍️',
                'Barriste la vereda de tu cuadra 🧹',
                'Ordenaste un almacén 📦',
                'Ayudaste a un anciano con sus compras 👴',
                'Regaste plantas en un jardín 🌱',
                'Limpieza de una piscina 🏊',
                'Ayudaste en un evento comunitario 🎪',
                'Hiciste entregas en moto 🏍️',
                'Cuidaste el puesto de un vendedor 🥤',
                'Ayudaste a una mamá con su carrito 🛒',
                'Llevaste comida a domicilio 🍕',
                'Ayudaste a reparar una cerca 🔧',
                'Limpiaste un parque 🏞️',
                'Ayudaste a un pintor de casas 🏡',
                'Cuidaste una tienda de mascotas 🐾',
                'Ayudaste a un agricultor con sus animales 🐄',
                'Hiciste mandados para una oficina 📋',
                'Ayudaste a un fotógrafo como asistente 📸',
                'Ayudaste a un DJ a cargar sus equipos 🎧',
                'Fuiste extra en un video musical 🎬',
                'Ayudaste a un artista callejero 🎭',
                'Ayudaste a instalar una feria 🎡',
                'Cuidaste un puesto de limonada 🍋',
                'Ayudaste a un repartidor de periódicos 📰',
                'Ayudaste a un electricista con sus herramientas ⚡',
                'Ayudaste a un plomero con una emergencia 🔧',
                'Ayudaste a un carpintero a cargar madera 🪵',
                'Ayudaste a un jardinero a podar árboles 🌳',
                'Ayudaste a un albañil a cargar ladrillos 🧱',
                'Ayudaste a un pintor de autos 🎨',
                'Ayudaste a un chef a preparar ingredientes 🍳',
                'Ayudaste a un panadero a hornear pan 🍞',
                'Ayudaste a un pescador a limpiar pescados 🎣',
                'Ayudaste a un joyero a limpiar joyas 💎',
                'Ayudaste a un relojero a arreglar relojes ⌚',
                'Ayudaste a un zapatero a reparar zapatos 👞',
                'Ayudaste a un sastre a tomar medidas 📐',
                'Ayudaste a un mecánico a cambiar llantas 🔧',
                'Ayudaste a un gasolinero a echar gasolina ⛽',
                'Ayudaste a un lavaplatos en un restaurante 🍽️',
                'Ayudaste a un repartidor de pizzas 🍕',
                'Ayudaste a un florista a hacer ramos 🌸',
                'Ayudaste a un cerrajero a hacer llaves 🔑',
                'Ayudaste a un taxista a limpiar su coche 🚖',
                'Ayudaste a un heladero a vender helados 🍦',
                'Ayudaste a un frutero a vender frutas 🍉',
                'Ayudaste a un panadero a vender pan 🥖',
                'Ayudaste a un carnicero a cortar carne 🥩'
            ];
            
            const chamba = chambas[Math.floor(Math.random() * chambas.length)];
            
            economy[from][userNumber].dinero += ganancia;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            timers[timerKey] = now;
            saveTimers(timers);
            
            await replyWithContext(`❀ *Chamba realizada*\n> ${chamba}\n> *Ganaste* ${formatNumber(ganancia)} ${moneda}\n\n*Billetera:* ${formatNumber(economy[from][userNumber].dinero)} ${moneda}`);
            
        } catch (error) {
            console.error('❌ Error en chambear:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};