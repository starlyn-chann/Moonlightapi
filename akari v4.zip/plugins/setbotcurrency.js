import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function getBotConfigPath(sock) {
    let botNumber = '';
    if (sock.phoneNumber) {
        botNumber = sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        botNumber = sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    
    if (!botNumber) return null;
    
    const subBotPath = path.join(process.cwd(), 'subs', botNumber, 'config.js');
    if (fs.existsSync(subBotPath)) {
        return { path: subBotPath, type: 'sub-bot', number: botNumber };
    }
    
    const mainPath = path.join(process.cwd(), 'config.js');
    if (fs.existsSync(mainPath)) {
        return { path: mainPath, type: 'main', number: botNumber };
    }
    
    return null;
}

export default {
    name: 'setbotcurrency',
    alias: ['setmoneda', 'currency'],
    description: 'Cambia la moneda del bot (solo dueño del bot)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, replyWithContext, userNumber } = options;
            
            const userNumberClean = cleanNumber(senderNumber || userNumber || '');
            const botownerClean = config.botowner ? cleanNumber(config.botowner) : '';
            
            if (!botownerClean || userNumberClean !== botownerClean) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede cambiar la moneda*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 *Formato incorrecto*\n\n> ${config.prefix}setbotcurrency COP$\n> ${config.prefix}setbotcurrency 💰\n> ${config.prefix}setbotcurrency Golosinas`);
            }
            
            const botConfig = getBotConfigPath(sock);
            if (!botConfig) {
                throw new Error('No se pudo encontrar la configuración del bot');
            }
            
            const configPath = botConfig.path;
            
            if (!fs.existsSync(configPath)) {
                throw new Error(`No se encontró configuración en: ${configPath}`);
            }
            
            const nuevaMoneda = args.join(' ').trim();
            
            if (nuevaMoneda.length > 20) {
                return await replyWithContext(`*ᰔᩚ* *La moneda no puede tener más de 20 caracteres*`);
            }
            
            let configContent = fs.readFileSync(configPath, 'utf8');
            
            // Buscar moneda existente
            const monedaRegex = /(moneda:\s*['"])([^'"]*)(['"])/;
            
            let newConfigContent;
            if (monedaRegex.test(configContent)) {
                // Si ya existe moneda, reemplazar
                newConfigContent = configContent.replace(monedaRegex, `$1${nuevaMoneda}$3`);
            } else {
                // Si no existe, agregarlo después de prefix o al inicio
                const prefixRegex = /(prefix:\s*['"][^'"]+['"])/;
                if (prefixRegex.test(configContent)) {
                    newConfigContent = configContent.replace(prefixRegex, `$1,\n  moneda: '${nuevaMoneda}'`);
                } else {
                    newConfigContent = configContent.replace(/(export default\s*\{)/, `$1\n  moneda: '${nuevaMoneda}',`);
                }
            }
            
            fs.writeFileSync(configPath, newConfigContent, 'utf8');
            
            // Actualizar memoria
            if (options.config) {
                options.config.moneda = nuevaMoneda;
            }
            
            await replyWithContext(`⭐ Moneda actualizada\n\n> Nueva moneda: ${nuevaMoneda}`);
            
        } catch (error) {
            console.error('Error en setbotcurrency:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};