import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setusername',
    alias: ['setbotname'],
    description: 'Cambia el nombre de usuario del bot (solo dueño del bot)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, replyWithContext, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Limpiar números
            let userNumberClean = (senderNumber || userNumber || '').toString().replace(/\D/g, '');
            let botownerClean = config.botowner ? config.botowner.toString().replace(/\D/g, '') : '';
            
            // Verificar si es botowner
            if (!botownerClean || userNumberClean !== botownerClean) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede cambiar el nombre de usuario*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`《✧》 *Ingresa el nuevo nombre del bot*\n\nEjemplo: *${config.prefix}setusername Mi Nuevo Nombre*`);
            }
            
            const newName = args.join(' ');
            
            if (newName.length > 25) {
                return await replyWithContext(`《✧》 *El nombre del bot no debe pasar los 25 caracteres*`);
            }
            
            await sock.updateProfileName(newName);
            
            await replyWithContext(`《✧》 *El nombre del bot se ha cambiado a "${newName}"*\n> Por el dueño del bot`);
            
        } catch (error) {
            console.error('Error en setusername:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};