import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

async function getUserProfilePicture(sock, jid) {
    try {
        const ppUrl = await sock.profilePictureUrl(jid, 'image');
        return ppUrl;
    } catch (e) {
        return null;
    }
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'bal',
    alias: ['bank'],
    description: 'Ver el balance de un usuario',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, senderJid, pushName, args, usersDb } = options;
            const from = msg.key.remoteJid;
            
            let targetUser = userNumber;
            let targetName = pushName || 'Usuario';
            let targetJid = senderJid;
            
            let mentionedUser = null;
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg) {
                const quotedParticipant = msg.message.extendedTextMessage.contextInfo.participant;
                if (quotedParticipant) {
                    mentionedUser = quotedParticipant;
                }
            }
            
            if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                const mentions = msg.message.extendedTextMessage.contextInfo.mentionedJid;
                if (mentions && mentions.length > 0) {
                    mentionedUser = mentions[0];
                }
            }
            
            if (!mentionedUser && args && args.length > 0) {
                const arg = args[0].replace(/@/g, '').replace(/\D/g, '');
                if (arg) {
                    mentionedUser = `${arg}@s.whatsapp.net`;
                }
            }
            
            if (mentionedUser) {
                let cleanMentioned = cleanNumber(mentionedUser);
                
                if (usersDb) {
                    const userFound = usersDb.find(user => user.number === cleanMentioned);
                    if (userFound) {
                        targetName = userFound.pushName || 'Usuario';
                    } else {
                        try {
                            const contact = await sock.contactQuery(mentionedUser);
                            if (contact) {
                                targetName = contact.notify || contact.name || 'Usuario';
                            }
                        } catch (e) {
                            targetName = cleanMentioned;
                        }
                    }
                } else {
                    try {
                        const contact = await sock.contactQuery(mentionedUser);
                        if (contact) {
                            targetName = contact.notify || contact.name || 'Usuario';
                        }
                    } catch (e) {
                        targetName = cleanMentioned;
                    }
                }
                
                targetUser = cleanMentioned;
                targetJid = mentionedUser;
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            
            if (!economy[from][targetUser]) {
                economy[from][targetUser] = {
                    dinero: 0,
                    banco: 0,
                    nombre: targetName
                };
                saveEconomy(economy);
            }
            
            const dinero = economy[from][targetUser].dinero || 0;
            const banco = economy[from][targetUser].banco || 0;
            const total = dinero + banco;
            const moneda = config.moneda || '💰';
            
            let profilePic = 'https://files.catbox.moe/kt6drf.jpeg';
            if (targetJid) {
                try {
                    const ppUrl = await getUserProfilePicture(sock, targetJid);
                    if (ppUrl) profilePic = ppUrl;
                } catch (e) {}
            }
            
            let imageBuffer;
            try {
                const response = await axios.get(profilePic, { responseType: 'arraybuffer' });
                imageBuffer = Buffer.from(response.data);
            } catch (e) {
                const defaultResponse = await axios.get('https://files.catbox.moe/kt6drf.jpeg', { responseType: 'arraybuffer' });
                imageBuffer = Buffer.from(defaultResponse.data);
            }
            
            const caption = `⡞   ⃟̸̷⃨★᪲᪲᪲ *Balance :* ${targetName}

🦦ᩧ͚┸ *Billetera :* ${formatNumber(dinero)} *${moneda}*
🦦ᩧ͚┸ *Banco :* ${formatNumber(banco)} ${moneda}

   ᮫ׁ🌈ᩚִ𑇓𑇖ֹׁ *Total :* ${formatNumber(total)} ${moneda}`;
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: caption,
                contextInfo: {
                    mentionedJid: [targetJid].filter(Boolean),
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
        } catch (error) {
            console.error('❌ Error en bal:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};