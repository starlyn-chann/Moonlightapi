import { gdriveInfo, gdriveDownload } from '@danonino/starlyn-scraper';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'testv2',
    alias: ['gdrive', 'googledrive'],
    description: 'Descarga archivos de Google Drive',
    category: 'downloader',
    
    async execute(sock, msg, options) {
        let filePath = null;
        
        try {
            const { args, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const query = args.join(' ').trim();
            if (!query) {
                return await replyWithContext(
                    '📁 GOOGLE DRIVE DOWNLOADER\n\n' +
                    'Sintaxis:\n' +
                    '.testv2 info <url_o_id>\n' +
                    '.testv2 descargar <url_o_id>\n\n' +
                    'Ejemplos:\n' +
                    '.testv2 info https://drive.google.com/file/d/xxxxx/view\n' +
                    '.testv2 descargar https://drive.google.com/file/d/xxxxx/view\n' +
                    '.testv2 info xxxxx\n\n' +
                    '📌 Descarga archivos de Google Drive'
                );
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📁', key: msg.key } });
            } catch (e) {}
            
            const parts = query.split(' ');
            const comando = parts[0].toLowerCase();
            const parametro = parts.slice(1).join(' ');
            
            // ============ INFO ============
            if (comando === 'info') {
                if (!parametro) {
                    return await replyWithContext('❌ Debes proporcionar una URL o ID de Google Drive\n\nEjemplo: .testv2 info https://drive.google.com/file/d/xxxxx/view');
                }
                
                await replyWithContext('📡 Obteniendo información del archivo...\n⏳ Por favor espera...');
                
                try {
                    const result = await gdriveInfo(parametro);
                    console.log('📦 RESPUESTA INFO:', JSON.stringify(result, null, 2));
                    
                    let mensaje = '📁 *INFORMACIÓN DEL ARCHIVO*\n\n';
                    mensaje += `📌 *Nombre:* ${result.name || 'Desconocido'}\n`;
                    mensaje += `🆔 *ID:* ${result.fileId}\n`;
                    mensaje += `📥 *Descarga:* ${result.download}\n`;
                    mensaje += `🔗 *URL:* ${result.url}`;
                    
                    await replyWithContext(mensaje);
                    
                    // Mostrar JSON
                    const jsonString = JSON.stringify(result, null, 2);
                    await replyWithContext('📦 *JSON COMPLETO:*\n```json\n' + jsonString + '\n```');
                    
                } catch (e) {
                    console.error('❌ Error en info:', e);
                    await replyWithContext('❌ Error al obtener información: ' + e.message);
                }
                return;
            }
            
            // ============ DESCARGAR ============
            if (comando === 'descargar' || comando === 'download' || comando === 'dl') {
                if (!parametro) {
                    return await replyWithContext('❌ Debes proporcionar una URL o ID de Google Drive\n\nEjemplo: .testv2 descargar https://drive.google.com/file/d/xxxxx/view');
                }
                
                await replyWithContext('📥 Preparando descarga...\n⏳ Por favor espera...');
                
                try {
                    // Obtener información primero
                    const info = await gdriveInfo(parametro);
                    console.log('📦 INFO:', JSON.stringify(info, null, 2));
                    
                    await replyWithContext(
                        '📥 Descargando archivo...\n\n' +
                        '📌 *Nombre:* ' + (info.name || 'Desconocido') + '\n' +
                        '⏳ Por favor espera...'
                    );
                    
                    // Descargar el archivo
                    const result = await gdriveDownload(parametro);
                    console.log('📦 DESCARGA:', JSON.stringify({
                        fileId: result.fileId,
                        size: result.size,
                        contentType: result.contentType
                    }, null, 2));
                    
                    if (!result || !result.buffer || result.buffer.length === 0) {
                        throw new Error('No se pudo descargar el archivo');
                    }
                    
                    const tmpDir = path.join(__dirname, '../tmp');
                    if (!fs.existsSync(tmpDir)) {
                        fs.mkdirSync(tmpDir, { recursive: true });
                    }
                    
                    // Determinar extensión
                    const ext = result.contentType?.split('/')[1] || 'bin';
                    const cleanName = (info.name || 'archivo').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
                    const fileName = `${cleanName}.${ext}`;
                    filePath = path.join(tmpDir, fileName);
                    
                    fs.writeFileSync(filePath, result.buffer);
                    
                    const stats = fs.statSync(filePath);
                    if (stats.size === 0) {
                        throw new Error('Archivo guardado con tamaño 0');
                    }
                    
                    const fileSizeMB = (stats.size / 1024 / 1024).toFixed(2);
                    
                    // Determinar tipo de archivo
                    const isVideo = result.contentType?.includes('video');
                    const isAudio = result.contentType?.includes('audio');
                    const isImage = result.contentType?.includes('image');
                    
                    // Enviar el archivo según su tipo
                    if (isVideo) {
                        const videoMessage = {
                            video: fs.readFileSync(filePath),
                            mimetype: result.contentType || 'video/mp4',
                            fileName: fileName,
                            caption: '📁 *ARCHIVO DE GOOGLE DRIVE*\n\n' +
                                     '📌 *Nombre:* ' + (info.name || 'Desconocido') + '\n' +
                                     '📁 *Tamaño:* ' + fileSizeMB + ' MB'
                        };
                        await sock.sendMessage(from, videoMessage, { quoted: msg });
                    } else if (isAudio) {
                        const audioMessage = {
                            audio: fs.readFileSync(filePath),
                            mimetype: result.contentType || 'audio/mpeg',
                            ptt: false,
                            fileName: fileName
                        };
                        await sock.sendMessage(from, audioMessage, { quoted: msg });
                    } else if (isImage) {
                        const imageMessage = {
                            image: fs.readFileSync(filePath),
                            mimetype: result.contentType || 'image/jpeg',
                            caption: '📁 *ARCHIVO DE GOOGLE DRIVE*\n\n' +
                                     '📌 *Nombre:* ' + (info.name || 'Desconocido') + '\n' +
                                     '📁 *Tamaño:* ' + fileSizeMB + ' MB'
                        };
                        await sock.sendMessage(from, imageMessage, { quoted: msg });
                    } else {
                        // Enviar como documento
                        const documentMessage = {
                            document: fs.readFileSync(filePath),
                            mimetype: result.contentType || 'application/octet-stream',
                            fileName: fileName,
                            caption: '📁 *ARCHIVO DE GOOGLE DRIVE*\n\n' +
                                     '📌 *Nombre:* ' + (info.name || 'Desconocido') + '\n' +
                                     '📁 *Tamaño:* ' + fileSizeMB + ' MB'
                        };
                        await sock.sendMessage(from, documentMessage, { quoted: msg });
                    }
                    
                    await replyWithContext(
                        '✅ Archivo descargado exitosamente!\n\n' +
                        '📌 *Nombre:* ' + (info.name || 'Desconocido') + '\n' +
                        '📁 *Tamaño:* ' + fileSizeMB + ' MB'
                    );
                    
                    // Mostrar JSON
                    const jsonString = JSON.stringify({
                        info: info,
                        download: {
                            fileId: result.fileId,
                            size: result.size,
                            contentType: result.contentType,
                            url: result.url
                        }
                    }, null, 2);
                    await replyWithContext('📦 *JSON COMPLETO:*\n```json\n' + jsonString + '\n```');
                    
                    try {
                        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
                    } catch (e) {}
                    
                } catch (e) {
                    console.error('❌ Error en descarga:', e);
                    await replyWithContext('❌ Error al descargar: ' + e.message);
                }
                return;
            }
            
            // ============ BÚSQUEDA AUTOMÁTICA (INFO por defecto) ============
            await replyWithContext('📡 Obteniendo información...\n⏳ Por favor espera...');
            
            try {
                const result = await gdriveInfo(query);
                console.log('📦 RESPUESTA:', JSON.stringify(result, null, 2));
                
                let mensaje = '📁 *INFORMACIÓN DEL ARCHIVO*\n\n';
                mensaje += `📌 *Nombre:* ${result.name || 'Desconocido'}\n`;
                mensaje += `🆔 *ID:* ${result.fileId}\n`;
                mensaje += `📥 *Descarga:* ${result.download}\n`;
                mensaje += `🔗 *URL:* ${result.url}\n\n`;
                mensaje += 'Usa: .testv2 descargar ' + result.fileId + ' para descargar';
                
                await replyWithContext(mensaje);
                
                const jsonString = JSON.stringify(result, null, 2);
                await replyWithContext('📦 *JSON COMPLETO:*\n```json\n' + jsonString + '\n```');
                
            } catch (e) {
                console.error('❌ Error:', e);
                await replyWithContext('❌ Error: ' + e.message);
            }
            
        } catch (error) {
            console.error('❌ Error en testv2:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                
                let errorMessage = '❌ ERROR\n\n';
                errorMessage += error.message;
                
                if (error.stack) {
                    errorMessage += '\n\nStack:\n' + error.stack;
                }
                
                await replyWithContext(errorMessage);
            } catch (e) {
                console.error('Error al enviar mensaje de error:', e);
            }
            
        } finally {
            if (filePath && fs.existsSync(filePath)) {
                try {
                    fs.unlinkSync(filePath);
                } catch (e) {}
            }
        }
    }
};