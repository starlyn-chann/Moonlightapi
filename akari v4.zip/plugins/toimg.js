import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import axios from 'axios';
import FormData from 'form-data';
import * as cheerio from 'cheerio';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `toimg_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${extension}`);
}

async function webp2mp4(source) {
    const form = new FormData();
    const isUrl = typeof source === 'string' && /https?:\/\//.test(source);
    form.append('new-image-url', isUrl ? source : '');
    form.append('new-image', source, 'image.webp');
    
    const res = await axios.post('https://ezgif.com/webp-to-mp4', form, {
        headers: { ...form.getHeaders() },
        responseType: 'text'
    });
    
    const $ = cheerio.load(res.data);
    const form2 = new FormData();
    let obj = {};
    
    $('form input[name]').each((i, input) => {
        const name = $(input).attr('name');
        const value = $(input).val();
        obj[name] = value;
        form2.append(name, value);
    });
    
    const res2 = await axios.post(`https://ezgif.com/webp-to-mp4/${obj.file}`, form2, {
        headers: { ...form2.getHeaders() },
        responseType: 'text'
    });
    
    const $2 = cheerio.load(res2.data);
    const videoUrl = new URL($2('div#output > p.outfile > video > source').attr('src'), res2.config.url).toString();
    
    const videoRes = await axios.get(videoUrl, { responseType: 'arraybuffer' });
    return Buffer.from(videoRes.data);
}

async function webp2png(source) {
    const form = new FormData();
    const isUrl = typeof source === 'string' && /https?:\/\//.test(source);
    form.append('new-image-url', isUrl ? source : '');
    form.append('new-image', source, 'image.webp');
    
    const res = await axios.post('https://ezgif.com/webp-to-png', form, {
        headers: { ...form.getHeaders() },
        responseType: 'text'
    });
    
    const $ = cheerio.load(res.data);
    const form2 = new FormData();
    let obj = {};
    
    $('form input[name]').each((i, input) => {
        const name = $(input).attr('name');
        const value = $(input).val();
        obj[name] = value;
        form2.append(name, value);
    });
    
    const res2 = await axios.post(`https://ezgif.com/webp-to-png/${obj.file}`, form2, {
        headers: { ...form2.getHeaders() },
        responseType: 'text'
    });
    
    const $2 = cheerio.load(res2.data);
    const imgUrl = new URL($2('div#output > p.outfile > img').attr('src'), res2.config.url).toString();
    
    const imgRes = await axios.get(imgUrl, { responseType: 'arraybuffer' });
    return Buffer.from(imgRes.data);
}

export default {
    name: 'toimg',
    alias: ['toimage'],
    description: 'Convierte stickers a imágenes o videos',
    category: 'tools',
    
    async execute(sock, msg, options) {
        try {
            const { config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;

            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!quotedMsg?.quotedMessage) {
                return await replyWithContext(`《✧》 Debes citar un sticker para convertir.`);
            }

            const quotedMessage = quotedMsg.quotedMessage;
            const stickerMessage = quotedMessage.stickerMessage;
            
            if (!stickerMessage) {
                return await replyWithContext(`《✧》 Debes citar un sticker para convertir.`);
            }

            try {
                await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } });
            } catch (e) {}

            const quotedMsgObj = {
                key: { 
                    remoteJid: from, 
                    id: quotedMsg.stanzaId, 
                    participant: quotedMsg.participant || from, 
                    fromMe: false 
                },
                message: { stickerMessage: stickerMessage }
            };
            
            const mediaBuffer = await downloadMediaMessage(
                quotedMsgObj, 
                'buffer', 
                {}, 
                { logger: console, reuploadRequest: sock.updateMediaMessage }
            );

            if (!mediaBuffer || mediaBuffer.length === 0) {
                throw new Error('No se pudo descargar el sticker');
            }

            const isAnimated = stickerMessage.isAnimated || false;
            console.log(`🔄 Convirtiendo sticker ${isAnimated ? 'animado' : 'estático'}...`);
            
            const contextInfo = {
                mentionedJid: senderJid ? [senderJid] : [],
                forwardingScore: 9999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.canalId || '',
                    serverMessageId: 0,
                    newsletterName: config.canalNombre || ''
                }
            };

            if (isAnimated) {
                const mp4Buffer = await webp2mp4(mediaBuffer);
                await sock.sendMessage(from, { 
                    video: mp4Buffer, 
                    caption: 'ꕥ *Aquí tienes ฅ^•ﻌ•^ฅ*',
                    gifPlayback: true,
                    contextInfo 
                }, { quoted: msg });
            } else {
                const pngBuffer = await webp2png(mediaBuffer);
                await sock.sendMessage(from, { 
                    image: pngBuffer, 
                    caption: 'ꕥ *Aquí tienes ฅ^•ﻌ•^ฅ*',
                    contextInfo 
                }, { quoted: msg });
            }

            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Sticker ${isAnimated ? 'animado' : 'estático'} convertido por ${pushName || userNumber}`);

        } catch (error) {
            console.error('❌ Error en toimg:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`《✧》 Error al convertir el sticker.\n${error.message}`);
            } catch (e) {}
        }
    }
};