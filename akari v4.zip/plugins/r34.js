import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configuración de rutas para la verificación de NSFW
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const NSFW_FILE = path.join(__dirname, '..', 'data', 'nsfw.json');

// Función para cargar la configuración de los grupos
function loadNsfwConfig() {
    try {
        if (fs.existsSync(NSFW_FILE)) {
            const data = fs.readFileSync(NSFW_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {}
    return {};
}

export default {
    name: 'r34',
    alias: ['rule34'],
    description: 'Busca contenido en Rule34 mediante etiquetas',
    category: 'search',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, isGroup } = options;
            const from = msg.key.remoteJid;
            const tag = args.join('_');
            
            // --- VALIDACIÓN NSFW ---
            if (isGroup) {
                const nsfwConfig = loadNsfwConfig();
                const isActive = nsfwConfig[from] || false;

                if (!isActive) {
                    return await replyWithContext(`「✰」 Los comandos nsfw están desactivados en este grupo.\n> Pide a un administrador que los active usando ${config.prefix}nsfw on`);
                }
            }
            // -----------------------
            
            if (!tag) {
                return await replyWithContext(`「✰」Debes especificar etiquetas para buscar.\n> Ejemplo: *${config.prefix}r34 neko*`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}

            console.log(`🔍 Buscando Rule34 para: ${tag}...`);
            
            const url = `https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&tags=${encodeURIComponent(tag)}&api_key=a4e807dd6d4c9e55768772996946e4074030ec02c49049d291e5edb8808a97b004190660b4b36c3d21699144c823ad93491d066e73682a632a38f9b6c3cf951b&user_id=5753302`;
            
            const response = await axios.get(url, {
                timeout: 30000,
                headers: {
                    'accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const data = Array.isArray(response.data) ? response.data : (response.data?.post || []);
            
            // Extraer y filtrar los resultados (imágenes, gifs o videos)
            const validMedia = data
                .map(i => i?.file_url || i?.sample_url)
                .filter(u => typeof u === 'string' && /\.(jpe?g|png|gif|mp4)$/i.test(u));

            if (validMedia.length === 0) {
                try {
                    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
                } catch (e) {}
                return await replyWithContext(`《✧》 No se encontraron resultados para: *${tag}*`);
            }

            // Seleccionar uno al azar
            const selected = validMedia[Math.floor(Math.random() * validMedia.length)];
            const isVideo = selected.toLowerCase().endsWith('.mp4');
            
            const caption = `「✰」Tag: ${tag}\n> Pedido por: ${pushName || userNumber}`;
            
            // Enviar el contenido con el contextInfo de tus otros comandos
            await sock.sendMessage(from, {
                [isVideo ? 'video' : 'image']: { url: selected },
                mimetype: isVideo ? 'video/mp4' : undefined,
                caption: caption,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Rule34 enviado por ${pushName || userNumber} - Tag: ${tag}`);
            
        } catch (error) {
            console.error('❌ Error en r34:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`♡ Ocurrió un error: ${error.message}`);
            } catch (e) {}
        }
    }
};