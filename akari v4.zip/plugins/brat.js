import axios from 'axios';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { promisify } from 'util';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const exec = promisify(spawn);

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

// Función para convertir imagen a WebP usando FFmpeg
async function convertToWebp(buffer) {
    return new Promise(async (resolve, reject) => {
        const tempId = Date.now() + Math.random().toString(36).substring(7);
        const inputPath = path.join(tempFolder, `brat_input_${tempId}.png`);
        const outputPath = path.join(tempFolder, `brat_output_${tempId}.webp`);
        
        try {
            // Guardar imagen temporal
            fs.writeFileSync(inputPath, buffer);
            
            // Convertir a WebP con FFmpeg
            const ffmpeg = spawn('ffmpeg', [
                '-i', inputPath,
                '-vcodec', 'libwebp',
                '-vf', 'scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000',
                '-lossless', '0',
                '-compression_level', '6',
                '-q:v', '80',
                '-loop', '0',
                '-an',
                '-vsync', '0',
                '-s', '512:512',
                '-f', 'webp',
                outputPath
            ]);
            
            ffmpeg.on('close', async (code) => {
                try {
                    if (code !== 0) {
                        throw new Error(`FFmpeg falló con código ${code}`);
                    }
                    
                    if (fs.existsSync(outputPath)) {
                        const webpBuffer = fs.readFileSync(outputPath);
                        // Limpiar archivos temporales
                        fs.unlinkSync(inputPath);
                        fs.unlinkSync(outputPath);
                        resolve(webpBuffer);
                    } else {
                        throw new Error('No se generó el archivo WebP');
                    }
                } catch (err) {
                    reject(err);
                }
            });
            
            ffmpeg.on('error', (err) => {
                reject(err);
            });
            
        } catch (err) {
            reject(err);
        }
    });
}

// Función para detectar si la respuesta es imagen válida
function isValidImage(buffer) {
    if (!buffer || buffer.length < 4) return false;
    
    const hex = buffer.toString('hex', 0, 4).toUpperCase();
    // PNG, JPEG, GIF, WEBP
    const validSignatures = ['89504E47', 'FFD8FF', '47494638', '52494646'];
    
    return validSignatures.some(sig => hex.startsWith(sig));
}

export default {
    name: 'brat',
    alias: [],
    description: 'Crea sticker estático con texto estilo brat',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const text = args.join(' ').trim();
            
            if (!text) {
                return await replyWithContext(`❀ Por favor, ingresa un texto para crear el Sticker.\n\n> Ejemplo: ${config.prefix}brat Hola mundo`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🕒', key: msg.key } });
            } catch (e) {}
            
            // API de Delirius
            const apiUrl = `https://api.delirius.store/canvas/brat?text=${encodeURIComponent(text)}`;
            console.log(`🔄 Solicitando: ${apiUrl}`);
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'image/webp,image/png,image/jpeg,*/*'
                }
            });
            
            if (!response.data || response.data.length === 0) {
                throw new Error('No se pudo generar la imagen');
            }
            
            const imageBuffer = Buffer.from(response.data);
            
            // Verificar si la respuesta es una imagen válida
            if (!isValidImage(imageBuffer)) {
                // Si no es imagen válida, puede ser un error HTML
                const errorText = imageBuffer.toString('utf-8', 0, 200);
                console.error('Respuesta no es imagen:', errorText);
                throw new Error('La API no devolvió una imagen válida');
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🎨', key: msg.key } });
            } catch (e) {}
            
            // Convertir a WebP para sticker
            let stickerBuffer;
            try {
                stickerBuffer = await convertToWebp(imageBuffer);
                console.log('✅ Sticker convertido a WebP');
            } catch (convError) {
                console.log('⚠️ Error convirtiendo a WebP, usando imagen original:', convError.message);
                stickerBuffer = imageBuffer;
            }
            
            // Enviar sticker
            await sock.sendMessage(from, { 
                sticker: stickerBuffer,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Brat sticker creado para ${pushName || userNumber}: "${text}"`);
            
        } catch (error) {
            console.error('❌ Error en brat:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            let errorMsg = `⚠︎ Error: ${error.message}`;
            if (error.response?.status === 404) {
                errorMsg = `⚠︎ La API no está disponible temporalmente`;
            } else if (error.message.includes('ECONNREFUSED')) {
                errorMsg = `⚠︎ No se pudo conectar con la API`;
            }
            
            try {
                await replyWithContext(errorMsg);
            } catch (e) {}
        }
    }
};