import axios from 'axios';

export default {
    name: 'maid',
    alias: ['sirvienta'],
    description: 'Envía una imagen aleatoria de una maid (anime)',
    category: 'image',

    async execute(sock, msg, options) {
        try {
            const { config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;

            // 1. Reacción de proceso
            try {
                await sock.sendMessage(from, { react: { text: '🧹', key: msg.key } });
            } catch (e) {}

            console.log(`🔍 Obteniendo Maid para ${pushName || userNumber}...`);

            // 2. Consulta a la API
            const apiUrl = `https://api.delirius.store/anime/maid`;
            const response = await axios.get(apiUrl, { timeout: 30000 });
            const res = response.data;

            // 3. Validar respuesta
            if (!res.status || !res.data || !res.data.image) {
                try { await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }); } catch (e) {}
                return await replyWithContext("♡ No se pudo obtener la imagen en este momento.");
            }

            const imageUrl = res.data.image;

            // 4. Envío de la imagen con el caption solicitado
            await sock.sendMessage(from, {
                image: { url: imageUrl },
                caption: `> Aquí tienes ฅ⁠^⁠•⁠ﻌ⁠•⁠^⁠ฅ`,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || 'Maid Central'
                    }
                }
            }, { quoted: msg });

            // 5. Reacción de éxito
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}

        } catch (error) {
            console.error('❌ Error en comando maid:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`♡ Ocurrió un error al contactar la API: ${error.message}`);
            } catch (e) {}
        }
    }
};