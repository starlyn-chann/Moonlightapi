import { search, download } from 'aptoide-scraper';

/**
 * Convierte el string de tamaño (ej: "15 MB") a bytes para validar el límite
 */
function parseSize(sizeStr) {
    if (!sizeStr) return 0;
    const parts = sizeStr.trim().toUpperCase().split(' ');
    const value = parseFloat(parts[0]);
    const unit = parts[1] || 'B';
    switch (unit) {
        case 'KB': return value * 1024;
        case 'MB': return value * 1024 * 1024;
        case 'GB': return value * 1024 * 1024 * 1024;
        default: return value;
    }
}

export default {
    name: 'apk',
    alias: ['aptoide', 'apkdl'],
    description: 'Busca y descarga aplicaciones APK',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            if (!args || !args.length) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre de la aplicación\n> Ejemplo: ${config.prefix}apk facebook`);
            }
            
            const query = args.join(' ').trim();
            
            try {
                await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });
            } catch (e) {}
            
            console.log(`🔍 Buscando APK: "${query}" para ${pushName || userNumber}`);
            
            // 1. Buscar la aplicación
            const searchA = await search(query);
            
            if (!searchA || searchA.length === 0) {
                try { await sock.sendMessage(from, { react: { text: '❌', key: msg.key } }); } catch (e) {}
                return await replyWithContext(`《✧》No se encontraron resultados para *${query}*`);
            }
            
            // 2. Obtener enlace de descarga
            const apkInfo = await download(searchA[0].id);
            
            if (!apkInfo) {
                return await replyWithContext(`《✧》No se pudo obtener la información de descarga para esta aplicación.`);
            }
            
            const { name, package: id, size, icon, dllink: downloadUrl, lastup } = apkInfo;
            const sizeBytes = parseSize(size);
            
            const caption = `「✰」 *APK DOWNLOADER* 「✰」\n\n` +
                            `*»* Nombre » ${name}\n` +
                            `*»* Paquete » ${id}\n` +
                            `*»* Tamaño » ${size}\n` +
                            `*»* Actualización » ${lastup}\n\n` +
                            `> *solicitado por ${pushName}*`;

            // 3. Validar límite de peso (500 MB aprox)
            if (sizeBytes > 524288000) {
                try { await sock.sendMessage(from, { react: { text: '⚠️', key: msg.key } }); } catch (e) {}
                return await replyWithContext(`《✧》 El archivo es demasiado grande (${size}).\n> WhatsApp no permite enviar archivos de más de 2GB fácilmente, descárgalo aquí:\n${downloadUrl}`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            // 4. Enviar el Documento (APK)
            await sock.sendMessage(from, {
                document: { url: downloadUrl },
                mimetype: 'application/vnd.android.package-archive',
                fileName: `${name}.apk`,
                caption: caption,
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ APK enviado con éxito: ${name}`);
            
        } catch (error) {
            console.error('❌ Error en comando APK:', error);
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
                await replyWithContext(`♡ Ocurrió un error al procesar el APK: ${error.message}`);
            } catch (e) {}
        }
    }
};