import { 
    obtenerPersonajePorId,
    reclamarPersonaje,
    eliminarReclamo
} from '../lib/gacha.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SALES_FILE = path.join(__dirname, '..', 'data', 'sales.json');

function loadSales() {
    try {
        if (fs.existsSync(SALES_FILE)) {
            const data = fs.readFileSync(SALES_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando ventas:', e);
    }
    return {};
}

function saveSales(sales) {
    try {
        fs.writeFileSync(SALES_FILE, JSON.stringify(sales, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando ventas:', e);
        return false;
    }
}

function loadEconomy() {
    try {
        const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function getDisplayName(number) {
    const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            const users = JSON.parse(data);
            const user = users.find(u => u.number === number);
            return user ? user.pushName : number;
        }
    } catch (e) {}
    return number;
}

export default {
    name: 'buyc',
    alias: ['buycharacter', 'buychar', 'comprar'],
    description: 'Comprar un personaje en venta',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando buyc...');
            
            const { config, replyWithContext, args, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `❀ Debes especificar un personaje para comprar.\n> Ejemplo: ${config.prefix}buyc Goku`
                );
            }
            
            const nombrePersonaje = args.join(' ').trim();
            
            // ============ BUSCAR EN VENTAS ============
            const sales = loadSales();
            
            if (!sales[from] || Object.keys(sales[from]).length === 0) {
                return await replyWithContext(`ꕥ No hay personajes en venta en este grupo.`);
            }
            
            let ventaEncontrada = null;
            let idEncontrado = null;
            
            for (const [id, venta] of Object.entries(sales[from])) {
                if (venta.nombre.toLowerCase() === nombrePersonaje.toLowerCase()) {
                    ventaEncontrada = venta;
                    idEncontrado = id;
                    break;
                }
            }
            
            if (!ventaEncontrada) {
                return await replyWithContext(`ꕥ No se encontró el personaje *${nombrePersonaje}* en venta.`);
            }
            
            // ============ VERIFICAR QUE NO SEA SU PROPIO PERSONAJE ============
            if (ventaEncontrada.usuario === userNumber) {
                return await replyWithContext(`ꕥ No puedes comprar tu propio personaje.`);
            }
            // ================================================================
            
            // ============ VERIFICAR EXPIRACIÓN (3 DIAS) ============
            const ahora = Date.now();
            const expiracion = 3 * 86400000;
            
            if (ahora - ventaEncontrada.tiempo >= expiracion) {
                delete sales[from][idEncontrado];
                saveSales(sales);
                return await replyWithContext(`ꕥ La venta de *${ventaEncontrada.nombre}* ha expirado.`);
            }
            // ================================================================
            
            // ============ VERIFICAR SALDO DEL COMPRADOR ============
            const economy = loadEconomy();
            
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const saldo = economy[from][userNumber].dinero || 0;
            
            if (saldo < ventaEncontrada.precio) {
                return await replyWithContext(
                    `ꕥ No tienes suficiente *${config.moneda}* para comprar a *${ventaEncontrada.nombre}*.\n` +
                    `> Necesitas *${ventaEncontrada.precio.toLocaleString()} ${config.moneda}*`
                );
            }
            // ================================================================
            
            // ============ REALIZAR COMPRA ============
            // Transferir dinero
            if (!economy[from][ventaEncontrada.usuario]) {
                economy[from][ventaEncontrada.usuario] = {
                    dinero: 0,
                    banco: 0,
                    nombre: getDisplayName(ventaEncontrada.usuario)
                };
            }
            
            economy[from][userNumber].dinero -= ventaEncontrada.precio;
            economy[from][ventaEncontrada.usuario].dinero += ventaEncontrada.precio;
            saveEconomy(economy);
            
            // Transferir personaje
            await eliminarReclamo(from, idEncontrado);
            await reclamarPersonaje(from, idEncontrado, userNumber);
            
            // Eliminar de ventas
            delete sales[from][idEncontrado];
            saveSales(sales);
            // ================================================================
            
            const vendedorNombre = getDisplayName(ventaEncontrada.usuario);
            const compradorNombre = pushName || userNumber;
            
            const mensaje = 
`❀ *${ventaEncontrada.nombre}* ha sido comprado por *${compradorNombre}*!
> Se han transferido *${ventaEncontrada.precio.toLocaleString()} ${config.moneda}* a *${vendedorNombre}*`;

            await replyWithContext(mensaje);
            
            console.log(`✅ buyc ejecutado: ${compradorNombre} compró ${ventaEncontrada.nombre} por ${ventaEncontrada.precio}`);
            
        } catch (error) {
            console.error('❌ Error en buyc:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};