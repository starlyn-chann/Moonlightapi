import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'join',
    alias: ['unir', 'entrar'],
    description: 'Hace que el bot se una a un grupo mediante enlace (solo dueño del bot)',
    category: 'sub-bot',
    
    async execute(sock, msg, options) {
        try {
            const { config, args, senderNumber, replyWithContext, userNumber, isSubBot } = options;
            const from = msg.key.remoteJid;
            
            // DEBUG: Mostrar en consola para verificar
            console.log('[JOIN DEBUG]', {
                senderNumber: senderNumber,
                userNumber: userNumber,
                configBotowner: config.botowner,
                configOwner: config.owner
            });
            
            // Limpiar número del usuario que ejecuta el comando
            let userNumberClean = '';
            if (senderNumber) {
                userNumberClean = senderNumber.toString().replace(/\D/g, '');
            } else if (userNumber) {
                userNumberClean = userNumber.toString().replace(/\D/g, '');
            } else if (msg.key?.participant) {
                userNumberClean = msg.key.participant.split('@')[0].replace(/\D/g, '');
            } else if (msg.key?.remoteJid) {
                userNumberClean = msg.key.remoteJid.split('@')[0].replace(/\D/g, '');
            }
            
            // Limpiar botowner de la config
            let botownerClean = '';
            if (config.botowner) {
                botownerClean = config.botowner.toString().replace(/\D/g, '');
            }
            
            // También verificar con config.owner por si acaso
            let isOwner = false;
            if (config.owner && Array.isArray(config.owner)) {
                isOwner = config.owner.some(owner => {
                    const cleanOwner = owner.toString().replace(/\D/g, '');
                    return cleanOwner === userNumberClean;
                });
            }
            
            console.log(`[JOIN] Usuario: ${userNumberClean} | Botowner: ${botownerClean} | isOwner: ${isOwner}`);
            
            // VERIFICAR SI EL USUARIO ES EL BOTOWNER O OWNER
            if (!botownerClean || (userNumberClean !== botownerClean && !isOwner)) {
                return await replyWithContext(`❀ *Solo el dueño de este bot puede usar este comando*\n\n> Tu número: ${userNumberClean}\n> Dueño del bot: ${botownerClean}`);
            }
            
            // Verificar que se proporcionó un enlace
            if (!args || args.length === 0) {
                return await replyWithContext(`《✧》 *Ingresa el enlace del grupo*\n\n> Ejemplo: *${config.prefix}join https://chat.whatsapp.com/...*`);
            }
            
            // Validar enlace de WhatsApp
            const linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;
            const match = args[0].match(linkRegex);
            
            if (!match || !match[1]) {
                return await replyWithContext(`《✧》 *El enlace ingresado no es válido*\n\n> Asegúrate de usar un enlace de grupo de WhatsApp completo.`);
            }
            
            try {
                const inviteCode = match[1];
                let botName = config.nombre || config.name || 'Bot';
                
                await replyWithContext(`《✧》 *Intentando unir ${botName} al grupo...*`);
                
                await sock.groupAcceptInvite(inviteCode);
                
                await replyWithContext(`❀ *${botName}* se ha unido exitosamente al grupo.\n> Solicitado por el dueño del bot`);
                
                console.log(`[JOIN] Bot ${botName} se unió a grupo usando código: ${inviteCode} por su dueño ${userNumberClean}`);
                
            } catch (error) {
                console.error('[JOIN] Error:', error);
                
                const errMsg = String(error.message || error);
                let responseMsg = '《✧》 *No se pudo unir al grupo*';
                
                if (errMsg.includes('not-authorized') || errMsg.includes('requires-admin')) {
                    responseMsg = '《✧》 *La unión requiere aprobación de admin*\n\n> Espera a que un administrador acepte la solicitud.';
                } else if (errMsg.includes('not-in-group') || errMsg.includes('removed')) {
                    responseMsg = '《✧》 *No se pudo unir al grupo*\n\n> El bot fue eliminado recientemente o no puede unirse.';
                } else if (errMsg.includes('invite') || errMsg.includes('código') || errMsg.includes('code')) {
                    responseMsg = '《✧》 *El enlace no es válido*\n\n> El código de invitación ha expirado o es incorrecto.';
                } else if (errMsg.includes('full') || errMsg.includes('lleno')) {
                    responseMsg = '《✧》 *El grupo está lleno*\n\n> El grupo tiene el máximo de participantes (1024).';
                } else if (errMsg.includes('blocked') || errMsg.includes('bloqueado')) {
                    responseMsg = '《✧》 *El bot está bloqueado*\n\n> Algún participante del grupo ha bloqueado al bot.';
                }
                
                await replyWithContext(responseMsg);
            }
            
        } catch (error) {
            console.error('Error en join:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};