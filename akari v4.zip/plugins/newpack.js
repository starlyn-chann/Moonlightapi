import { guardarPack, obtenerPacksUsuario } from '../lib/mongoose.js';

export default {
    name: 'newpack',
    alias: ['addpack'],
    description: 'Crea un nuevo pack de stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid, pushName } = options;
            
            const args = options.args || [];
            const packName = args.join(' ').trim();
            
            // Validaciones
            if (!packName || packName.length < 1 || packName.length > 64) {
                return await replyWithContext(`「✰」El nombre del pack debe tener entre 1 y 64 caracteres\n> Ejemplo: ${config.prefix}newpack Mis Stickers`);
            }
            
            // Verificar si el pack ya existe
            const packs = await obtenerPacksUsuario(userNumber);
            const existingPack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (existingPack) {
                return await replyWithContext(`「✰」Ya tienes un pack con el nombre "${packName}"`);
            }
            
            // Crear nuevo pack
            const newPack = {
                id: Date.now().toString(),
                name: packName,
                owner: userNumber,
                ownerJid: senderJid,
                ownerName: pushName || userNumber,
                author: '𝖬𝖺𝖽𝖾 𝗂𝗇 𝖬𝗈𝗈𝗇𝗅𝗂𝗀𝗁𝗍 𝖲𝗍𝖺𝖿𝖿',
                desc: `Paquete de stickers creado por ${pushName || userNumber}`,
                createdAt: new Date().toLocaleString(),
                lastModified: Date.now().toString(),
                timestamp: Date.now(),
                stickers: [],
                spackpublic: 0
            };
            
            // ✅ Guardar en MongoDB con manejo de errores
            try {
                const resultado = await guardarPack(userNumber, newPack);
                
                if (resultado) {
                    await replyWithContext(`《✧》El paquete de stickers \`${packName}\` ha sido creado exitosamente!\n> ${config.prefix}addsticker ${packName} - Agregar stickers\n> ${config.prefix}pack ${packName} - Ver pack`);
                } else {
                    await replyWithContext(`❌ Error al guardar el pack en la base de datos.\n> Por favor, intenta nuevamente más tarde.`);
                }
            } catch (dbError) {
                console.error('❌ Error de base de datos:', dbError);
                await replyWithContext(`❌ Error al guardar el pack: ${dbError.message}\n> Por favor, intenta nuevamente.`);
            }
            
        } catch (error) {
            console.error('❌ Error en newpack:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};