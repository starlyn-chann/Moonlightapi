export default {
    name: 'gpdesc',
    alias: ['setgroupdesc'],
    description: 'Cambia la descripción del grupo (solo admins)',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, replyWithContext, isGroup, senderJid, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            // Función para limpiar número
            function cleanNumber(jid) {
                if (!jid) return '';
                return jid.split(':')[0].split('@')[0].replace(/\D/g, '');
            }
            
            function getCleanJid(jid) {
                if (!jid) return '';
                const number = cleanNumber(jid);
                return `${number}@s.whatsapp.net`;
            }
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            // Verificar que se proporcionó una descripción
            const nuevaDescripcion = args.join(' ').trim();
            
            if (!nuevaDescripcion) {
                return await replyWithContext(`*ᰔᩚ* Debes proporcionar una descripción para el grupo\n> Ejemplo: ${config.prefix}gpdesc +Esta es la descripción del grupo`);
            }
            
            // Eliminar el '+' si está presente al inicio
            let descripcionFinal = nuevaDescripcion;
            if (descripcionFinal.startsWith('+')) {
                descripcionFinal = descripcionFinal.substring(1).trim();
            }
            
            if (!descripcionFinal) {
                return await replyWithContext(`*ᰔᩚ* La descripción no puede estar vacía`);
            }
            
            // Limitar longitud (máx 500 caracteres)
            if (descripcionFinal.length > 500) {
                return await replyWithContext(`「✰」 La descripción del grupo no puede tener más de 500 caracteres\n> Tu descripción tiene: ${descripcionFinal.length} caracteres`);
            }
            
            // Obtener metadata del grupo
            let groupMetadata;
            try {
                groupMetadata = await sock.groupMetadata(from);
            } catch (error) {
                return await replyWithContext(`❌ Error al obtener información del grupo`);
            }
            
            // Verificar si el usuario que ejecuta el comando es administrador
            const senderCleanJid = getCleanJid(senderJid);
            const senderParticipant = groupMetadata.participants.find(p => p.id === senderJid || p.id === senderCleanJid);
            const isSenderAdmin = senderParticipant?.admin === 'admin' || senderParticipant?.admin === 'superadmin';
            
            if (!isSenderAdmin) {
                return await replyWithContext(`「✰」 Debes ser administrador del grupo para poder usar este comando`);
            }
            
            // Verificar si el bot es administrador
            const botJid = sock.user?.id;
            const botCleanJid = getCleanJid(botJid);
            const botParticipant = groupMetadata.participants.find(p => p.id === botJid || p.id === botCleanJid);
            const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
            
            if (!isBotAdmin) {
                return await replyWithContext(`「✰」 ${config.nombre || config.name} debe ser administrador del grupo`);
            }
            
            // Cambiar la descripción del grupo
            try {
                await sock.groupUpdateDescription(from, descripcionFinal);
                
                await replyWithContext(`《✧》 Descripción del grupo actualizada a:\n> ${descripcionFinal}`);
                
                console.log(`📝 Descripción del grupo cambiada por ${pushName || userNumber} en grupo ${from}`);
                
            } catch (error) {
                console.error('Error al cambiar descripción:', error);
                return await replyWithContext(`❌ Error al cambiar la descripción: ${error.message}`);
            }
            
        } catch (error) {
            console.error('❌ Error en gpdesc:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};