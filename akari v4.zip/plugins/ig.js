import axios from 'axios';

export default {
    name: 'ig',
    alias: ['instagram', 'reel'],
    description: 'Descarga videos e imágenes de Instagram',
    category: 'download',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            const url = args[0];
            
            if (!url) {
                return await replyWithContext(`♡ Por favor, ingresa un enlace de Instagram\n> Uso: ${config.prefix}ig [enlace]`);
            }
            
            if (!url.includes('instagram.com')) {
                return await replyWithContext(`♡ Eso no parece ser un enlace de Instagram válido`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            } catch (e) {}
            
            // Detectar si es reel (video) o publicación (imagen)
            const isReel = url.includes('/reel/');
            
            let mediaUrl = '';
            let title = '';
            let likes = 0;
            let comments = 0;
            let username = '';
            let thumbnail = '';
            let quality = '';
            
            if (isReel) {
                // ============ REEL (VIDEO) - USAR API SIPUTZX ============
                try {
                    console.log(`🔍 Consultando API Siputzx para reel...`);
                    
                    const apiUrl = `https://api.siputzx.my.id/api/d/igram?url=${encodeURIComponent(url)}`;
                    
                    const response = await axios.get(apiUrl, {
                        timeout: 30000,
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const data = response.data;
                    
                    if (data.status && data.data) {
                        const result = data.data;
                        
                        // Obtener URL del video (mejor calidad)
                        if (result.url && result.url.length > 0) {
                            let bestQuality = 0;
                            for (const video of result.url) {
                                if (video.quality && video.quality > bestQuality) {
                                    bestQuality = video.quality;
                                    mediaUrl = video.url;
                                    quality = `${video.quality}p`;
                                } else if (!mediaUrl) {
                                    mediaUrl = video.url;
                                    quality = video.quality ? `${video.quality}p` : 'SD';
                                }
                            }
                        }
                        
                        // Extraer metadata
                        const meta = result.meta || {};
                        title = meta.title || '';
                        likes = meta.like_count || 0;
                        comments = meta.comment_count || 0;
                        username = meta.username || '';
                        thumbnail = result.thumb || '';
                        
                        console.log(`✅ Reel obtenido: ${quality}`);
                    } else {
                        throw new Error('No se encontró contenido');
                    }
                    
                } catch (siputzxError) {
                    console.log('⚠️ API Siputzx falló:', siputzxError.message);
                    
                    // Respaldo para reel
                    const apiUrl = `https://api.nexray.eu.cc/downloader/instagram?url=${encodeURIComponent(url)}`;
                    const response = await axios.get(apiUrl, {
                        timeout: 30000,
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const data = response.data;
                    if (data.status && data.result && data.result.length > 0) {
                        mediaUrl = data.result[0].url;
                        quality = 'SD';
                    } else {
                        throw new Error('No se pudo obtener el video');
                    }
                }
                
                if (!mediaUrl) {
                    throw new Error('No se pudo obtener el video');
                }
                
                // Enviar información primero
                const infoText = `「✰」Título » ${title.substring(0, 100)}${title.length > 100 ? '...' : ''}\n` +
                              `「✰」Calidad » ${quality}\n` +
                              `「✰」Likes » ${likes.toLocaleString()}\n` +
                              `「✰」Comentarios » ${comments.toLocaleString()}\n` +
                              `「✰」Usuario » @${username}\n` +
                              `「✰」Enlace » ${url}`;
                
                // Enviar thumbnail si existe
                if (thumbnail) {
                    try {
                        const thumbResponse = await axios.get(thumbnail, { responseType: 'arraybuffer', timeout: 15000 });
                        const thumbBuffer = Buffer.from(thumbResponse.data);
                        
                        await sock.sendMessage(from, {
                            image: thumbBuffer,
                            caption: infoText,
                            contextInfo: {
                                forwardingScore: 9999999,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: 0,
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        }, { quoted: msg });
                    } catch (thumbError) {
                        await replyWithContext(infoText);
                    }
                } else {
                    await replyWithContext(infoText);
                }
                
                // Descargar y enviar video
                const videoResponse = await axios({
                    method: 'get',
                    url: mediaUrl,
                    responseType: 'arraybuffer',
                    timeout: 60000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Referer': 'https://www.instagram.com/'
                    }
                });
                
                const videoBuffer = Buffer.from(videoResponse.data);
                
                await sock.sendMessage(from, {
                    video: videoBuffer,
                    mimetype: 'video/mp4',
                    caption: `♡ *Instagram Reel*\n> Calidad: ${quality}`,
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: config.canalId || '',
                            serverMessageId: 0,
                            newsletterName: config.canalNombre || ''
                        }
                    }
                }, { quoted: msg });
                
            } else {
                // ============ PUBLICACIÓN (IMÁGENES) - USAR API NEXRAY v2 ============
                try {
                    console.log(`🔍 Consultando API NexRay v2 para publicación...`);
                    
                    const apiUrl = `https://api.nexray.eu.cc/downloader/v2/instagram?url=${encodeURIComponent(url)}`;
                    
                    const response = await axios.get(apiUrl, {
                        timeout: 30000,
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const data = response.data;
                    
                    if (data.status && data.result) {
                        const result = data.result;
                        
                        title = result.title || '';
                        likes = result.likes || 0;
                        comments = result.comment || 0;
                        username = result.username || '';
                        thumbnail = result.thumbnail || '';
                        
                        // Extraer todas las imágenes
                        const mediaItems = result.media || [];
                        
                        if (mediaItems.length === 0) {
                            throw new Error('No se encontraron imágenes');
                        }
                        
                        // Enviar información con thumbnail
                        const infoText = `「✰」Título » ${title.substring(0, 100)}${title.length > 100 ? '...' : ''}\n` +
                                      `「✰」Likes » ${likes.toLocaleString()}\n` +
                                      `「✰」Comentarios » ${comments.toLocaleString()}\n` +
                                      `「✰」Usuario » @${username}\n` +
                                      `「✰」Enlace » ${url}`;
                        
                        if (thumbnail) {
                            try {
                                const thumbResponse = await axios.get(thumbnail, { responseType: 'arraybuffer', timeout: 15000 });
                                const thumbBuffer = Buffer.from(thumbResponse.data);
                                
                                await sock.sendMessage(from, {
                                    image: thumbBuffer,
                                    caption: infoText,
                                    contextInfo: {
                                        forwardingScore: 9999999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: config.canalId || '',
                                            serverMessageId: 0,
                                            newsletterName: config.canalNombre || ''
                                        }
                                    }
                                }, { quoted: msg });
                            } catch (thumbError) {
                                await replyWithContext(infoText);
                            }
                        } else {
                            await replyWithContext(infoText);
                        }
                        
                        // Descargar y enviar todas las imágenes
                        for (let i = 0; i < mediaItems.length; i++) {
                            const media = mediaItems[i];
                            if (media.url) {
                                const imgResponse = await axios.get(media.url, { responseType: 'arraybuffer', timeout: 30000 });
                                const imgBuffer = Buffer.from(imgResponse.data);
                                
                                const caption = mediaItems.length > 1 
                                    ? `♡ *Instagram Download*\n> Imagen ${i + 1}/${mediaItems.length}`
                                    : `♡ *Instagram Download*`;
                                
                                await sock.sendMessage(from, {
                                    image: imgBuffer,
                                    caption: caption,
                                    contextInfo: {
                                        forwardingScore: 9999999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: config.canalId || '',
                                            serverMessageId: 0,
                                            newsletterName: config.canalNombre || ''
                                        }
                                    }
                                }, { quoted: msg });
                            }
                        }
                        
                    } else {
                        throw new Error('No se encontró contenido');
                    }
                    
                } catch (nexrayError) {
                    console.log('⚠️ API NexRay v2 falló:', nexrayError.message);
                    
                    // Respaldo para publicación con NexRay original
                    const apiUrl = `https://api.nexray.eu.cc/downloader/instagram?url=${encodeURIComponent(url)}`;
                    const response = await axios.get(apiUrl, {
                        timeout: 30000,
                        headers: {
                            'accept': '*/*',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    const data = response.data;
                    if (data.status && data.result && data.result.length > 0) {
                        for (let i = 0; i < data.result.length; i++) {
                            const media = data.result[i];
                            if (media.url) {
                                const imgResponse = await axios.get(media.url, { responseType: 'arraybuffer', timeout: 30000 });
                                const imgBuffer = Buffer.from(imgResponse.data);
                                
                                await sock.sendMessage(from, {
                                    image: imgBuffer,
                                    caption: `♡ *Instagram Download*`,
                                    contextInfo: {
                                        forwardingScore: 9999999,
                                        isForwarded: true,
                                        forwardedNewsletterMessageInfo: {
                                            newsletterJid: config.canalId || '',
                                            serverMessageId: 0,
                                            newsletterName: config.canalNombre || ''
                                        }
                                    }
                                }, { quoted: msg });
                            }
                        }
                    } else {
                        throw new Error('No se pudo obtener el contenido');
                    }
                }
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Instagram descargado por ${pushName || userNumber} - ${isReel ? 'Reel' : 'Publicación'}`);
            
        } catch (error) {
            console.error('❌ Error en ig:', error);
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`♡ Ocurrió un error: ${error.message}`);
            } catch (e) {}
        }
    }
};