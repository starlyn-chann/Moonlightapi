import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const API_DELIRIUS = 'https://api.delirius.store/download/mediafire';

const tempFolder = path.join(__dirname, '..', 'temp');
if (!fs.existsSync(tempFolder)) fs.mkdirSync(tempFolder, { recursive: true });

function getTempFilePath(extension) {
    return path.join(tempFolder, `mediafire_${Date.now()}_${Math.random().toString(36).substring(7)}.${extension}`);
}

function getFileTypeInfo(filename, fileType) {
    const lowerName = filename.toLowerCase();
    const type = fileType || '';
    
    // APK y variantes
    if (type === '.apk' || lowerName.endsWith('.apk')) {
        return { type: 'apk', emoji: '📱', name: 'APK (Android App)' };
    }
    if (lowerName.includes('apk+') || lowerName.includes('apkplus')) {
        return { type: 'apkplus', emoji: '📱✨', name: 'APK+ (App Modificada)' };
    }
    
    // Minecraft packs
    if (type === '.mcpack' || lowerName.endsWith('.mcpack')) {
        return { type: 'mcpack', emoji: '🎮', name: 'Minecraft Pack (.mcpack)' };
    }
    if (type === '.mcaddon' || lowerName.endsWith('.mcaddon')) {
        return { type: 'mcaddon', emoji: '🎮', name: 'Minecraft Addon' };
    }
    if (type === '.mcworld' || lowerName.endsWith('.mcworld')) {
        return { type: 'mcworld', emoji: '🌍', name: 'Minecraft World' };
    }
    if (type === '.mctemplate' || lowerName.endsWith('.mctemplate')) {
        return { type: 'mctemplate', emoji: '📐', name: 'Minecraft Template' };
    }
    
    // Archivos comprimidos
    if (type === '.zip' || lowerName.endsWith('.zip')) {
        return { type: 'zip', emoji: '🗜️', name: 'Archivo ZIP' };
    }
    if (type === '.rar' || lowerName.endsWith('.rar')) {
        return { type: 'rar', emoji: '🗜️', name: 'Archivo RAR' };
    }
    if (type === '.7z' || lowerName.endsWith('.7z')) {
        return { type: '7z', emoji: '🗜️', name: 'Archivo 7Z' };
    }
    
    // Videos
    if (type === '.mp4' || lowerName.endsWith('.mp4')) {
        return { type: 'video', emoji: '🎬', name: 'Video MP4' };
    }
    if (type === '.mkv' || lowerName.endsWith('.mkv')) {
        return { type: 'video', emoji: '🎬', name: 'Video MKV' };
    }
    
    // Audios
    if (type === '.mp3' || lowerName.endsWith('.mp3')) {
        return { type: 'audio', emoji: '🎵', name: 'Audio MP3' };
    }
    
    // Imágenes
    if (type === '.jpg' || type === '.jpeg' || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) {
        return { type: 'image', emoji: '🖼️', name: 'Imagen JPG' };
    }
    if (type === '.png' || lowerName.endsWith('.png')) {
        return { type: 'image', emoji: '🖼️', name: 'Imagen PNG' };
    }
    
    // Documentos
    if (type === '.pdf' || lowerName.endsWith('.pdf')) {
        return { type: 'pdf', emoji: '📄', name: 'Documento PDF' };
    }
    if (type === '.txt' || lowerName.endsWith('.txt')) {
        return { type: 'text', emoji: '📝', name: 'Texto' };
    }
    
    // Ejecutables
    if (type === '.exe' || lowerName.endsWith('.exe')) {
        return { type: 'exe', emoji: '⚙️', name: 'Ejecutable EXE' };
    }
    
    return { type: 'file', emoji: '📁', name: 'Archivo' };
}

function getMimeType(filename, fileType) {
    const lowerName = filename.toLowerCase();
    const type = fileType || '';
    
    if (type === '.apk' || lowerName.endsWith('.apk')) return 'application/vnd.android.package-archive';
    if (type === '.mcpack' || lowerName.endsWith('.mcpack')) return 'application/octet-stream';
    if (type === '.mcaddon' || lowerName.endsWith('.mcaddon')) return 'application/octet-stream';
    if (type === '.mcworld' || lowerName.endsWith('.mcworld')) return 'application/octet-stream';
    if (type === '.mctemplate' || lowerName.endsWith('.mctemplate')) return 'application/octet-stream';
    if (type === '.zip' || lowerName.endsWith('.zip')) return 'application/zip';
    if (type === '.rar' || lowerName.endsWith('.rar')) return 'application/x-rar-compressed';
    if (type === '.7z' || lowerName.endsWith('.7z')) return 'application/x-7z-compressed';
    if (type === '.mp4' || lowerName.endsWith('.mp4')) return 'video/mp4';
    if (type === '.mkv' || lowerName.endsWith('.mkv')) return 'video/x-matroska';
    if (type === '.mp3' || lowerName.endsWith('.mp3')) return 'audio/mpeg';
    if (type === '.jpg' || type === '.jpeg' || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) return 'image/jpeg';
    if (type === '.png' || lowerName.endsWith('.png')) return 'image/png';
    if (type === '.pdf' || lowerName.endsWith('.pdf')) return 'application/pdf';
    if (type === '.txt' || lowerName.endsWith('.txt')) return 'text/plain';
    if (type === '.exe' || lowerName.endsWith('.exe')) return 'application/x-msdownload';
    
    return 'application/octet-stream';
}

function parseSizeToMB(sizeStr) {
    if (!sizeStr) return 0;
    // Extraer número y unidad (ej: "452.5MB" → 452.5, "1.2GB" → 1.2)
    const match = sizeStr.match(/(\d+(?:\.\d+)?)\s*(MB|GB)/i);
    if (match) {
        const size = parseFloat(match[1]);
        const unit = match[2].toUpperCase();
        if (unit === 'GB') return size * 1024;
        return size;
    }
    // Si no encuentra MB/GB, intentar extraer solo número
    const numMatch = sizeStr.match(/(\d+(?:\.\d+)?)/);
    if (numMatch) {
        return parseFloat(numMatch[1]);
    }
    return 0;
}

export default {
    name: 'mf',
    alias: ['mediafire'],
    description: 'Descarga archivos de Mediafire',
    category: 'download',
    
    async execute(sock, msg, options) {
        let tempPath = null;
        
        try {
            const { args, config, senderJid, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const url = args.join(' ').trim();
            
            if (!url) {
                return await replyWithContext(`「✰」 Debes proporcionar un enlace de Mediafire\n> Ejemplo: ${config.prefix}mediafire https://www.mediafire.com/file/xxxxx`);
            }
            
            if (!url.includes('mediafire.com')) {
                return await replyWithContext(`「✰」 Link inválido\n> Debes proporcionar un enlace de Mediafire válido.`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '📥', key: msg.key } });
            } catch (e) {}
            
            // ============ API DELIRIUS ============
            const response = await axios.get(`${API_DELIRIUS}?url=${encodeURIComponent(url)}`, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'accept': '*/*'
                }
            });
            
            if (!response.data?.status || !response.data?.data) {
                throw new Error('No se pudo obtener información del archivo');
            }
            
            const data = response.data.data;
            const filename = data.filename || 'archivo';
            const filesize = data.size || 'Desconocido';
            const uploaded = data.uploaded || 'Desconocido';
            const extension = data.extension || path.extname(filename) || '';
            const downloadUrl = data.link;
            
            if (!downloadUrl) {
                throw new Error('No se pudo obtener el enlace de descarga');
            }
            
            // Verificar tamaño máximo (300MB) - ANTES DE DESCARGAR
            const sizeInMB = parseSizeToMB(filesize);
            if (sizeInMB > 300) {
                return await replyWithContext(`《✧》Archivo demasiado grande\n> *Límite:* 300MB`);
            }
            
            const fileInfo = getFileTypeInfo(filename, `.${extension}`);
            
            await replyWithContext(
                `✩̶๋۪ׄ ꒱ *Nombre:* ${filename.replace(/\+/g, ' ')}\n` +
                `✩̶๋۪ׄ ꒱ *Tamaño:* ${filesize}\n` +
                `✩̶๋۪ׄ ꒱ *Tipo:* ${fileInfo.name}\n` +
                `> *Descargando archivo...* Esto puede tomar varios minutos.`
            );
            
            const fileResponse = await axios.get(downloadUrl, {
                responseType: 'stream',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            const tempExt = extension ? `.${extension}` : '.bin';
            tempPath = getTempFilePath(tempExt);
            const writer = fs.createWriteStream(tempPath);
            
            await new Promise((resolve, reject) => {
                fileResponse.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
            
            const fileBuffer = fs.readFileSync(tempPath);
            
            const sizeMB = (fileBuffer.length / 1024 / 1024).toFixed(2);
            let cleanFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
            const mimeType = getMimeType(filename, `.${extension}`);
            
            await sock.sendMessage(from, {
                document: fileBuffer,
                mimetype: mimeType,
                fileName: cleanFilename,
                caption: `> Solicitado por: ${pushName || userNumber}`,
                contextInfo: {
                    mentionedJid: senderJid ? [senderJid] : [],
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Archivo descargado: ${filename} (${sizeMB} MB) - Tipo: ${fileInfo.type} por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en mediafire:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ *Error:* ${error.message}\n\n> Verifica que el enlace sea válido y vuelve a intentarlo.`);
            } catch (e) {}
            
        } finally {
            try { if (tempPath && fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch (e) {}
        }
    }
};