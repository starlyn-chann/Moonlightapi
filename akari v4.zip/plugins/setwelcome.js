import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const WELCOME_FILE = path.join(__dirname, '..', 'data', 'welcome.json');

function loadWelcome() {
    try {
        if (fs.existsSync(WELCOME_FILE)) {
            const data = fs.readFileSync(WELCOME_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de bienvenida:', e);
    }
    return {};
}

function saveWelcome(welcome) {
    try {
        fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcome, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando mensajes de bienvenida:', e);
        return false;
    }
}

export default {
    name: 'setwelcome',
    alias: ['setwlc'],
    description: 'Configurar mensaje de bienvenida del grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, isGroup, isOwner } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            const groupMetadata = await sock.groupMetadata(from);
            const participant = groupMetadata.participants.find(p => p.id === msg.key.participant);
            const isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
            
            if (!isAdmin && !isOwner) {
                return await replyWithContext(`*ᰔᩚ* *Solo administradores pueden usar este comando*`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(
                    `Debes proporcionar un mensaje de bienvenida\n\n*❒ Opciones*\n\n꒰ 👒 ੭  ﾟ@user\n> → Mención del usuario que entra\n\n꒰ 👒 ੭  ﾟ@group\n> → Nombre del grupo\n\n꒰ 👒 ੭  ﾟ@desc\n> → Descripción del grupo\n\n꒰ 👒 ੭  ﾟ@members\n> → Número de miembros actuales\n\n꒰ 👒 ੭  ﾟ@time\n> → Fecha y hora`
                );
            }

            const welcomeData = loadWelcome();
            
            if (!welcomeData[from]) {
                welcomeData[from] = {
                    message: '',
                    enabled: true
                };
            }

            if (args[0] === '0') {
                if (!welcomeData[from].message || welcomeData[from].message.trim() === '') {
                    return await replyWithContext('✎ No tienes ningún mensaje de bienvenida definido.');
                }
                welcomeData[from].message = '';
                welcomeData[from].enabled = false;
                saveWelcome(welcomeData);
                return await replyWithContext('✐ Mensaje de bienvenida eliminado.');
            }

            if (welcomeData[from].message && welcomeData[from].message.trim() !== '') {
                return await replyWithContext(
                    `《✤》 Ya tienes un mensaje de bienvenida configurado:\n\n${welcomeData[from].message}\n\nSi quieres reemplazarlo, primero bórralo con:\n${config.prefix}setwelcome 0`
                );
            }

            const texto = args.join(' ');
            welcomeData[from].message = texto;
            welcomeData[from].enabled = true;
            saveWelcome(welcomeData);
            
            await replyWithContext(`✐ Nuevo mensaje de bienvenida configurado correctamente.`);
            
        } catch (error) {
            console.error('❌ Error en setwelcome:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};