import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { connectMongoDB } from '../lib/mongoose.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============ ESQUEMA Y MODELO PARA HISTORIAL ============
let HistorialModel = null;
let mongoose = null;

async function getHistorialModel() {
    if (HistorialModel) return HistorialModel;
    
    const { default: mongooseMod } = await import('mongoose');
    mongoose = mongooseMod;
    
    await connectMongoDB();
    
    const historialSchema = new mongoose.Schema({
        _id: { type: String, required: true },
        conversacion: { type: Array, default: [] },
        ultimaActualizacion: { type: Date, default: Date.now }
    });
    
    HistorialModel = mongoose.model('HistorialGemini', historialSchema);
    return HistorialModel;
}

// ============ FUNCIONES PARA HISTORIAL ============
async function getHistorialUsuario(userNumber) {
    try {
        const model = await getHistorialModel();
        const usuario = await model.findOne({ _id: userNumber });
        if (!usuario) return [];
        return usuario.conversacion || [];
    } catch (error) {
        console.error('Error cargando historial:', error);
        return [];
    }
}

async function addToHistorial(userNumber, role, content) {
    try {
        const model = await getHistorialModel();
        const usuario = await model.findOne({ _id: userNumber });
        
        const nuevoMensaje = {
            role: role,
            content: content,
            timestamp: new Date().toISOString()
        };
        
        if (usuario) {
            usuario.conversacion.push(nuevoMensaje);
            if (usuario.conversacion.length > 20) {
                usuario.conversacion = usuario.conversacion.slice(-20);
            }
            usuario.ultimaActualizacion = new Date();
            await usuario.save();
        } else {
            const nuevoUsuario = new model({
                _id: userNumber,
                conversacion: [nuevoMensaje]
            });
            await nuevoUsuario.save();
        }
        return true;
    } catch (error) {
        console.error('Error guardando historial:', error);
        return false;
    }
}

function construirContexto(historial, nuevaPregunta) {
    let contexto = '';
    
    for (const msg of historial) {
        if (msg.role === 'user') {
            contexto += `Usuario: ${msg.content}\n`;
        } else {
            contexto += `Gemini: ${msg.content}\n`;
        }
    }
    
    contexto += `Usuario: ${nuevaPregunta}\nGemini:`;
    
    return contexto;
}

export default {
    name: 'gemini',
    alias: ['ai'],
    description: 'Pregunta algo a Gemini AI',
    category: 'ai',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext } = options;
            const from = msg.key.remoteJid;
            
            const prompt = args.join(' ').trim();
            
            if (!prompt) {
                return await replyWithContext(`[ ★ ] Debes proporcionar una pregunta para Gemini`);
            }
            
            try {
                await sock.sendMessage(from, { react: { text: '🙀', key: msg.key } });
            } catch (e) {}
            
            await addToHistorial(userNumber, 'user', prompt);
            
            const historial = await getHistorialUsuario(userNumber);
            const contexto = construirContexto(historial, prompt);
            
            console.log(`📝 Contexto para ${pushName || userNumber}: ${historial.length} mensajes previos`);
            
            let answer = null;
            
            try {
                console.log(`🤖 Consultando API Gemini...`);
                
                const apiUrl = `https://api.soonex.biz.id/v1/ai/gemini?text=${encodeURIComponent(contexto)}`;
                
                const response = await axios.get(apiUrl, {
                    timeout: 60000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Accept': 'application/json'
                    }
                });
                
                if (response.data?.status && response.data?.result) {
                    answer = response.data.result;
                    console.log(`✅ Respuesta obtenida de API Soonex`);
                } else {
                    throw new Error('No se pudo obtener respuesta de la API');
                }
                
            } catch (error) {
                console.log(`⚠️ API Soonex falló: ${error.message}`);
                
                const APIS_ALTERNAS = [
                    {
                        name: 'ZenZX',
                        url: 'https://api.zenzxz.my.id/ai/gemini',
                        param: 'prompt',
                        getAnswer: (data) => data?.result?.reply
                    },
                    {
                        name: 'Varhad',
                        url: 'https://v2.api-varhad.my.id/ai/gemini',
                        param: 'prompt',
                        getAnswer: (data) => data?.result?.text
                    },
                    {
                        name: 'NexRay',
                        url: 'https://api.nexray.web.id/ai/gemini',
                        param: 'text',
                        getAnswer: (data) => data?.result
                    }
                ];
                
                for (const api of APIS_ALTERNAS) {
                    try {
                        console.log(`🤖 Intentando API alternativa ${api.name}...`);
                        
                        const response = await axios.get(`${api.url}?${api.param}=${encodeURIComponent(contexto)}`, {
                            timeout: 60000,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Accept': 'application/json'
                            }
                        });
                        
                        answer = api.getAnswer(response.data);
                        
                        if (answer) {
                            console.log(`✅ Respuesta obtenida de ${api.name}`);
                            break;
                        }
                        
                    } catch (err) {
                        console.log(`⚠️ API alternativa ${api.name} falló: ${err.message}`);
                        continue;
                    }
                }
            }
            
            if (!answer) {
                throw new Error('Todas las APIs fallaron');
            }
            
            answer = answer.replace(/Gemini:/g, '').trim();
            
            await addToHistorial(userNumber, 'assistant', answer);
            
            if (answer.length > 3000) {
                answer = answer.substring(0, 3000) + '\n\n... (respuesta truncada)';
            }
            
            await replyWithContext(`${answer}`);
            
            try {
                await sock.sendMessage(from, { react: { text: '🌟', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Gemini respondió para ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en gemini:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`[ ★ ] *Error:* No se pudo obtener respuesta. Intenta más tarde.`);
            } catch (e) {}
        }
    }
};