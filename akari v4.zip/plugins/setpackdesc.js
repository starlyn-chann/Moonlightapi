import { obtenerPacksUsuario, actualizarPack } from '../lib/mongoose.js';

export default {
    name: 'setpackdesc',
    alias: ['packdesc', 'descripcion'],
    description: 'Establece la descripción y autor de un pack de stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid, pushName } = options;
            
            const args = options.args || [];
            
            if (args.length < 3) {
                return await replyWithContext(`「✰」Formato incorrecto\n> Ejemplo: ${config.prefix}setpackdesc nombre del pack / autor | descripción`);
            }
            
            const fullText = args.join(' ');
            
            // Buscar el primer " / " para separar nombre del pack del resto
            const separatorIndex = fullText.indexOf(' / ');
            
            if (separatorIndex === -1) {
                return await replyWithContext(`「✰」Formato incorrecto\n> Usa " / " para separar el nombre del pack\n> Ejemplo: ${config.prefix}setpackdesc Mis Stickers / Moonlight | Stickers de la comunidad`);
            }
            
            const packName = fullText.substring(0, separatorIndex).trim();
            const rest = fullText.substring(separatorIndex + 3).trim();
            
            if (!packName) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre del pack`);
            }
            
            // Buscar el " | " para separar autor y descripción
            const pipeIndex = rest.indexOf(' | ');
            
            let author = '';
            let description = '';
            
            if (pipeIndex !== -1) {
                // Tiene autor y descripción
                author = rest.substring(0, pipeIndex).trim();
                description = rest.substring(pipeIndex + 3).trim();
            } else {
                // Si no tiene " | ", solo descripción
                description = rest;
            }
            
            if (!description) {
                return await replyWithContext(`「✰」Debes proporcionar una descripción\n> Ejemplo: ${config.prefix}setpackdesc Mis Stickers / Moonlight | Stickers de la comunidad`);
            }
            
            if (description.length > 100) {
                return await replyWithContext(`「✰」La descripción no puede tener más de 100 caracteres`);
            }
            
            // Obtener packs del usuario desde MongoDB
            const packs = await obtenerPacksUsuario(userNumber);
            
            if (!packs || packs.length === 0) {
                return await replyWithContext(`「✰」No tienes ningún pack creado\n> Crea uno con ${config.prefix}newpack <nombre>`);
            }
            
            const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (!pack) {
                return await replyWithContext(`「✰」No tienes un pack llamado "${packName}"\n> Usa ${config.prefix}packlist para ver tus packs`);
            }
            
            // Preparar datos para actualizar
            const datosActualizar = {
                desc: description
            };
            
            // Si hay autor, actualizarlo también
            if (author) {
                datosActualizar.author = author;
            }
            
            // Actualizar en MongoDB
            const resultado = await actualizarPack(userNumber, packName, datosActualizar);
            
            if (!resultado) {
                return await replyWithContext(`❌ Error al actualizar la descripción. Por favor, intenta nuevamente.`);
            }
            
            let mensaje = `《✧》Descripción del pack actualizada`;
            
            if (author) {
                mensaje += ` `;
            }
            
            await replyWithContext(mensaje);
            
            console.log(`✅ Descripción del pack "${packName}" actualizada por ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en setpackdesc:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};