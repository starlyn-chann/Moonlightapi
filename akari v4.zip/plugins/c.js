import { 
    reclamarPersonaje, 
    obtenerPersonajePorId, 
    verificarReclamo,
    obtenerPersonajesReclamados,
    obtenerPersonajePorNombre
} from '../lib/gacha.js';
import { 
    getPersonajeEnGrupo, 
    eliminarPersonajeDelCache,
    getTiempoRestante,
    loadCache
} from '../lib/gachaCache.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
const CLAIM_MSG_FILE = path.join(__dirname, '..', 'data', 'claim_messages.json');

function loadUsersDb() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return [];
}

function loadClaimMessages() {
    try {
        if (fs.existsSync(CLAIM_MSG_FILE)) {
            const data = fs.readFileSync(CLAIM_MSG_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de claim:', e);
    }
    return {};
}

function getClaimMessage(userNumber) {
    const messages = loadClaimMessages();
    return messages[userNumber] || null;
}

export default {
    name: 'claim',
    alias: ['c', 'reclamar'],
    description: 'Reclama un personaje del gacha',
    category: 'gacha',
    
    async execute(sock, msg, options) {
        try {
            console.log('🚀 Ejecutando comando claim...');
            
            const { config, replyWithContext, userNumber, senderJid, pushName } = options;
            const from = msg.key.remoteJid;
            
            if (!from.endsWith('@g.us')) {
                return await replyWithContext(`❌ *Este comando solo funciona en grupos*`);
            }
            
            // ============ OBTENER MENSAJE CITADO DIRECTAMENTE DEL MSG ============
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            console.log(`📌 quotedMsg: ${quotedMsg ? 'Sí' : 'No'}`);
            console.log(`📌 quotedMessage: ${quotedMessage ? 'Sí' : 'No'}`);
            
            if (!quotedMsg || !quotedMessage) {
                return await replyWithContext(`*ᰔᩚ* Responde al mensaje del personaje que quieres reclamar`);
            }
            
            // Obtener el texto del mensaje citado
            let textoCitado = '';
            
            if (quotedMessage.conversation) {
                textoCitado = quotedMessage.conversation;
            } else if (quotedMessage.extendedTextMessage?.text) {
                textoCitado = quotedMessage.extendedTextMessage.text;
            } else if (quotedMessage.imageMessage?.caption) {
                textoCitado = quotedMessage.imageMessage.caption;
            } else if (quotedMessage.videoMessage?.caption) {
                textoCitado = quotedMessage.videoMessage.caption;
            }
            
            console.log(`📝 Texto citado: ${textoCitado ? textoCitado.substring(0, 100) : 'VACÍO'}...`);
            
            if (!textoCitado) {
                return await replyWithContext(`*ᰔᩚ* No pude leer el mensaje del personaje\n> Asegúrate de responder al mensaje correcto`);
            }
            
            // Verificar si el mensaje citado contiene un personaje
            const esMensajeRW = textoCitado.includes('❀ 𝖭𝗈𝗆𝖻𝗋𝖾 ›') || 
                               textoCitado.includes('❀ 𝖭𝗈𝗆𝖻𝗋𝖾 ›') ||
                               textoCitado.includes('Nombre ›');
            
            if (!esMensajeRW) {
                return await replyWithContext(`*ᰔᩚ* Responde al mensaje del personaje que quieres reclamar`);
            }
            
            // Extraer el nombre del personaje
            let nombrePersonaje = '';
            const nombreMatch = textoCitado.match(/❀ 𝖭𝗈𝗆𝖻𝗋𝖾 › ([^\n]+)/) || 
                               textoCitado.match(/❀ 𝖭𝗈𝗆𝖻𝗋𝖾 › ([^\n]+)/) ||
                               textoCitado.match(/Nombre › ([^\n]+)/);
            
            if (nombreMatch) {
                nombrePersonaje = nombreMatch[1].trim();
                console.log(`✅ Nombre del personaje: ${nombrePersonaje}`);
            }
            
            if (!nombrePersonaje) {
                return await replyWithContext(`*ᰔᩚ* No pude identificar el personaje en el mensaje`);
            }
            
            // ============ VERIFICAR SI EL PERSONAJE YA FUE RECLAMADO ============
            const personajeBD = await obtenerPersonajePorNombre(nombrePersonaje);
            
            if (personajeBD) {
                const reclamado = await verificarReclamo(from, personajeBD.id);
                
                if (reclamado) {
                    const reclamos = await obtenerPersonajesReclamados(from);
                    const reclamo = reclamos.find(r => r.personajeId === personajeBD.id);
                    let nombreReclamador = 'alguien';
                    
                    if (reclamo) {
                        const usersDb = loadUsersDb();
                        const user = usersDb.find(u => u.number === reclamo.usuarioId);
                        nombreReclamador = user ? user.pushName : reclamo.usuarioId;
                    }
                    
                    return await replyWithContext(`❀ ${personajeBD.nombre} ya fue reclamado por ${nombreReclamador}`);
                }
            }
            // ================================================================
            
            // Buscar el personaje en el cache del usuario
            const cacheKey = `${from}_${userNumber}`;
            const cacheData = getPersonajeEnGrupo(cacheKey);
            
            // Si no hay personaje activo del usuario
            if (!cacheData) {
                // Buscar en todo el cache si el personaje está protegido por otro usuario
                const allCache = loadCache();
                let protegidoPor = null;
                let tiempoRestanteProtegido = 0;
                
                for (const [key, value] of Object.entries(allCache)) {
                    if (key.includes(from) && value.personajeId === personajeBD?.id) {
                        protegidoPor = value.usuarioId;
                        const tiempoTranscurrido = Date.now() - value.timestamp;
                        const tiempoRestante = Math.max(0, 120 - (tiempoTranscurrido / 1000));
                        tiempoRestanteProtegido = Math.ceil(tiempoRestante);
                        break;
                    }
                }
                
                if (protegidoPor && tiempoRestanteProtegido > 0) {
                    const jid = `${protegidoPor}@s.whatsapp.net`;
                    const tiempoStr = `${tiempoRestanteProtegido}s`;
                    return await replyWithContext(
                        `✰ ${nombrePersonaje} está protegido por @${protegidoPor} por ${tiempoStr}`,
                        [jid]
                    );
                }
                
                if (personajeBD) {
                    return await replyWithContext(`⚠︎ *El personaje ${nombrePersonaje} ya expiró*\n> Usa ${config.prefix}rw para obtener uno nuevo`);
                }
                
                return await replyWithContext(`*ᰔᩚ* No hay personaje activo para reclamar\n> Usa ${config.prefix}rw para obtener uno nuevo`);
            }
            
            // Verificar que el personaje coincida con el nombre
            const personajeCache = await obtenerPersonajePorId(cacheData.personajeId);
            if (!personajeCache) {
                eliminarPersonajeDelCache(cacheKey);
                return await replyWithContext(`⚠︎ *El personaje ${nombrePersonaje} ya expiró*\n> Usa ${config.prefix}rw para obtener uno nuovo`);
            }
            
            if (personajeCache.nombre.toLowerCase() !== nombrePersonaje.toLowerCase()) {
                return await replyWithContext(`*ᰔᩚ* Este no es tu personaje activo`);
            }
            
            // Verificar si puede reclamar según la fase
            if (cacheData.fase === 1 && cacheData.usuarioId !== userNumber) {
                const tiempoRestante = getTiempoRestante(cacheKey);
                const segundosRestantes = Math.min(60, Math.floor(tiempoRestante - 60));
                if (segundosRestantes > 0) {
                    const usuarioProtegido = cacheData.usuarioId;
                    const jid = `${usuarioProtegido}@s.whatsapp.net`;
                    const tiempoStr = `${segundosRestantes}s`;
                    return await replyWithContext(
                        `✰ ${personajeCache.nombre} está protegido por @${usuarioProtegido} por ${tiempoStr}`,
                        [jid]
                    );
                }
            }
            
            // Verificar si ya fue reclamado permanentemente
            const yaReclamado = await reclamarPersonaje(from, personajeCache.id, userNumber);
            if (!yaReclamado.success) {
                eliminarPersonajeDelCache(cacheKey);
                const reclamos = await obtenerPersonajesReclamados(from);
                const reclamo = reclamos.find(r => r.personajeId === personajeCache.id);
                let nombreReclamador = 'alguien';
                if (reclamo) {
                    const usersDb = loadUsersDb();
                    const user = usersDb.find(u => u.number === reclamo.usuarioId);
                    nombreReclamador = user ? user.pushName : reclamo.usuarioId;
                }
                return await replyWithContext(`❀ ${personajeCache.nombre} ya fue reclamado por ${nombreReclamador}`);
            }
            
            // Eliminar del cache
            eliminarPersonajeDelCache(cacheKey);
            
            // ============ MENSAJE PERSONALIZADO ============
            const displayName = pushName || userNumber;
            const customMsg = getClaimMessage(userNumber);
            
            let mensaje = '';
            if (customMsg) {
                // Mensaje personalizado con el formato *⚡︎* 
                const textoPersonalizado = customMsg
                    .replace(/\$user/g, `${displayName}`)
                    .replace(/\$character/g, `${personajeCache.nombre}`);
                mensaje = `*⚡︎* ${textoPersonalizado}`;
            } else {
                // Mensaje predeterminado
                mensaje = `❀ ${personajeCache.nombre} ha sido reclamado por ${displayName}`;
            }
            // ================================================================

            await replyWithContext(mensaje);
            console.log('✅ Comando claim finalizado');
            
        } catch (error) {
            console.error('❌ Error en claim:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};