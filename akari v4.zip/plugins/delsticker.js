import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { obtenerPacksUsuario, eliminarSticker } from '../lib/mongoose.js';

export default {
    name: 'delsticker',
    alias: ['removesticker', 'borrarsticker'],
    description: 'Elimina un sticker de un pack',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid } = options;
            const from = msg.key.remoteJid;
            
            const args = options.args || [];
            const packName = args.join(' ').trim();
            
            if (!packName) {
                return await replyWithContext(`「✰」Debes proporcionar el nombre del pack\n> Ejemplo: ${config.prefix}delsticker Mis Stickers (respondiendo al sticker que quieres eliminar)`);
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            const quotedMessage = quotedMsg?.quotedMessage;
            
            if (!quotedMessage || !quotedMessage.stickerMessage) {
                return await replyWithContext(`「✰」Debes responder a un sticker\n> Ejemplo: ${config.prefix}delsticker Mis Stickers (respondiendo al sticker que quieres eliminar)`);
            }
            
            // Obtener packs del usuario desde MongoDB
            const packs = await obtenerPacksUsuario(userNumber);
            
            if (!packs || packs.length === 0) {
                return await replyWithContext(`「✰」No tienes ningún pack creado`);
            }
            
            const pack = packs.find(p => p.name.toLowerCase() === packName.toLowerCase());
            
            if (!pack) {
                return await replyWithContext(`「✰」No tienes un pack llamado "${packName}"\n> Usa ${config.prefix}packlist para ver tus packs`);
            }
            
            if (!pack.stickers || pack.stickers.length === 0) {
                return await replyWithContext(`「✰」El pack "${packName}" no tiene stickers`);
            }
            
            const quotedMsgObj = {
                key: {
                    remoteJid: from,
                    id: quotedMsg.stanzaId,
                    participant: quotedMsg.participant || from,
                    fromMe: false
                },
                message: {
                    stickerMessage: quotedMessage.stickerMessage
                }
            };
            
            const stickerBuffer = await downloadMediaMessage(
                quotedMsgObj,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );
            
            if (!stickerBuffer || stickerBuffer.length === 0) {
                throw new Error('No se pudo descargar el sticker');
            }
            
            const stickerBase64 = stickerBuffer.toString('base64');
            
            // Buscar el sticker por su buffer
            const stickerToDelete = pack.stickers.find(s => s.buffer === stickerBase64);
            
            if (!stickerToDelete) {
                return await replyWithContext(`「✰」No se encontró ese sticker en el pack *"${packName}"*`);
            }
            
            // Eliminar sticker de MongoDB
            const resultado = await eliminarSticker(userNumber, packName, stickerToDelete.id);
            
            if (!resultado) {
                return await replyWithContext(`❌ Error al eliminar el sticker. Por favor, intenta nuevamente.`);
            }
            
            await replyWithContext(`「✰」Sticker eliminado del pack \`${pack.name}\` exitosamente`);
            
        } catch (error) {
            console.error('❌ Error en delsticker:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};