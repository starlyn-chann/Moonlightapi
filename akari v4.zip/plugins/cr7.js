import axios from 'axios';

export default {
    name: 'cr7',
    alias: ['ronaldo'],
    description: 'Envía una imagen aleatoria de Cristiano Ronaldo',
    category: 'image',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, pushName, userNumber } = options;
            const from = msg.key.remoteJid;
            
            try {
                await sock.sendMessage(from, { react: { text: '⚽', key: msg.key } });
            } catch (e) {}
            
            // Obtener imágenes del JSON
            const response = await axios.get('https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/CristianoRonaldo.json');
            const images = response.data;
            
            if (!images || images.length === 0) {
                throw new Error('No se encontraron imágenes');
            }
            
            const randomImage = images[Math.floor(Math.random() * images.length)];
            
            // Descargar la imagen
            const imgResponse = await axios.get(randomImage, { responseType: 'arraybuffer' });
            const imgBuffer = Buffer.from(imgResponse.data);
            
            // Enviar imagen con botón quick reply
            await sock.sendMessage(from, {
                image: imgBuffer,
                caption: "*Siiiuuuuuu*",
                footer: "Moonlight",
                interactiveButtons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Siguiente",
                            id: `${config.prefix}cr7`
                        })
                    }
                ],
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Cristiano Ronaldo enviado a ${pushName || userNumber}`);
            
        } catch (error) {
            console.error('❌ Error en cristianoronaldo:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};