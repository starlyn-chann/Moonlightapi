import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

export default {
    name: 'cf',
    alias: ['coinflip', 'caraocruz'],
    description: 'Apuesta a cara o cruz',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length < 2) {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Ejemplo: ${config.prefix}cf 1000 cara\n> ${config.prefix}cf cruz 500`);
            }
            
            let cantidad = 0;
            let lado = '';
            
            const firstArg = args[0].toLowerCase();
            const secondArg = args[1].toLowerCase();
            
            if (!isNaN(firstArg) && parseInt(firstArg) > 0) {
                cantidad = parseInt(firstArg);
                lado = secondArg;
            } else if (!isNaN(secondArg) && parseInt(secondArg) > 0) {
                cantidad = parseInt(secondArg);
                lado = firstArg;
            } else {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Ejemplo: ${config.prefix}cf 1000 cara\n> ${config.prefix}cf cruz 500`);
            }
            
            if (cantidad <= 0) {
                return await replyWithContext(`「✰」 La cantidad debe ser mayor a 0`);
            }
            
            if (lado !== 'cara' && lado !== 'cruz') {
                return await replyWithContext(`「✰」 Solo puedes apostar a *cara* o *cruz*`);
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const dineroActual = economy[from][userNumber].dinero || 0;
            
            if (cantidad > dineroActual) {
                return await replyWithContext(`❀ *No tienes suficiente dinero*\n> Billetera: ${dineroActual} ${config.moneda}`);
            }
            
            const resultado = Math.random() < 0.5 ? 'cara' : 'cruz';
            const esGanador = lado === resultado;
            
            let mensaje = '';
            
            if (esGanador) {
                economy[from][userNumber].dinero += cantidad;
                mensaje = `✧ Apuestas a *${lado}* y ganaste ${cantidad} ${config.moneda}`;
            } else {
                economy[from][userNumber].dinero -= cantidad;
                mensaje = `✧ Apuestas a *${lado}* y perdiste ${cantidad} ${config.moneda}`;
            }
            
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            await replyWithContext(`${mensaje}\n\n*Billetera:* ${economy[from][userNumber].dinero} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en cf:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};