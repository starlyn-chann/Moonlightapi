import { obtenerPacksUsuario } from '../lib/mongoose.js';

export default {
    name: 'packlist',
    alias: ['listpacks', 'mispacks'],
    description: 'Lista tus packs de stickers',
    category: 'stickers',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, userNumber, senderJid, pushName, args } = options;
            
            let targetNumber = userNumber;
            let targetName = pushName;
            let targetJid = senderJid;
            let isOther = false;
            
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
            
            if (mentionedJid) {
                targetJid = mentionedJid;
                targetNumber = targetJid.split('@')[0];
                targetName = args?.join(' ').replace(`@${targetNumber}`, '').trim() || 'Usuario';
                isOther = true;
            } else if (args && args.length > 0) {
                const possibleNumber = args[0].replace(/[^0-9]/g, '');
                if (possibleNumber && possibleNumber.length > 8) {
                    targetNumber = possibleNumber;
                    targetName = args.slice(1).join(' ') || `Usuario ${targetNumber}`;
                    targetJid = `${targetNumber}@s.whatsapp.net`;
                    isOther = true;
                }
            }
            
            // Obtener packs desde MongoDB
            const packs = await obtenerPacksUsuario(targetNumber);
            
            if (!packs || packs.length === 0) {
                const msgText = isOther 
                    ? `「✰」${targetName} no tiene packs creados` 
                    : `「✰」No tienes packs creados\n> Crea uno con ${config.prefix}newpack <nombre>`;
                return await replyWithContext(msgText, isOther ? [targetJid] : [senderJid]);
            }
            
            let packsList = '';
            
            for (const pack of packs) {
                const stickerCount = pack.stickers ? pack.stickers.length : 0;
                const progress = Math.floor((stickerCount / 50) * 10);
                const bar = '▓'.repeat(progress) + '░'.repeat(10 - progress);
                
                packsList += `❱❱ *Nombre* » ${pack.name}\n`;
                packsList += `❱❱ *Stickers* » ${stickerCount}/50 ${bar}\n`;
                packsList += `❱❱ *Creado* » ${pack.createdAt || 'N/A'}\n`;
                packsList += `❱❱ *Comando* » ${config.prefix}getpack ${pack.name}\n\n`;
            }
            
            const message = `ᅟ＼＿＿ 🌊ᤳ *Lista de Packs*\n\n` +
                          `★ *Usuario* » ${isOther ? targetName : pushName}\n` +
                          `★ *Packs* » ${packs.length}\n` +
                          `★ *Total stickers* » ${packs.reduce((acc, p) => acc + (p.stickers?.length || 0), 0)}\n\n` +
                          `${packsList}`;
            
            await replyWithContext(message, isOther ? [targetJid] : [senderJid]);
            
        } catch (error) {
            console.error('❌ Error en packlist:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};