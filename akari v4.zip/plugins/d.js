import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

export default {
    name: 'd',
    alias: ['depositar'],
    description: 'Deposita dinero en el banco',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName, args } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length === 0) {
                return await replyWithContext(`「✰」 Debes especificar una cantidad\n> Ejemplo: ${config.prefix}d 1000\n> ${config.prefix}d all`);
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const dineroActual = economy[from][userNumber].dinero || 0;
            
            let cantidad = 0;
            if (args[0].toLowerCase() === 'all') {
                cantidad = dineroActual;
            } else {
                cantidad = parseInt(args[0]);
                if (isNaN(cantidad) || cantidad <= 0) {
                    return await replyWithContext(`「✰」 Cantidad inválida\n> Debes ingresar un número positivo`);
                }
            }
            
            if (cantidad === 0) {
                return await replyWithContext(`❀ *No tienes dinero para depositar*`);
            }
            
            if (cantidad > dineroActual) {
                return await replyWithContext(`❀ *No tienes suficiente dinero*\n> Billetera: ${dineroActual} ${config.moneda}`);
            }
            
            economy[from][userNumber].dinero -= cantidad;
            economy[from][userNumber].banco = (economy[from][userNumber].banco || 0) + cantidad;
            economy[from][userNumber].nombre = pushName || 'Usuario';
            saveEconomy(economy);
            
            await replyWithContext(`❀ *Depósito exitoso*\n> Has depositado ${cantidad} ${config.moneda} en el banco\n\n*Billetera:* ${economy[from][userNumber].dinero} ${config.moneda}\n*Banco:* ${economy[from][userNumber].banco} ${config.moneda}`);
            
        } catch (error) {
            console.error('❌ Error en d:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};