import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
    fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

function cleanNumber(number) {
    if (!number) return '';
    let cleaned = number.split('@')[0];
    cleaned = cleaned.split(':')[0];
    return cleaned.replace(/\D/g, '');
}

function getCleanJid(jid) {
    if (!jid) return '';
    const number = cleanNumber(jid);
    return `${number}@s.whatsapp.net`;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export default {
    name: 'pay',
    alias: ['pagar', 'dar'],
    description: 'Regala dinero a otro usuario desde tu banco',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, isGroup, userNumber, pushName, args, senderJid } = options;
            const from = msg.key.remoteJid;
            
            if (!isGroup) {
                return await replyWithContext(`「✰」 Este comando solo funciona en grupos`);
            }
            
            if (!args || args.length < 2) {
                return await replyWithContext(`「✰」 Formato incorrecto\n> Ejemplo: ${config.prefix}pay 1000 @usuario`);
            }
            
            let cantidad = 0;
            let targetJid = null;
            let targetUser = null;
            
            const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentionedJid && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
                targetUser = cleanNumber(targetJid);
            }
            
            const quotedMsg = msg.message?.extendedTextMessage?.contextInfo;
            if (!targetJid && quotedMsg?.participant) {
                targetJid = quotedMsg.participant;
                targetUser = cleanNumber(targetJid);
            }
            
            if (!targetJid) {
                for (const arg of args) {
                    if (arg.includes('@') || arg.includes('s.whatsapp.net')) {
                        targetJid = arg;
                        targetUser = cleanNumber(targetJid);
                        break;
                    }
                }
            }
            
            if (!targetJid) {
                return await replyWithContext(`「✰」 Debes mencionar a quien quieres pagar\n> Ejemplo: ${config.prefix}pay 1000 @usuario`);
            }
            
            targetJid = getCleanJid(targetJid);
            targetUser = cleanNumber(targetJid);
            
            const senderCleanJid = getCleanJid(senderJid);
            if (targetJid === senderCleanJid) {
                return await replyWithContext(`❀ *No puedes pagarte a ti mismo*`);
            }
            
            for (const arg of args) {
                const num = parseInt(arg);
                if (!isNaN(num) && num > 0) {
                    cantidad = num;
                    break;
                }
            }
            
            if (cantidad <= 0) {
                return await replyWithContext(`「✰」 Debes especificar una cantidad válida\n> Ejemplo: ${config.prefix}pay 1000 @usuario`);
            }
            
            let economy = loadEconomy();
            if (!economy[from]) economy[from] = {};
            
            if (!economy[from][userNumber]) {
                economy[from][userNumber] = {
                    dinero: 0,
                    banco: 0,
                    nombre: pushName || 'Usuario'
                };
            }
            
            const bancoRemitente = economy[from][userNumber].banco || 0;
            
            if (cantidad > bancoRemitente) {
                return await replyWithContext(`❀ *No tienes suficiente dinero en el banco*\n> Banco: ${formatNumber(bancoRemitente)} ${config.moneda}`);
            }
            
            let targetName = 'Usuario';
            try {
                const contact = await sock.contactQuery(targetJid);
                if (contact) {
                    targetName = contact.notify || contact.name || 'Usuario';
                }
            } catch (e) {
                targetName = targetJid.split('@')[0];
            }
            
            if (!economy[from][targetUser]) {
                economy[from][targetUser] = {
                    dinero: 0,
                    banco: 0,
                    nombre: targetName
                };
            }
            
            // Restar del banco del remitente
            economy[from][userNumber].banco -= cantidad;
            
            // Depositar en el banco del destinatario
            economy[from][targetUser].banco = (economy[from][targetUser].banco || 0) + cantidad;
            
            economy[from][userNumber].nombre = pushName || 'Usuario';
            economy[from][targetUser].nombre = targetName;
            saveEconomy(economy);
            
            await replyWithContext(
                `✧ Has pagado ${formatNumber(cantidad)} ${config.moneda} a @${targetUser}\n\n*Tu banco:* ${formatNumber(economy[from][userNumber].banco)} ${config.moneda}`,
                [targetJid]
            );
            
        } catch (error) {
            console.error('❌ Error en pay:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};