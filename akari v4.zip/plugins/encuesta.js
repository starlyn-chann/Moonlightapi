export default {
    name: 'encuesta',
    alias: ['poll', 'votacion'],
    description: 'Crea una encuesta en el grupo',
    category: 'group',
    
    async execute(sock, msg, options) {
        try {
            const { args, config, pushName, userNumber, replyWithContext, isGroup } = options;
            const from = msg.key.remoteJid;
            
            // Verificar que sea un grupo
            if (!isGroup) {
                return await replyWithContext(`🌸 Este comando solo puede usarse en grupos.`);
            }
            
            const text = args.join(' ');
            
            if (!text) {
                return await replyWithContext(`「✰」 Ingresa la pregunta y opciones.\n> *Ejemplo:* ${config.prefix}encuesta ¿Te gusta el bot?|si|no`);
            }
            
            const textSplit = text.split('|');
            
            if (textSplit.length < 2) {
                return await replyWithContext(`「✰」 Mínimo 2 opciones.\n> Ejemplo: ${config.prefix}encuesta ¿Te gusta el bot?|si|no`);
            }
            
            if (textSplit.length > 13) {
                return await replyWithContext(`「✰」 Máximo 12 opciones.`);
            }
            
            const question = textSplit[0];
            const optionsList = textSplit.slice(1);
            
            try {
                await sock.sendMessage(from, { react: { text: '🌸', key: msg.key } });
            } catch (e) {}
            
            // Enviar encuesta
            await sock.sendMessage(from, {
                poll: {
                    name: question,
                    values: optionsList,
                    selectableCount: 1
                },
                contextInfo: {
                    forwardingScore: 9999999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: config.canalId || '',
                        serverMessageId: 0,
                        newsletterName: config.canalNombre || ''
                    }
                }
            }, { quoted: msg });
            
            try {
                await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            } catch (e) {}
            
            console.log(`✅ Encuesta creada por ${pushName || userNumber} en grupo ${from}`);
            
        } catch (error) {
            console.error('❌ Error en encuesta:', error);
            
            try {
                await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            } catch (e) {}
            
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};