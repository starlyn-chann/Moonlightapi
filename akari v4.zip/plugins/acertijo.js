import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { juegosActivos } from '../lib/gameCache.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ACERTIJOS_FILE = path.join(__dirname, '..', 'data', 'acertijo.json');
const ECONOMY_FILE = path.join(__dirname, '..', 'data', 'economy.json');

const timeout = 30000;
const REcompensa = 10000;

function loadAcertijos() {
    try {
        if (fs.existsSync(ACERTIJOS_FILE)) {
            const data = fs.readFileSync(ACERTIJOS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando acertijos:', e);
    }
    return [];
}

function loadEconomy() {
    try {
        if (fs.existsSync(ECONOMY_FILE)) {
            const data = fs.readFileSync(ECONOMY_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando economía:', e);
    }
    return {};
}

function saveEconomy(economy) {
    try {
        fs.writeFileSync(ECONOMY_FILE, JSON.stringify(economy, null, 2));
        return true;
    } catch (e) {
        console.error('Error guardando economía:', e);
        return false;
    }
}

export default {
    name: 'acertijo',
    alias: ['acert', 'adivinanza'],
    description: 'Adivina el acertijo y gana 10,000 coins',
    category: 'economy',
    
    async execute(sock, msg, options) {
        try {
            const { config, replyWithContext, args, userNumber, senderJid, pushName, isGroup } = options;
            const from = msg.key.remoteJid;
            const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            
            if (!isGroup) {
                return await replyWithContext(`⚠︎ *Este comando solo funciona en grupos*`);
            }
            
            const gameKey = `acertijo_${from}`;
            
            // ============ VERIFICAR SI ES RESPUESTA A UN ACERTIJO ============
            if (juegosActivos[gameKey]) {
                const game = juegosActivos[gameKey];
                
                // Si el mensaje es un comando, no procesar como respuesta
                if (body.startsWith(config.prefix)) return;
                
                const respuestaUsuario = body.trim().toLowerCase();
                const respuestaCorrecta = game.respuesta.toLowerCase().trim();
                
                const esCorrecta = respuestaUsuario === respuestaCorrecta || 
                    (respuestaUsuario.length > 2 && respuestaCorrecta.includes(respuestaUsuario)) || 
                    (respuestaCorrecta.length > 2 && respuestaUsuario.includes(respuestaCorrecta));
                
                if (esCorrecta) {
                    // Limpiar el timeout
                    if (game.timeout) {
                        clearTimeout(game.timeout);
                    }
                    
                    const economy = loadEconomy();
                    if (!economy[from]) economy[from] = {};
                    if (!economy[from][userNumber]) {
                        economy[from][userNumber] = {
                            dinero: 0,
                            banco: 0,
                            nombre: pushName || 'Usuario'
                        };
                    }
                    
                    economy[from][userNumber].dinero += REcompensa;
                    economy[from][userNumber].nombre = pushName || 'Usuario';
                    saveEconomy(economy);
                    
                    await replyWithContext(`❀ 𝘈𝘤𝘦𝘳𝘵𝘪𝘫𝘰 𝘢𝘥𝘪𝘷𝘪𝘯𝘢𝘥𝘰\n> *Recompensa: ${REcompensa.toLocaleString()} ${config.moneda}*`);
                    
                    delete juegosActivos[gameKey];
                    return;
                }
                
                return;
            }
            // ================================================================
            
            // ============ INICIAR NUEVO ACERTIJO ============
            const commandMatch = body.match(new RegExp(`^${config.prefix}(acertijo|acert|adivinanza|tekateki)`));
            if (!commandMatch) return;
            
            if (juegosActivos[gameKey]) {
                return await replyWithContext(`⚠︎ *Ya hay un acertijo activo en este grupo*\n> Responde al mensaje con tu respuesta.`);
            }
            
            const acertijos = loadAcertijos();
            if (!acertijos || acertijos.length === 0) {
                return await replyWithContext(`✘ *No hay acertijos disponibles*`);
            }
            
            const randomIndex = Math.floor(Math.random() * acertijos.length);
            const acertijo = acertijos[randomIndex];
            
            // Crear el timeout y guardarlo en el objeto
            const timeoutId = setTimeout(() => {
                if (juegosActivos[gameKey]) {
                    const game = juegosActivos[gameKey];
                    replyWithContext(`⏰ *Tiempo agotado!*\n\n` +
                        `⍰ 𝘈𝘤𝘦𝘳𝘵𝘪𝘫𝘰 › ${game.pregunta}\n` +
                        `❖ 𝘙𝘦𝘴𝘱𝘶𝘦𝘴𝘵𝘢 › ${game.respuesta}`);
                    delete juegosActivos[gameKey];
                }
            }, timeout);
            
            juegosActivos[gameKey] = {
                pregunta: acertijo.question,
                respuesta: acertijo.response,
                timestamp: Date.now(),
                usuario: userNumber,
                timeout: timeoutId // Guardar el timeout para poder limpiarlo
            };
            
            const mensaje = `⍰ 𝘈𝘤𝘦𝘳𝘵𝘪𝘫𝘰 › ${acertijo.question}\n` +
                          `⧖ 𝘛𝘪𝘦𝘮𝘱𝘰 › ${(timeout / 1000).toFixed(0)}s\n` +
                          `✧ 𝘙𝘦𝘤𝘰𝘮𝘱𝘦𝘯𝘴𝘢 › ${REcompensa.toLocaleString()} ${config.moneda}`;
            
            await replyWithContext(mensaje);
            
        } catch (error) {
            console.error('❌ Error en acertijo:', error);
            try {
                const { replyWithContext } = options;
                await replyWithContext(`❌ Error: ${error.message}`);
            } catch (e) {}
        }
    }
};