import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const WELCOME_FILE = path.join(__dirname, 'data', 'welcome.json');
const GOODBYE_FILE = path.join(__dirname, 'data', 'goodbye.json');
const ALERTS_FILE = path.join(__dirname, 'data', 'alerts.json');
const PRIMARIOS_FILE = path.join(process.cwd(), 'databases', 'primarios.json');

function loadWelcome() {
    try {
        if (fs.existsSync(WELCOME_FILE)) {
            const data = fs.readFileSync(WELCOME_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de bienvenida:', e);
    }
    return {};
}

function loadGoodbye() {
    try {
        if (fs.existsSync(GOODBYE_FILE)) {
            const data = fs.readFileSync(GOODBYE_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando mensajes de despedida:', e);
    }
    return {};
}

function loadAlerts() {
    try {
        if (fs.existsSync(ALERTS_FILE)) {
            const data = fs.readFileSync(ALERTS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando alertas:', e);
    }
    return {};
}

function loadUsersDb() {
    try {
        const USERS_FILE = path.join(__dirname, 'data', 'users.json');
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (e) {
        console.error('Error cargando usuarios:', e);
    }
    return {};
}

function getDisplayName(number) {
    const users = loadUsersDb();
    const user = users.find(u => u.number === number);
    return user ? user.pushName : number;
}

function cleanNumber(number) {
    if (!number) return '';
    if (typeof number === 'object') {
        number = number.id || number.jid || number.phoneNumber || '';
    }
    if (typeof number === 'string') {
        let cleaned = number.replace(/@.+/, '').split(':')[0];
        cleaned = cleaned.replace(/\D/g, '');
        return cleaned;
    }
    return '';
}

function loadConfig() {
    try {
        const configPath = path.join(__dirname, 'config.js');
        if (fs.existsSync(configPath)) {
            const configContent = fs.readFileSync(configPath, 'utf8');
            const match = configContent.match(/export default\s+({[\s\S]*})/);
            if (match && match[1]) {
                return eval('(' + match[1] + ')');
            }
        }
    } catch (e) {
        console.error('Error cargando config:', e);
    }
    return {
        nombre: 'Starlyn',
        nombre2: 'あかり',
        prefix: '.',
        banner: '',
        canalId: '',
        canalNombre: ''
    };
}

function getPrimaryBot(groupId) {
    try {
        if (fs.existsSync(PRIMARIOS_FILE)) {
            const data = JSON.parse(fs.readFileSync(PRIMARIOS_FILE, 'utf8'));
            return data[groupId] || null;
        }
    } catch (e) {}
    return null;
}

function getBotNumber(sock) {
    if (sock.phoneNumber) {
        return sock.phoneNumber.replace(/[^0-9]/g, '');
    } else if (sock.user?.id) {
        return sock.user.id.split(':')[0].replace(/[^0-9]/g, '');
    }
    return '';
}

function getGroupAdmins(participants) {
    return (participants ?? []).filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.id).filter(Boolean);
}

const DEFAULT_WELCOME = 
`✿ @user

  ╭   ۪ ໋ 𝆬ฅ ฅ (ᐡ ⩌⩊⩌ ᐡ) 𝆬   𖹭ᩧ𑁀🌻̥  ֵ   ֘ ⪩⪨  ໋໋╮
          𖹭 ㅤ  𝓦𝘦𝘭𝘤𝘰𝘮𝘦ㅤ   ᗝ᳢    ::
          
      ✿ @user 𝖡𝗂𝖾𝗇𝗏𝖾𝗇𝗂𝖽𝗈 𝖺𝗅 𝗀𝗋𝗎𝗉𝗈 *(ᐢ˙꒳˙ᐢ)*
      ✐ @group  
         ︶⏝︶ ౨🩰ৎ ︶ׁ⏝︶

> ✐ Usa /help para ver mis funciones
> https://moonstaff.onrender.com/`;

const DEFAULT_GOODBYE =
`✿ @user

  ╭   ۪ ໋ 𝆬ฅ ฅ (ᐡ ⩌⩊⩌ ᐡ) 𝆬   𖹭ᩧ𑁀🌻̥  ֵ   ֘ ⪩⪨  ໋໋╮
         𖹭 ㅤ  𝓖𝘰𝘰𝘥𝘣𝘺𝘦ㅤ   ᗝ᳢    ::
          
      ✿ @user 𝖧𝖺 𝗌𝖺𝗅𝗂𝖽𝗈 𝖽𝖾𝗅 𝗀𝗋𝗎𝗉𝗈 *(𓏽̊◞ׄ ‸ ۪◟ּ𓏽 ᳹ )*
      ✐ @group  
         ︶⏝︶ ౨🩰ৎ ︶ׁ⏝︶

> ✐ Usa /help para ver mis funciones
> https://moonstaff.onrender.com/`;

export default async (sock) => {
    sock.ev.on('group-participants.update', async (update) => {
        try {
            const { id: groupId, participants, action } = update;
            
            const primaryData = getPrimaryBot(groupId);
            const currentBotNumber = getBotNumber(sock);
            
            if (primaryData && primaryData.botNumber !== currentBotNumber) {
                console.log(`[EVENT] Bot primario es ${primaryData.botNumber}, ignorando evento en ${groupId}`);
                return;
            }
            
            const metadata = await sock.groupMetadata(groupId).catch(() => null);
            if (!metadata) return;
            
            const memberCount = metadata.participants?.length || 0;
            const groupName = metadata.subject || 'Grupo';
            const groupDesc = metadata.desc || 'Sin descripción';
            const groupAdmins = getGroupAdmins(metadata.participants);
            
            const welcomeData = loadWelcome();
            const goodbyeData = loadGoodbye();
            const alertsData = loadAlerts();
            
            const welcomeConfig = welcomeData[groupId] || { 
                message: DEFAULT_WELCOME, 
                enabled: true 
            };
            const goodbyeConfig = goodbyeData[groupId] || { 
                message: DEFAULT_GOODBYE, 
                enabled: true 
            };
            const alertsEnabled = alertsData[groupId] !== false;
            
            const now = new Date();
            const fecha = now.toLocaleDateString('es-ES', { 
                day: '2-digit', 
                month: 'long', 
                year: 'numeric' 
            });
            const hora = now.toLocaleTimeString('es-ES', { 
                hour: '2-digit', 
                minute: '2-digit',
                second: '2-digit'
            });
            const tiempo = `${fecha} ${hora}`;
            
            const config = loadConfig();
            const bannerUrl = config.banner || '';
            const link = 'https://moonstaff.onrender.com/';
            
            const participantsList = Array.isArray(participants) ? participants : [participants];
            
            for (const participant of participantsList) {
                let jid = '';
                if (typeof participant === 'string') {
                    jid = participant;
                } else if (typeof participant === 'object') {
                    jid = participant.id || participant.jid || participant.phoneNumber || '';
                }
                
                if (!jid) continue;
                
                const number = cleanNumber(jid);
                if (!number) continue;
                
                const name = getDisplayName(number) || number;
                
                // ============ BIENVENIDA ============
                if ((action === 'add') && welcomeConfig.enabled && welcomeConfig.message) {
                    let welcomeMsg = welcomeConfig.message
                        .replace(/@user/g, `@${name}`)
                        .replace(/@group/g, groupName)
                        .replace(/@desc/g, groupDesc)
                        .replace(/@members/g, memberCount)
                        .replace(/@time/g, tiempo);
                    
                    if (!welcomeMsg.includes('https://moonstaff.onrender.com/')) {
                        welcomeMsg = welcomeMsg + `\n\n> ✐ Usa /help para ver mis funciones\n> https://moonstaff.onrender.com/`;
                    }
                    
                    try {
                        const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                        
                        if (bannerUrl && uploadMethod) {
                            const { imageMessage } = await prepareWAMessageMedia(
                                { image: { url: bannerUrl } },
                                { 
                                    upload: uploadMethod, 
                                    mediaTypeOverride: 'thumbnail-link' 
                                }
                            );
                            
                            const linkPreview = {
                                'canonical-url': link,
                                'matched-text': link,
                                title: config.nombre || 'Starlyn',
                                description: `🌻 Bienvenida a ${groupName}`,
                                jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                                highQualityThumbnail: imageMessage || undefined
                            };
                            
                            await sock.sendMessage(groupId, {
                                text: welcomeMsg,
                                linkPreview: linkPreview,
                                contextInfo: {
                                    mentionedJid: [jid],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            });
                        } else {
                            await sock.sendMessage(groupId, {
                                text: welcomeMsg,
                                contextInfo: {
                                    mentionedJid: [jid],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            });
                        }
                    } catch (error) {
                        console.error('Error enviando bienvenida:', error);
                        await sock.sendMessage(groupId, {
                            text: welcomeMsg,
                            contextInfo: {
                                mentionedJid: [jid],
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: '0',
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        });
                    }
                }
                
                // ============ DESPEDIDA ============
                if ((action === 'remove' || action === 'leave') && goodbyeConfig.enabled && goodbyeConfig.message) {
                    let goodbyeMsg = goodbyeConfig.message
                        .replace(/@user/g, `@${name}`)
                        .replace(/@group/g, groupName)
                        .replace(/@desc/g, groupDesc)
                        .replace(/@members/g, memberCount)
                        .replace(/@time/g, tiempo);
                    
                    if (!goodbyeMsg.includes('https://moonstaff.onrender.com/')) {
                        goodbyeMsg = goodbyeMsg + `\n\n> ✐ Usa /help para ver mis funciones\n> https://moonstaff.onrender.com/`;
                    }
                    
                    try {
                        const uploadMethod = sock.waUploadToServer || sock.updateMediaMessage;
                        
                        if (bannerUrl && uploadMethod) {
                            const { imageMessage } = await prepareWAMessageMedia(
                                { image: { url: bannerUrl } },
                                { 
                                    upload: uploadMethod, 
                                    mediaTypeOverride: 'thumbnail-link' 
                                }
                            );
                            
                            const linkPreview = {
                                'canonical-url': link,
                                'matched-text': link,
                                title: config.nombre || 'Starlyn',
                                description: `🐝 Despedida de ${groupName}`,
                                jpegThumbnail: imageMessage?.jpegThumbnail ? Buffer.from(imageMessage.jpegThumbnail) : undefined,
                                highQualityThumbnail: imageMessage || undefined
                            };
                            
                            await sock.sendMessage(groupId, {
                                text: goodbyeMsg,
                                linkPreview: linkPreview,
                                contextInfo: {
                                    mentionedJid: [jid],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            });
                        } else {
                            await sock.sendMessage(groupId, {
                                text: goodbyeMsg,
                                contextInfo: {
                                    mentionedJid: [jid],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterJid: config.canalId || '',
                                        serverMessageId: '0',
                                        newsletterName: config.canalNombre || ''
                                    }
                                }
                            });
                        }
                    } catch (error) {
                        console.error('Error enviando despedida:', error);
                        await sock.sendMessage(groupId, {
                            text: goodbyeMsg,
                            contextInfo: {
                                mentionedJid: [jid],
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: '0',
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        });
                    }
                }
                
                // ============ ALERTAS DE PROMOCIÓN/DEMOCIÓN CON CONTEXTINFO ============
                if (alertsEnabled && (!primaryData || primaryData.botNumber === currentBotNumber)) {
                    const authorJid = update.author || '';
                    const authorNumber = cleanNumber(authorJid);
                    
                    let alertText = '';
                    let mentions = [];
                    
                    if (action === 'promote') {
                        alertText = `「✎」 *@${number}* ha sido promovido a Administrador por *@${authorNumber}*.`;
                        mentions = [jid, authorJid, ...groupAdmins];
                    } else if (action === 'demote') {
                        alertText = `「✎」 *@${number}* ha sido degradado de Administrador por *@${authorNumber}*.`;
                        mentions = [jid, authorJid, ...groupAdmins];
                    }
                    
                    if (alertText) {
                        await sock.sendMessage(groupId, {
                            text: alertText,
                            contextInfo: {
                                mentionedJid: mentions,
                                isForwarded: true,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: config.canalId || '',
                                    serverMessageId: '0',
                                    newsletterName: config.canalNombre || ''
                                }
                            }
                        });
                    }
                }
                // ================================================================
            }
            
        } catch (error) {
            console.error('❌ Error en evento group-participants:', error);
        }
    });
};